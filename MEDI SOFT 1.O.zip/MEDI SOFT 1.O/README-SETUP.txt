============================================
 RATHI MEDISOFT - ZIP SE INSTALL KARNE KA TARIKA
============================================

DOOSRE COMPUTER PAR (jo bhi yeh app chalana chahe):

STEP 1 - ZIP extract karo
  - ZIP ko kahin bhi extract karo (jaise C:\ ya Documents)
  - NOTE: Folder jis naam se extract hoga, shortcut usi ko point karega.
    Folder ko bad mein rename/na move karna!

STEP 2 - SETUP.bat chalao (double-click)
  - Bas itna karna hai - Desktop par "Medisoft Medical Store" shortcut ban jayega

STEP 3 - Kaam shuru
  - Desktop par "Medisoft Medical Store" double-click
  - Koi window nahi dikhegi - bas browser mein app khul jayegi
  - Bill banao -> "🖨️ Print & Save Bill" dabao -> Bill save + print ho jayega
  - History mein kisi bill par "🖨️ Print" / "↻ Reprint" ya "👁 Preview" dabao

============================================
 APP POORA OFFLINE CHALTA HAI
============================================
- Billing, inventory, history, reports, Excel export, PDF download, printing,
  Notepad print — sab kuch bina internet ke chalta hai.
- Excel (xlsx) aur PDF (html2pdf) libraries ab app ke andar
  assets/vendor/ folder mein rakhi hain. CDN/internet ki zaroorat nahi.
- Internet SIRF tab chahiye jab aap khud "Backup & Restore" section mein
  "☁️ Backup to DB", "☁️ Restore from DB" ya Gmail backup dabayein.
  Neon/cloud par koi automatic sync nahi hota. Online backup Neon Postgres
  DB mein jaata hai (pehli baar tables khud ban jaate hain).
- Offline JSON Backup (Download JSON) se local file bana ke rakhna zaroori hai
  — hardisk/format hone par yahi sabse safe copy hai.

============================================
 SAFETY / SECURITY NOTES
============================================
- App ka local server sirf 127.0.0.1 (is computer) par chalta hai. Dusre
  computer/mobile se is app ko network par access nahi kiya ja sakta.
- Neon connection string sirf assets/neon-config.json mein hai (server-side).
  Browser mein wo key kabhi nahi jaati. Is file ko kisi ke saath share na karein.
- Server sirf app ki zaroori files serve karta hai (index.html + assets/css,
  assets/js, assets/vendor). server.js, package.json, schema, backups etc.
  browser se padhe nahi ja sakte.
- "Clear All Data" sirf is computer ka local data delete karta hai.
  Online backup (cloud) ko chhuta nahi. Cloud delete ke liye alag se
  "🗑️ Clear Online Backup" button hai (password ke saath).

============================================
 ZAROORI BAAT
============================================
- App chalane ke liye Node.js zaroori hai. Agar kisi computer par Node.js
  nahi hai, to shortcut par click karne par khud hi message aayega aur
  install page khul jayega (sirf ek baar install karna hota hai).
- Server ko koi aur install ki zaroorat NAHI hai (npm install nahi).
- Data is computer ki IndexedDB (medi_soft_v2) mein authoritative roop se
  save hota hai; localStorage sirf fallback/mirror hai. Har bill/stock/return
  alag record ki tarah likha jata hai, taaki ek stale tab purana data overwrite
  na kar de.
- Koi bill agar history se gayab ho aur printed copy ho, to New Bill screen par
  "🔧 Missing Bill Re-entry" kholein, printed Invoice No. daalein, Apply karein,
  phir bill normal tarah banayein. Bill usi number se save hoga aur duplicate
  number allow nahi hoga. Stock pehle hi kata ho to "Stock already deducted"
  checkbox checked rakhein — dobara stock nahi ghatega.
- Regular Offline Backup (JSON) download karte rehna best hai — computer
  kharab/format hone par local data chala jayega.
- Agar kisi computer par server port 8080 pehle se kisi aur cheez se
  bhra ho, to wo conflict dega (rare) - aam taur par koi dikkat nahi.
  Server band karne ke liye task manager mein "node" process band karein
  ya computer restart karein.
