var h = require('http'), https = require('https'), f = require('fs'), p = require('path'), os = require('os');

// App root = server folder ke parent mein (index.html wahi hai; assets/ uske andar).
var root = p.resolve(__dirname, '..');

// ========== NEON DB CONFIG (SERVER-SIDE ONLY — never exposed to client) ==========
// Browser kabhi Neon DB ko direct call nahi karta. Sirf yeh local server proxy karta hai.
// Connection string env var se ya assets/neon-config.json se padhi jaati hai.
// (neon-config.json static resolver se serve NAHI hoti.)
function loadNeonConnectionString() {
    var fromEnv = process.env.NEON_DATABASE_URL || process.env.DATABASE_URL;
    if (fromEnv && /^postgres(ql)?:\/\//i.test(fromEnv)) return fromEnv;
    try {
        var raw = f.readFileSync(p.join(__dirname, 'neon-config.json'), 'utf8');
        var cfg = JSON.parse(raw);
        var cs = cfg && (cfg.connectionString || cfg.connection_string || cfg.url);
        if (cs && /^postgres(ql)?:\/\//i.test(cs)) return cs;
        console.error('Neon config error: connectionString missing in assets/neon-config.json');
    } catch (e) {
        if (e && e.code !== 'ENOENT') console.error('Neon config read error:', e.message || e);
    }
    return '';
}

var NEON_CONNECTION_STRING = loadNeonConnectionString();
var NEON_HOST = '';
try {
    if (NEON_CONNECTION_STRING) NEON_HOST = new URL(NEON_CONNECTION_STRING).hostname;
    if (!NEON_HOST) console.error('Neon DB configure nahi hua — online backup available nahi hoga.');
} catch (e) {
    NEON_HOST = '';
    console.error('Neon config error: invalid connection string.');
}

// Table schema allowlist. Sirf yahi tables/columns proxy kiye jaate hain,
// aur inhi types se DELETE filters safely cast hote hain.
var TABLES = {
    stock: {
        pk: 'id',
        cols: {
            id: 'text', name: 'text', wholesaler: 'text', make: 'text',
            h: 'bool', h1: 'bool', h2: 'bool', narcotic: 'bool'
        }
    },
    batches: {
        pk: 'id',
        cols: {
            id: 'text', stock_id: 'text', batch: 'text', expiry: 'text',
            qty: 'int', strip_size: 'int', price: 'real'
        }
    },
    bills: {
        pk: 'id',
        cols: {
            id: 'text', bill_no: 'int', date: 'text', time: 'text', patient: 'text',
            doctor: 'text', payment_mode: 'text', total: 'real', cancelled: 'bool',
            cancel_reason: 'text', cancelled_at: 'text'
        }
    },
    bill_items: {
        pk: 'id',
        cols: {
            id: 'text', bill_id: 'text', stock_id: 'text', particulars: 'text',
            make: 'text', h: 'bool', h1: 'bool', h2: 'bool', narcotic: 'bool',
            batch: 'text', expiry: 'text', qty: 'int', amount: 'real'
        }
    },
    doctors: { pk: 'name', cols: { name: 'text' } },
    make_list: { pk: 'name', cols: { name: 'text' } },
    wholesaler_list: { pk: 'name', cols: { name: 'text' } },
    patient_words: { pk: 'word', cols: { word: 'text' } },
    bill_counter: { pk: 'id', cols: { id: 'int', counter: 'int' } },
    purchase_bills: {
        pk: 'id',
        cols: {
            id: 'text', pharma_name: 'text', file_name: 'text', file_type: 'text',
            file_data: 'text', date: 'text', added_at: 'bigint'
        }
    },
    medicine_returns: {
        pk: 'id',
        cols: {
            id: 'text', request_id: 'text', stock_id: 'text', batch_id: 'text',
            medicine_name: 'text', make: 'text', supplier: 'text', batch: 'text',
            expiry: 'text', qty: 'int', return_date: 'text', remarks: 'text',
            status_before: 'text', status_after: 'text', remaining_after: 'int',
            stock_before: 'int', stock_after: 'int', returned_before: 'int',
            source_type: 'text', created_at: 'text', timestamp: 'bigint'
        }
    }
};

var ALLOWED_TABLES = {};
Object.keys(TABLES).forEach(function (t) { ALLOWED_TABLES[t] = true; });

var HOST = '127.0.0.1';
var PORT = parseInt(process.env.PORT, 10) || 8080;
var MAX_BODY = 30 * 1024 * 1024;      // 30 MB (purchase-bill base64 records)
var MAX_PRINT_BODY = 8 * 1024 * 1024; // 8 MB raw ESC/P payload
var MAX_URL = 8192;

// ========== SECURE STATIC FILE RESOLUTION ==========
// Sirf app ke liye zaroori files serve hoti hain. server.js / package.json /
// neon-config.json / neon-schema.sql / backups etc. kabhi serve nahi hote.
function resolveStatic(urlPath) {
    if (urlPath === '/' || urlPath === '/index.html') return p.join(root, 'index.html');
    var m = /^\/assets\/(css|js|vendor)\/([A-Za-z0-9._-]+)$/.exec(urlPath);
    if (!m) return null;
    var dir = m[1], name = m[2];
    var ext = p.extname(name).toLowerCase();
    if (dir === 'css' && ext !== '.css') return null;
    if ((dir === 'js' || dir === 'vendor') && ext !== '.js') return null;
    var full = p.join(root, 'assets', dir, name);
    if (!full.startsWith(p.join(root, 'assets') + p.sep)) return null;
    return full;
}

function contentTypeFor(fp) {
    var ext = p.extname(fp).toLowerCase();
    if (ext === '.html') return 'text/html; charset=utf-8';
    if (ext === '.js') return 'text/javascript; charset=utf-8';
    if (ext === '.css') return 'text/css; charset=utf-8';
    if (ext === '.json') return 'application/json; charset=utf-8';
    if (ext === '.png') return 'image/png';
    if (ext === '.svg') return 'image/svg+xml';
    if (ext === '.ico') return 'image/x-icon';
    return 'application/octet-stream';
}

function isLocalAuthority(value) {
    if (!value) return false;
    return /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i.test(value);
}

function isLocalOrigin(value) {
    if (!value) return false;
    return /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i.test(value);
}

function sendJson(res, status, obj) {
    if (res.writableEnded) return;
    var body = JSON.stringify(obj);
    res.writeHead(status, {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff'
    });
    res.end(body);
}

function readBody(req, limit, cb) {
    var chunks = [], len = 0, done = false;
    req.on('data', function (chunk) {
        if (done) return;
        len += chunk.length;
        if (len > limit) {
            done = true;
            cb({ tooLarge: true });
            req.destroy();
            return;
        }
        chunks.push(chunk);
    });
    req.on('end', function () {
        if (done) return;
        done = true;
        cb(null, Buffer.concat(chunks).toString('utf8'));
    });
    req.on('error', function () {
        if (done) return;
        done = true;
        cb({ error: true });
    });
}

function validQueryString(qs) {
    if (!qs) return true;
    if (qs.length > MAX_URL) return false;
    // Printable ASCII only (no spaces / CRLF / NUL). Query string sirf
    // PostgREST filters ke liye hai; path traversal isme possible nahi.
    return /^[!-~]+$/.test(qs) && qs.charAt(0) === '?' && qs.indexOf('#') === -1;
}

// ========== NEON PROXY (SQL over HTTPS) ==========
// Neon ka SQL-over-HTTP endpoint use hota hai — koi npm package install nahi
// karna padta. Har request: POST https://<endpoint-host>/sql
// Header: Neon-Connection-String (poora connection string, server-side only).

function neonReady() { return !!(NEON_CONNECTION_STRING && NEON_HOST); }

function quoteIdent(name) {
    // Identifiers hamesha allowlist se aate hain; yeh extra safety hai.
    return '"' + String(name).replace(/"/g, '""') + '"';
}

function neonRequest(payload, cb) {
    if (!neonReady()) {
        cb({ error: 'Neon DB configure nahi hua — assets/neon-config.json check karein.' });
        return;
    }
    var body = JSON.stringify(payload);
    var maxAttempts = 2;

    function attempt(n) {
        var finished = false;
        var options = {
            hostname: NEON_HOST,
            port: 443,
            path: '/sql',
            method: 'POST',
            // Har request fresh connection par — Neon idle keep-alive socket
            // band kar deta hai, jisse reuse par ECONNRESET aa sakta hai.
            agent: false,
            headers: {
                'Neon-Connection-String': NEON_CONNECTION_STRING,
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(body)
            }
        };
        var req = https.request(options, function (neonRes) {
            var data = '';
            neonRes.setEncoding('utf8');
            neonRes.on('data', function (chunk) { data += chunk; });
            neonRes.on('end', function () {
                if (finished) return;
                finished = true;
                var parsed = null;
                try { parsed = JSON.parse(data || '{}'); } catch (e) {}
                if (neonRes.statusCode >= 200 && neonRes.statusCode < 300) {
                    cb(null, parsed || {});
                    return;
                }
                var msg = (parsed && (parsed.message || parsed.error)) || ('Neon HTTP ' + neonRes.statusCode);
                cb({ error: msg, code: parsed && parsed.code });
            });
        });
        req.setTimeout(30000, function () {
            if (!finished) req.destroy(Object.assign(new Error('Neon request timeout'), { code: 'ETIMEDOUT' }));
        });
        req.on('error', function (e) {
            if (finished) return;
            finished = true;
            var code = e && e.code;
            var retryable = n < maxAttempts &&
                (code === 'ECONNRESET' || code === 'EPIPE' || code === 'ECONNREFUSED');
            if (retryable) {
                console.error('Neon request ' + code + ' — retry ' + n + '/' + maxAttempts);
                setTimeout(function () { attempt(n + 1); }, 500);
                return;
            }
            console.error('Neon request error:', (e && e.message) || e);
            cb({ error: 'Online backup server se connect nahi ho paya.' });
        });
        req.write(body);
        req.end();
    }

    attempt(1);
}

function neonQuery(sql, params) {
    return new Promise(function (resolve) {
        neonRequest({ query: sql, params: params || [] }, function (err, out) {
            if (err) { resolve(err); return; }
            resolve(out && Array.isArray(out.rows) ? out.rows : []);
        });
    });
}

// BIGINT Neon se string ban ke aata hai — app ko number chahiye.
function normalizeRow(table, row) {
    var def = TABLES[table];
    if (!def || !row) return row;
    Object.keys(def.cols).forEach(function (col) {
        if (def.cols[col] === 'bigint' && row[col] !== null && row[col] !== undefined && row[col] !== '') {
            var n = Number(row[col]);
            if (isFinite(n)) row[col] = n;
        }
    });
    return row;
}

// Fresh/empty Neon DB par pehli cloud request se pehle tables bana dete hain.
var NEON_SCHEMA_STATEMENTS = [
`CREATE TABLE IF NOT EXISTS public.stock (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    wholesaler TEXT DEFAULT '',
    make TEXT DEFAULT '',
    h BOOLEAN DEFAULT false,
    h1 BOOLEAN DEFAULT false,
    h2 BOOLEAN DEFAULT false,
    narcotic BOOLEAN DEFAULT false
)`,
`CREATE TABLE IF NOT EXISTS public.batches (
    id TEXT PRIMARY KEY,
    stock_id TEXT NOT NULL REFERENCES public.stock(id) ON DELETE CASCADE,
    batch TEXT DEFAULT '',
    expiry TEXT DEFAULT '',
    qty INTEGER DEFAULT 0,
    strip_size INTEGER DEFAULT 0,
    price REAL DEFAULT 0
)`,
`CREATE INDEX IF NOT EXISTS idx_batches_stock_id ON public.batches(stock_id)`,
`CREATE TABLE IF NOT EXISTS public.bills (
    id TEXT PRIMARY KEY,
    bill_no INTEGER DEFAULT 0,
    date TEXT DEFAULT '',
    time TEXT DEFAULT '',
    patient TEXT DEFAULT '',
    doctor TEXT DEFAULT '',
    payment_mode TEXT DEFAULT 'Cash',
    total REAL DEFAULT 0,
    cancelled BOOLEAN DEFAULT false,
    cancel_reason TEXT DEFAULT '',
    cancelled_at TEXT DEFAULT ''
)`,
`CREATE TABLE IF NOT EXISTS public.bill_items (
    id TEXT PRIMARY KEY,
    bill_id TEXT NOT NULL REFERENCES public.bills(id) ON DELETE CASCADE,
    stock_id TEXT DEFAULT '',
    particulars TEXT DEFAULT '',
    make TEXT DEFAULT '',
    h BOOLEAN DEFAULT false,
    h1 BOOLEAN DEFAULT false,
    h2 BOOLEAN DEFAULT false,
    narcotic BOOLEAN DEFAULT false,
    batch TEXT DEFAULT '',
    expiry TEXT DEFAULT '',
    qty INTEGER DEFAULT 0,
    amount REAL DEFAULT 0
)`,
`CREATE INDEX IF NOT EXISTS idx_bill_items_bill_id ON public.bill_items(bill_id)`,
`CREATE TABLE IF NOT EXISTS public.doctors (name TEXT PRIMARY KEY)`,
`CREATE TABLE IF NOT EXISTS public.make_list (name TEXT PRIMARY KEY)`,
`CREATE TABLE IF NOT EXISTS public.wholesaler_list (name TEXT PRIMARY KEY)`,
`CREATE TABLE IF NOT EXISTS public.patient_words (word TEXT PRIMARY KEY)`,
`CREATE TABLE IF NOT EXISTS public.bill_counter (
    id INTEGER PRIMARY KEY DEFAULT 1,
    counter INTEGER DEFAULT 0
)`,
`CREATE TABLE IF NOT EXISTS public.purchase_bills (
    id TEXT PRIMARY KEY,
    pharma_name TEXT DEFAULT '',
    file_name TEXT DEFAULT '',
    file_type TEXT DEFAULT '',
    file_data TEXT DEFAULT '',
    date TEXT DEFAULT '',
    added_at BIGINT DEFAULT 0
)`,
`CREATE TABLE IF NOT EXISTS public.medicine_returns (
    id TEXT PRIMARY KEY,
    request_id TEXT DEFAULT '',
    stock_id TEXT DEFAULT '',
    batch_id TEXT DEFAULT '',
    medicine_name TEXT DEFAULT '',
    make TEXT DEFAULT '',
    supplier TEXT DEFAULT '',
    batch TEXT DEFAULT '',
    expiry TEXT DEFAULT '',
    qty INTEGER DEFAULT 0,
    return_date TEXT DEFAULT '',
    remarks TEXT DEFAULT '',
    status_before TEXT DEFAULT '',
    status_after TEXT DEFAULT '',
    remaining_after INTEGER DEFAULT 0,
    stock_before INTEGER DEFAULT 0,
    stock_after INTEGER DEFAULT 0,
    returned_before INTEGER DEFAULT 0,
    source_type TEXT DEFAULT 'inventory',
    created_at TEXT DEFAULT '',
    timestamp BIGINT DEFAULT 0
)`,
`CREATE INDEX IF NOT EXISTS idx_medicine_returns_stock_id ON public.medicine_returns(stock_id)`,
`CREATE INDEX IF NOT EXISTS idx_medicine_returns_medicine ON public.medicine_returns(medicine_name)`
];

var _schemaPromise = null;
function ensureSchema() {
    if (_schemaPromise) return _schemaPromise;
    _schemaPromise = new Promise(function (resolve, reject) {
        var queries = NEON_SCHEMA_STATEMENTS.map(function (q) { return { query: q, params: [] }; });
        neonRequest({ queries: queries }, function (err) {
            if (err) {
                _schemaPromise = null;
                reject(new Error(err.error || 'Neon schema error'));
                return;
            }
            resolve(true);
        });
    });
    return _schemaPromise;
}

function parseQuery(queryString) {
    var qs = queryString || '';
    if (qs.charAt(0) === '?') qs = qs.slice(1);
    return new URLSearchParams(qs);
}

function clampLimit(value) {
    var n = parseInt(value, 10);
    if (!isFinite(n) || n <= 0) n = 1000;
    if (n > 5000) n = 5000;
    return n;
}

function decodeValue(v) {
    try { return decodeURIComponent(String(v)); } catch (e) { return String(v); }
}

function parseDeleteFilter(params) {
    var col = null, raw = null;
    params.forEach(function (val, key) {
        if (col === null) { col = key; raw = val; }
    });
    if (!col || raw === null) return { error: 'Missing delete filter' };
    if (raw.indexOf('eq.') === 0) {
        return { col: col, mode: 'eq', values: raw.slice(3) };
    }
    if (raw.indexOf('in.(') === 0 && raw.charAt(raw.length - 1) === ')') {
        var inner = raw.slice(4, -1);
        var vals = inner ? inner.split(',').map(decodeValue) : [];
        return { col: col, mode: 'in', values: vals };
    }
    return { error: 'Unsupported delete filter' };
}

function readJsonBody(req, limit) {
    return new Promise(function (resolve, reject) {
        readBody(req, limit, function (err, bodyStr) {
            if (err) {
                var e = new Error(err.tooLarge ? 'Request too large' : 'Bad request');
                e.status = err.tooLarge ? 413 : 400;
                reject(e);
                return;
            }
            resolve(bodyStr || '');
        });
    });
}

function neonSelect(table, limit, offset) {
    var def = TABLES[table];
    var sql = 'SELECT * FROM ' + quoteIdent(table) +
        ' ORDER BY ' + quoteIdent(def.pk) + ' ASC LIMIT $1 OFFSET $2';
    return neonQuery(sql, [limit, offset]).then(function (rows) {
        if (!Array.isArray(rows)) return rows;
        return rows.map(function (row) { return normalizeRow(table, row); });
    });
}

function neonUpsert(table, rows, conflictCol) {
    var def = TABLES[table];
    var arr = Array.isArray(rows) ? rows : [rows];
    arr = arr.filter(function (r) { return r && typeof r === 'object'; });
    if (!arr.length) return Promise.resolve({ error: 'No rows to upsert' });

    var seen = {};
    arr.forEach(function (r) {
        Object.keys(r).forEach(function (k) {
            if (def.cols[k]) seen[k] = true;
        });
    });
    var cols = Object.keys(seen);
    if (!cols.length) return Promise.resolve({ error: 'No valid columns to upsert' });

    conflictCol = conflictCol || def.pk;
    if (!def.cols[conflictCol]) return Promise.resolve({ error: 'Invalid conflict column' });

    var params = [];
    var tuples = arr.map(function (r) {
        var placeholders = cols.map(function (c) {
            var v = (r[c] === undefined) ? null : r[c];
            params.push(v);
            return '$' + params.length;
        });
        return '(' + placeholders.join(', ') + ')';
    });

    var updateCols = cols.filter(function (c) { return c !== conflictCol; });
    var sql = 'INSERT INTO ' + quoteIdent(table) +
        ' (' + cols.map(quoteIdent).join(', ') + ') VALUES ' + tuples.join(', ') +
        ' ON CONFLICT (' + quoteIdent(conflictCol) + ') DO ' +
        (updateCols.length
            ? 'UPDATE SET ' + updateCols.map(function (c) {
                return quoteIdent(c) + ' = EXCLUDED.' + quoteIdent(c);
            }).join(', ')
            : 'NOTHING');

    return neonQuery(sql, params).then(function (res) {
        if (!Array.isArray(res)) return res; // error object
        return { ok: true };
    });
}

function neonDelete(table, col, mode, values) {
    var def = TABLES[table];
    if (!def.cols[col]) return Promise.resolve({ error: 'Invalid filter column' });
    var numeric = def.cols[col] === 'int' || def.cols[col] === 'bigint';

    var sql, params;
    if (mode === 'in') {
        if (!values || !values.length) return Promise.resolve({ ok: true });
        sql = 'DELETE FROM ' + quoteIdent(table) + ' WHERE ' + quoteIdent(col) +
            ' = ANY($1::' + (numeric ? 'bigint' : 'text') + '[])';
        params = [numeric ? values.map(function (v) { return Number(v); }) : values];
    } else {
        sql = 'DELETE FROM ' + quoteIdent(table) + ' WHERE ' + quoteIdent(col) + ' = $1';
        params = [numeric ? Number(values) : values];
    }

    return neonQuery(sql, params).then(function (res) {
        if (!Array.isArray(res)) return res; // error object
        return { ok: true };
    });
}

// ========== PRINT HELPERS ==========
function openInNotepad(file, res) {
    // Notepad ko foreground mein kholo. PowerShell command ke andar path ko
    // single-quote escape karke daala jaata hai (apostrophe wale Windows user
    // profile paths bhi safe rahein).
    var psFile = String(file).replace(/'/g, "''");
    var psCmd = "$p = Start-Process -FilePath notepad.exe -ArgumentList '" + psFile + "' -PassThru; $w = New-Object -ComObject WScript.Shell; for ($i = 0; $i -lt 15; $i++) { Start-Sleep -Milliseconds 200; if ($w.AppActivate($p.Id)) { break } }; $w.AppActivate($p.Id)";
    try {
        require('child_process').execFile('powershell.exe',
            ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', psCmd],
            { windowsHide: true },
            function () {}
        );
    } catch (e) {
        try {
            require('child_process').spawn('notepad.exe', [file], { detached: true, stdio: 'ignore' }).unref();
        } catch (e2) {}
    }
    sendJson(res, 200, { ok: true, file: file });
}

// ========== HTTP SERVER ==========
var server = h.createServer(function (r, s) {
    // DNS-rebinding / cross-site request se bachao: sirf local host allowed.
    var host = r.headers.host || '';
    if (!isLocalAuthority(host)) {
        s.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
        s.end('Forbidden host');
        return;
    }

    if (!r.url || r.url.length > MAX_URL) {
        s.writeHead(414, { 'Content-Type': 'text/plain; charset=utf-8' });
        s.end('URI too long');
        return;
    }

    var qIdx = r.url.indexOf('?');
    var url = qIdx === -1 ? r.url : r.url.slice(0, qIdx);
    var queryString = qIdx === -1 ? '' : r.url.slice(qIdx);

    // ===== API ENDPOINTS =====
    if (url.indexOf('/api/') === 0) {
        // Cross-origin browser requests block karo. Custom header ki wajah se
        // cross-origin call ko pehle CORS preflight karna padta hai — jo yeh
        // server allow nahi karta.
        var origin = r.headers.origin;
        if (origin && !isLocalOrigin(origin)) {
            sendJson(s, 403, { error: 'Forbidden origin' });
            return;
        }
        if (String(r.headers['x-requested-with'] || '') !== 'MediSoft') {
            sendJson(s, 403, { error: 'Forbidden' });
            return;
        }

        // Notepad print
        if (url === '/api/print-text') {
            if (r.method !== 'POST') { sendJson(s, 405, { error: 'Method not allowed' }); return; }
            readBody(r, MAX_PRINT_BODY, function (err, bodyStr) {
                if (err) { sendJson(s, err.tooLarge ? 413 : 400, { error: err.tooLarge ? 'Text too large' : 'Bad request' }); return; }
                var text = '';
                try { text = String((JSON.parse(bodyStr || '{}').text) || ''); } catch (e) {}
                if (!text) { sendJson(s, 400, { error: 'Empty text' }); return; }
                var file = p.join(os.tmpdir(), 'medisoft_bill_' + Date.now() + '.txt');
                f.writeFile(file, text, function (writeErr) {
                    if (writeErr) {
                        console.error('print-text write error:', writeErr.message || writeErr);
                        sendJson(s, 500, { error: 'Print file save nahi hui.' });
                        return;
                    }
                    openInNotepad(file, s);
                });
            });
            return;
        }

        // Raw ESC/P print
        if (url === '/api/print-raw') {
            if (r.method !== 'POST') { sendJson(s, 405, { error: 'Method not allowed' }); return; }
            readBody(r, MAX_PRINT_BODY, function (err, rawBody) {
                if (err) { sendJson(s, err.tooLarge ? 413 : 400, { error: err.tooLarge ? 'Print data too large' : 'Bad request' }); return; }
                var payload = {};
                try { payload = JSON.parse(rawBody || '{}'); } catch (e) {}
                var dataBase64 = String(payload.dataBase64 || '');
                var printerName = String(payload.printerName || process.env.PRINTER_NAME || 'EPSON LX-310 ESC/P')
                    .replace(/[^A-Za-z0-9 _.\-()]/g, '')
                    .slice(0, 100) || 'EPSON LX-310 ESC/P';
                if (!dataBase64) { sendJson(s, 400, { error: 'Empty dataBase64' }); return; }
                var buffer = null;
                try { buffer = Buffer.from(dataBase64, 'base64'); } catch (e) {}
                if (!buffer || !buffer.length) { sendJson(s, 400, { error: 'Invalid base64 data' }); return; }

                var printerMod = null;
                try { printerMod = require('@thiagoelg/node-printer'); } catch (e) {}
                if (printerMod && typeof printerMod.printDirect === 'function') {
                    try {
                        printerMod.printDirect({
                            data: buffer,
                            printer: printerName,
                            type: 'RAW',
                            success: function () { sendJson(s, 200, { ok: true }); },
                            error: function (printErr) {
                                console.error('printDirect error:', printErr);
                                sendJson(s, 500, { error: 'Printer error.' });
                            }
                        });
                        return;
                    } catch (e) {
                        // fallback below
                    }
                }

                var prnFile = p.join(os.tmpdir(), 'medisoft_raw_' + Date.now() + '.prn');
                f.writeFile(prnFile, buffer, function (writeErr) {
                    if (writeErr) {
                        console.error('print-raw write error:', writeErr.message || writeErr);
                        sendJson(s, 500, { error: 'Print file save nahi hui.' });
                        return;
                    }
                    var psFile = p.join(os.tmpdir(), 'medisoft_raw_' + Date.now() + '.ps1');
                    var psScript = `param([string]$PrinterName, [string]$FilePath)
$ErrorActionPreference = 'Stop'
# PRINTER AUTO-RESOLVE: exact naam na mile to LX-310 / EPSON printer auto-detect karo
$resolved = $PrinterName
try {
    $all = @(Get-Printer | Select-Object -ExpandProperty Name)
    if ($all -notcontains $resolved) {
        $lx = @($all | Where-Object { $_ -like '*LX-310*' }) | Select-Object -First 1
        if ($lx) { $resolved = $lx }
        else {
            $eps = @($all | Where-Object { $_ -like '*EPSON*' }) | Select-Object -First 1
            if ($eps) { $resolved = $eps }
        }
    }
    Write-Host "Using printer: $resolved"
} catch { $resolved = $PrinterName }
$bytes = [System.IO.File]::ReadAllBytes($FilePath)
if (-not ("WPR.RawPrinterHelper" -as [type])) {
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
namespace WPR {
    public class RawPrinterHelper {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public class DOCINFOA {
            [MarshalAs(UnmanagedType.LPWStr)] public string pDocName;
            [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile;
            [MarshalAs(UnmanagedType.LPWStr)] public string pDataType;
        }
        [DllImport("winspool.drv", EntryPoint = "OpenPrinterW", SetLastError = true, CharSet = CharSet.Unicode, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool OpenPrinter(string szPrinter, out IntPtr phPrinter, IntPtr pd);
        [DllImport("winspool.drv", EntryPoint = "ClosePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool ClosePrinter(IntPtr hPrinter);
        [DllImport("winspool.drv", EntryPoint = "StartDocPrinterW", SetLastError = true, CharSet = CharSet.Unicode, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool StartDocPrinter(IntPtr hPrinter, Int32 level, [In, MarshalAs(UnmanagedType.LPStruct)] DOCINFOA di);
        [DllImport("winspool.drv", EntryPoint = "StartPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool StartPagePrinter(IntPtr hPrinter);
        [DllImport("winspool.drv", EntryPoint = "WritePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, Int32 dwCount, out Int32 dwWritten);
        [DllImport("winspool.drv", EntryPoint = "EndPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool EndPagePrinter(IntPtr hPrinter);
        [DllImport("winspool.drv", EntryPoint = "EndDocPrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool EndDocPrinter(IntPtr hPrinter);
    }
}
"@
}
$hPrinter = [IntPtr]::Zero
if (-not [WPR.RawPrinterHelper]::OpenPrinter($resolved, [ref]$hPrinter, [IntPtr]::Zero)) {
    [System.Console]::Error.WriteLine("OpenPrinter failed for '$resolved', Win32Error=" + [System.Runtime.InteropServices.Marshal]::GetLastWin32Error())
    exit 2
}
try {
    $doc = New-Object WPR.RawPrinterHelper+DOCINFOA
    $doc.pDocName = "MediSoft Raw Print"
    $doc.pOutputFile = ""
    $doc.pDataType = "RAW"
    if (-not [WPR.RawPrinterHelper]::StartDocPrinter($hPrinter, 1, $doc)) {
        [System.Console]::Error.WriteLine("StartDocPrinter failed, Win32Error=" + [System.Runtime.InteropServices.Marshal]::GetLastWin32Error())
        exit 3
    }
    [WPR.RawPrinterHelper]::StartPagePrinter($hPrinter) | Out-Null
    $alloc = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($bytes.Length)
    try {
        [System.Runtime.InteropServices.Marshal]::Copy($bytes, 0, $alloc, $bytes.Length)
        $written = 0
        [WPR.RawPrinterHelper]::WritePrinter($hPrinter, $alloc, $bytes.Length, [ref]$written) | Out-Null
    } finally {
        [System.Runtime.InteropServices.Marshal]::FreeHGlobal($alloc)
    }
    [WPR.RawPrinterHelper]::EndPagePrinter($hPrinter) | Out-Null
    [WPR.RawPrinterHelper]::EndDocPrinter($hPrinter) | Out-Null
    exit 0
} finally {
    [WPR.RawPrinterHelper]::ClosePrinter($hPrinter) | Out-Null
}`;
                    f.writeFile(psFile, psScript, function (psWriteErr) {
                        if (psWriteErr) {
                            try { f.unlink(prnFile, function () {}); } catch (e2) {}
                            sendJson(s, 500, { error: 'Print helper save nahi hua.' });
                            return;
                        }
                        var cleanup = function () {
                            try { f.unlink(prnFile, function () {}); } catch (e3) {}
                            try { f.unlink(psFile, function () {}); } catch (e4) {}
                        };
                        require('child_process').execFile(
                            'powershell.exe',
                            ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', psFile, printerName, prnFile],
                            { timeout: 60000, windowsHide: true },
                            function (psErr, stdout, stderr) {
                                if (!psErr) {
                                    cleanup();
                                    sendJson(s, 200, { ok: true, fallback: 'winspool' });
                                    return;
                                }
                                // Last resort: shared-printer UNC copy (printer share karna padega).
                                var compName = process.env.COMPUTERNAME || os.hostname();
                                require('child_process').execFile(
                                    'cmd.exe',
                                    ['/c', 'copy', '/b', prnFile, '\\\\' + compName + '\\' + printerName],
                                    function (copyErr) {
                                        cleanup();
                                        if (copyErr) {
                                            console.error('Raw print failed:', (stderr || '').trim(), psErr.message);
                                            sendJson(s, 500, { error: 'Printer ko data nahi bheja ja saka.' });
                                            return;
                                        }
                                        sendJson(s, 200, { ok: true, fallback: 'copy' });
                                    }
                                );
                            }
                        );
                    });
                });
            });
            return;
        }

        // Neon table proxy
        var table = url.slice('/api/'.length);
        if (!ALLOWED_TABLES[table]) { sendJson(s, 404, { error: 'Unknown endpoint' }); return; }
        if (!validQueryString(queryString)) { sendJson(s, 400, { error: 'Invalid query' }); return; }
        if (!neonReady()) {
            sendJson(s, 503, { error: 'Neon DB configure nahi hua — assets/neon-config.json check karein.' });
            return;
        }

        (async function () {
            await ensureSchema();

            if (r.method === 'GET') {
                var getParams = parseQuery(queryString);
                var limit = clampLimit(getParams.get('limit'));
                var offset = Math.max(0, parseInt(getParams.get('offset'), 10) || 0);
                var rows = await neonSelect(table, limit, offset);
                if (!Array.isArray(rows)) { sendJson(s, 502, rows); return; }
                sendJson(s, 200, rows);
                return;
            }

            if (r.method === 'POST') {
                var bodyStr = await readJsonBody(r, MAX_BODY);
                var rowsIn;
                try { rowsIn = JSON.parse(bodyStr || '[]'); } catch (e) {
                    sendJson(s, 400, { error: 'Invalid JSON body' });
                    return;
                }
                if (!Array.isArray(rowsIn) || !rowsIn.length) {
                    sendJson(s, 400, { error: 'No rows to upsert' });
                    return;
                }
                var postParams = parseQuery(queryString);
                var upRes = await neonUpsert(table, rowsIn, postParams.get('on_conflict') || TABLES[table].pk);
                if (upRes && upRes.error) { sendJson(s, 502, { error: upRes.error }); return; }
                sendJson(s, 200, { ok: true });
                return;
            }

            if (r.method === 'DELETE') {
                var delParams = parseQuery(queryString);
                var filter = parseDeleteFilter(delParams);
                if (filter.error) { sendJson(s, 400, { error: filter.error }); return; }
                var delRes = await neonDelete(table, filter.col, filter.mode, filter.values);
                if (delRes && delRes.error) { sendJson(s, 502, { error: delRes.error }); return; }
                sendJson(s, 200, { ok: true });
                return;
            }

            sendJson(s, 405, { error: 'Method not allowed' });
        })().catch(function (e) {
            console.error('Neon proxy error:', e && (e.message || e));
            sendJson(s, (e && e.status) || 502, { error: 'Online backup error: ' + ((e && e.message) || 'unknown') });
        });
        return;
    }

    // ===== STATIC FILES =====
    if (r.method !== 'GET' && r.method !== 'HEAD') {
        s.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
        s.end('Method not allowed');
        return;
    }

    var u = url;
    if (u === '/index.html/') u = '/index.html';
    var fp = resolveStatic(u);
    if (!fp) {
        s.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        s.end('Not Found');
        return;
    }

    f.readFile(fp, function (err, data) {
        if (err) {
            s.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
            s.end('Not Found');
            return;
        }
        var headers = {
            'Content-Type': contentTypeFor(fp),
            'X-Content-Type-Options': 'nosniff',
            'Cache-Control': 'no-store',
            'Referrer-Policy': 'no-referrer',
            'X-Frame-Options': 'SAMEORIGIN',
            'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
            'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; frame-src 'self' data: blob:; worker-src 'self' blob:; object-src 'none'; base-uri 'self'; form-action 'none'"
        };
        s.writeHead(200, headers);
        if (r.method === 'HEAD') s.end();
        else s.end(data);
    });
});

server.on('error', function (e) {
    if (e && e.code === 'EADDRINUSE') {
        console.error('Port ' + PORT + ' already in use. Pehle se chal raha Medisoft band karein.');
    } else {
        console.error('Server error:', e && (e.message || e));
    }
    process.exitCode = 1;
});

server.listen(PORT, HOST, function () {
    var addr = 'http://127.0.0.1:' + PORT;
    console.log('RATHI\'s MEDISOFT — Server chalu! (sirf is computer par)');
    console.log('Khulega: ' + addr);
    console.log('Online backup (Neon): ' + (neonReady() ? 'configured' : 'NOT configured'));
    console.log('Band karne ke liye Ctrl+C dabayein.');
    if (process.env.MEDISOFT_NO_OPEN !== '1') {
        try {
            var cp = require('child_process').spawn('cmd.exe', ['/c', 'start', '', addr], {
                detached: true, stdio: 'ignore', windowsHide: true
            });
            cp.unref();
        } catch (e) {}
    }
});
