const Inventory = (() => {
    let _editIdx = -1;
    let _pendingDeleteIdx = -1;
    let _currentPage = 1;
    let _currentFilter = '';
    let _makeHL = -1;
    let _wholeHL = -1;

    function _returnedQtyFor(item, batch) {
        try {
            if (typeof Returns === 'undefined' || !Returns.getReturnedQty) return 0;
            return Returns.getReturnedQty(item, batch) || 0;
        } catch (_) { return 0; }
    }

    function _getFilteredData() {
        const q = _currentFilter.toLowerCase().trim();
        return AppState.stockData.filter(item => {
            if (!q) return true;
            var flagField = null;
            if (q === 'h1') flagField = 'h1';
            else if (q === 'h2') flagField = 'h2';
            else if (q === 'narcotic' || q === 'narcotics' || q === 'ndps') flagField = 'narcotic';
            else if (q === 'h' && _currentFilter.trim().toLowerCase() === 'h' && _currentFilter.trim().length === 1) {
                var onlyH = item.h && !item.h1 && !item.h2 && !item.narcotic;
                if (onlyH) return true;
            }
            if (flagField) return !!item[flagField];
            if (item.name.toLowerCase().includes(q)) return true;
            if ((item.wholesaler || '').toLowerCase().includes(q)) return true;
            if ((item.make || '').toLowerCase().includes(q)) return true;
            return false;
        }).sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()));
    }

    function renderStockTable() {
        const tbody = document.getElementById('inventoryTableBody');
        Utils.clearElement(tbody);

        const filtered = _getFilteredData();
        const totalPages = Math.ceil(filtered.length / CONFIG.PAGE_SIZE) || 1;
        if (_currentPage > totalPages) _currentPage = totalPages;
        const start = (_currentPage - 1) * CONFIG.PAGE_SIZE;
        const pageData = filtered.slice(start, start + CONFIG.PAGE_SIZE);

        pageData.forEach((item, pageIdx) => {
            const realIndex = AppState.stockData.indexOf(item);
            // Zero-batch medicine ko bhi dikhao — pehle batches array khali hone
            // par koi row render nahi hoti thi aur medicine table se gayab lagti thi.
            const batchList = (item.batches && item.batches.length)
                ? item.batches
                : [{ batch: '-', expiry: '-', qty: 0, price: 0, _empty: true }];

            batchList.forEach((b, bIdx) => {
                const isLow = (b.qty || 0) < CONFIG.LOW_STOCK_THRESHOLD;
                const returnedQty = b._empty ? 0 : _returnedQtyFor(item, b);
                const tr = document.createElement('tr');
                if (isLow) tr.className = 'low-stock-row';
                if (returnedQty > 0) tr.classList.add('returned-stock-row');
                if (bIdx === 0) {
                    const tdSr = document.createElement('td');
                    tdSr.style.cssText = 'vertical-align:middle;text-align:center;color:#9ca3af;font-weight:600;';
                    tdSr.textContent = String(start + pageIdx + 1);
                    tdSr.rowSpan = batchList.length;
                    tr.appendChild(tdSr);

                    const tdName = document.createElement('td');
                    tdName.rowSpan = batchList.length;
                    tdName.style.cssText = 'vertical-align:middle;';
                    const strong = document.createElement('strong');
                    strong.textContent = item.name;
                    tdName.appendChild(strong);
                    const badges = [];
                    if (item.h) badges.push({ text: 'H', bg: '#e0e7ff', color: '#3730a3' });
                    if (item.h1) badges.push({ text: 'H1', bg: '#fef3c7', color: '#92400e' });
                    if (item.h2) badges.push({ text: 'H2', bg: '#fce7f3', color: '#9d174d' });
                    if (item.narcotic) badges.push({ text: 'NDPS', bg: '#fee2e2', color: '#991b1b' });
                    if (isLow) badges.push({ text: 'LOW', bg: '#fee2e2', color: '#dc2626' });
                    badges.forEach(b => {
                        tdName.appendChild(Utils.createElement('span', {
                            style: 'background:' + b.bg + ';color:' + b.color + ';font-size:10px;font-weight:700;padding:2px 7px;border-radius:10px;margin-left:4px;',
                            innerText: b.text
                        }));
                    });
                    tr.appendChild(tdName);

                    const tdWhole = Utils.createElement('td', {
                        rowSpan: batchList.length,
                        style: 'vertical-align:middle;color:#6b7280;',
                        innerText: item.wholesaler || '-'
                    });
                    tr.appendChild(tdWhole);

                    const tdMake = Utils.createElement('td', {
                        rowSpan: batchList.length,
                        style: 'vertical-align:middle;color:#6b7280;',
                        innerText: item.make || '-'
                    });
                    tr.appendChild(tdMake);
                }

                const tdBatch = Utils.createElement('td', { style: 'color:#6b7280;', innerText: b.batch });
                tr.appendChild(tdBatch);

                const tdExpiry = Utils.createElement('td', { style: 'color:#6b7280;', innerText: b.expiry });
                tr.appendChild(tdExpiry);

                const tdQty = document.createElement('td');
                tdQty.style.cssText = 'text-align:right;';
                const qtyVal = Utils.createElement('span', {
                    className: isLow ? 'qty-low' : 'qty-ok',
                    innerText: String(b.qty || 0)
                });
                tdQty.appendChild(qtyVal);
                if (returnedQty > 0) {
                    tdQty.appendChild(Utils.createElement('div', {
                        className: 'returned-qty-note',
                        innerText: '↩ ' + returnedQty + ' returned'
                    }));
                }
                tr.appendChild(tdQty);

                const tdPrice = Utils.createElement('td', { innerText: '₹' + Number(b.price || 0).toFixed(2) });
                tr.appendChild(tdPrice);

                if (bIdx === 0) {
                    const tdAction = document.createElement('td');
                    const editBtn = document.createElement('button');
                    editBtn.className = 'btn-primary';
                    editBtn.style.cssText = 'padding:4px 10px;font-size:12px;';
                    editBtn.textContent = '✏ Edit';
                    editBtn.addEventListener('click', () => editStockItem(realIndex));
                    tdAction.appendChild(editBtn);
                    tr.appendChild(tdAction);
                }

                tbody.appendChild(tr);
            });
        });

        if (!pageData.length) {
            tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#9ca3af;padding:30px;">Koi medicine nahi mila</td></tr>';
        }

        _renderPagination(filtered.length, totalPages);
        _updateSearchCount(filtered.length);
    }

    function _renderPagination(totalItems, totalPages) {
        let paginationEl = document.getElementById('stockPagination');
        if (!paginationEl) {
            const toolbar = document.querySelector('.inv-toolbar');
            if (!toolbar) return;
            paginationEl = document.createElement('div');
            paginationEl.id = 'stockPagination';
            paginationEl.style.cssText = 'display:flex;gap:6px;align-items:center;flex-wrap:wrap;';
            toolbar.appendChild(paginationEl);
        }
        Utils.clearElement(paginationEl);

        const info = document.createElement('span');
        info.style.cssText = 'font-size:12px;color:#9ca3af;margin-right:8px;';
        info.textContent = 'Page ' + _currentPage + ' of ' + totalPages + ' (' + totalItems + ' items)';
        paginationEl.appendChild(info);

        const prevBtn = document.createElement('button');
        prevBtn.className = 'btn-secondary';
        prevBtn.style.cssText = 'padding:4px 10px;font-size:12px;';
        prevBtn.textContent = '◀ Prev';
        prevBtn.disabled = _currentPage <= 1;
        prevBtn.addEventListener('click', () => { if (_currentPage > 1) { _currentPage--; renderStockTable(); } });
        paginationEl.appendChild(prevBtn);

        const pageInput = document.createElement('input');
        pageInput.type = 'number';
        pageInput.value = String(_currentPage);
        pageInput.min = '1';
        pageInput.max = String(totalPages);
        pageInput.style.cssText = 'width:50px;padding:4px 6px;border:1.5px solid #d1d9e0;border-radius:5px;font-size:13px;text-align:center;';
        pageInput.addEventListener('change', () => {
            const p = parseInt(pageInput.value, 10);
            if (p >= 1 && p <= totalPages) { _currentPage = p; renderStockTable(); }
            else pageInput.value = String(_currentPage);
        });
        paginationEl.appendChild(pageInput);

        const nextBtn = document.createElement('button');
        nextBtn.className = 'btn-secondary';
        nextBtn.style.cssText = 'padding:4px 10px;font-size:12px;';
        nextBtn.textContent = 'Next ▶';
        nextBtn.disabled = _currentPage >= totalPages;
        nextBtn.addEventListener('click', () => { if (_currentPage < totalPages) { _currentPage++; renderStockTable(); } });
        paginationEl.appendChild(nextBtn);
    }

    function _updateSearchCount(count) {
        const sc = document.getElementById('searchCount');
        if (sc) sc.textContent = _currentFilter ? count + ' result(s)' : 'Total: ' + AppState.stockData.length + ' medicines';
    }

    function filterStockTable(val) {
        _currentFilter = val;
        _currentPage = 1;
        renderStockTable();
    }

    // ==================== BATCH ROWS ====================

    function initBatchRows(prefill) {
        const container = document.getElementById('batchRowsContainer');
        Utils.clearElement(container);
        if (prefill && prefill.length > 0) prefill.forEach(b => addNewBatchRow(b));
        else addNewBatchRow();
    }

    function addNewBatchRow(prefill) {
        const container = document.getElementById('batchRowsContainer');
        const rowId = 'brow_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
        const div = document.createElement('div');
        div.className = 'batch-row';
        div.id = rowId;

        const preStripPrice = prefill && prefill.stripSize ? (prefill.price * prefill.stripSize).toFixed(2) : '';

        div.innerHTML = [
            '<div class="batch-field" style="flex:1.2;">',
            '  <label>Batch No.</label>',
            '  <input type="text" class="batch-no" placeholder="673862B" value="' + Utils.escapeAttr(prefill ? prefill.batch : '') + '" onkeydown="Inventory.batchRowEnter(event,this,\'expiry\')">',
            '</div>',
            '<div class="batch-field" style="flex:1.2;">',
            '  <label>Expiry (MM/YYYY)</label>',
            '  <input type="text" class="batch-expiry" placeholder="MM/YYYY" maxlength="7" oninput="Utils.formatAndValidateExpiry(this)" onkeydown="Inventory.batchRowEnter(event,this,\'qty\')" value="' + Utils.escapeAttr(prefill ? prefill.expiry : '') + '">',
            '</div>',
            '<div class="batch-field" style="flex:0.6;min-width:65px;">',
            '  <label>Qty</label>',
            '  <input type="number" class="batch-qty" placeholder="100" min="0" value="' + (prefill ? prefill.qty : '') + '" onkeydown="Inventory.batchRowEnter(event,this,\'strip-size\')">',
            '</div>',
            '<div class="batch-field" style="flex:0.5;min-width:60px;">',
            '  <label>Strip Size</label>',
            '  <input type="number" class="batch-strip-size" placeholder="10" min="1" value="' + (prefill ? prefill.stripSize || '' : '') + '" oninput="Inventory._updatePerPillHint(this)" onkeydown="Inventory.batchRowEnter(event,this,\'strip-price\')">',
            '</div>',
            '<div class="batch-field" style="flex:0.6;min-width:70px;">',
            '  <label>Strip Price (₹)</label>',
            '  <input type="number" class="batch-strip-price" placeholder="56.00" step="0.01" value="' + preStripPrice + '" oninput="Inventory._updatePerPillHint(this)" onkeydown="Inventory.batchRowStripPriceEnter(event)">',
            '  <small style="font-size:10px;color:#1a56db;font-weight:600;display:none;" class="per-pill-hint"></small>',
            '</div>',
            '<button class="btn-icon-del" onclick="Inventory.deleteBatchRow(\'' + rowId + '\')" title="Delete">✕</button>'
        ].join('');

        container.appendChild(div);
        setTimeout(() => div.querySelector('.batch-no').focus(), 30);
    }

    function _isAtEnd(el) { return el.selectionStart === null || (el.selectionStart === el.value.length && el.selectionEnd === el.value.length); }
    function _isAtStart(el) { return el.selectionStart === null || (el.selectionStart === 0 && el.selectionEnd === 0); }

    function batchRowEnter(e, input, nextClass) {
        const row = input.closest('.batch-row');
        if (e.key === 'Enter') {
            e.preventDefault();
            const next = row.querySelector('.batch-' + nextClass);
            if (next) next.focus();
        }
        if (e.key === 'ArrowRight' && _isAtEnd(input)) {
            e.preventDefault();
            const next = row.querySelector('.batch-' + nextClass);
            if (next) next.focus();
        }
        if (e.key === 'ArrowLeft' && _isAtStart(input)) {
            e.preventDefault();
            const classes = ['batch-no', 'batch-expiry', 'batch-qty', 'batch-strip-size', 'batch-strip-price'];
            const cls = classes.find(c => input.classList.contains(c));
            const idx = classes.indexOf(cls);
            if (idx > 0) { const p = row.querySelector('.' + classes[idx - 1]); if (p) p.focus(); }
            else { const sn = document.getElementById('stockName'); if (sn) sn.focus(); }
        }
        if (e.key === 'Backspace' && input.classList.contains('batch-expiry')) {
            const val = input.value;
            const pos = input.selectionStart;
            if (pos === 3 && val.length >= 3 && val[2] === '/') {
                e.preventDefault();
                input.value = val.slice(0, 2) + val.slice(3);
                input.setSelectionRange(2, 2);
            }
        }
    }

    function batchRowStripPriceEnter(e) {
        const row = e.target.closest('.batch-row');
        if (e.key === 'Enter') {
            e.preventDefault();
            const nextRow = row.nextElementSibling;
            if (nextRow && nextRow.classList.contains('batch-row')) {
                nextRow.querySelector('.batch-no').focus();
            } else {
                saveMedicineToInventory();
            }
        }
        if (e.key === 'ArrowRight' && _isAtEnd(e.target)) {
            e.preventDefault();
            const nextRow = row.nextElementSibling;
            if (nextRow && nextRow.classList.contains('batch-row')) {
                nextRow.querySelector('.batch-no').focus();
            }
        }
        if (e.key === 'ArrowLeft' && _isAtStart(e.target)) {
            e.preventDefault();
            const prev = row.querySelector('.batch-strip-size');
            if (prev) prev.focus();
        }
    }

    function _updatePerPillHint(input) {
        var row = input.closest('.batch-row');
        if (!row) return;
        var stripSizeInp = row.querySelector('.batch-strip-size');
        var stripPriceInp = row.querySelector('.batch-strip-price');
        var hint = row.querySelector('.per-pill-hint');
        if (!hint) return;
        var ss = stripSizeInp.valueAsNumber || 0;
        var sp = stripPriceInp.valueAsNumber;
        if (ss > 0 && !isNaN(sp) && sp > 0) {
            hint.textContent = '1 pill = ₹' + (sp / ss).toFixed(2);
            hint.style.display = 'block';
        } else { hint.style.display = 'none'; }
    }

    function deleteBatchRow(rowId) {
        const container = document.getElementById('batchRowsContainer');
        if (container.children.length <= 1) {
            if (_editIdx > -1) {
                _pendingDeleteIdx = _editIdx;
                const bar = document.getElementById('deleteConfirmBar');
                document.getElementById('deleteConfirmMsg').textContent = 'Yeh akhiri batch hai. "' + AppState.stockData[_editIdx].name + '" ko inventory se poora hatana hai?';
                bar.style.display = 'block';
                bar.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            } else {
                const row = document.getElementById(rowId);
                if (row) row.querySelectorAll('input').forEach(i => i.value = '');
            }
            return;
        }
        const row = document.getElementById(rowId);
        if (row) row.remove();
    }

    function confirmDeleteMedicine() {
        if (_pendingDeleteIdx < 0) return;
        const med = AppState.deleteMedicine(_pendingDeleteIdx);
        if (med) {
            _pendingDeleteIdx = -1;
            _editIdx = -1;
            document.getElementById('editIndex').value = '-1';
        _setValue('stockName', '');
        _setValue('stockMake', '');
        _setValue('stockWholesaler', '');
        document.getElementById('stockH').checked = false;
        document.getElementById('stockH1').checked = false;
        document.getElementById('stockH2').checked = false;
        document.getElementById('stockNarcotic').checked = false;
        _resetFormStyle();
        _hide('deleteConfirmBar');
        initBatchRows();
            renderStockTable();
            if (typeof Notifications !== 'undefined') Notifications.renderPanel();
            UI.showToast('"' + med.name + '" inventory se hata diya!', 'info');
        }
    }

    function cancelDeleteMedicine() {
        _pendingDeleteIdx = -1;
        _hide('deleteConfirmBar');
    }

    function resetEditState() {
        _editIdx = -1;
        _pendingDeleteIdx = -1;
        _hide('deleteConfirmBar');
        _resetFormStyle();
        _currentFilter = '';
        const searchInput = document.getElementById('stockSearchInput');
        if (searchInput) searchInput.value = '';
        // Edit state sirf variables mein nahi — form aur hidden editIndex bhi
        // clear karo. Warna agla "Save Item" galti se purani edited medicine
        // ko overwrite kar sakta tha.
        const editIndexEl = document.getElementById('editIndex');
        if (editIndexEl) editIndexEl.value = '-1';
        _setValue('stockName', '');
        _setValue('stockMake', '');
        _setValue('stockWholesaler', '');
        const hEl = document.getElementById('stockH');
        const h1El = document.getElementById('stockH1');
        const h2El = document.getElementById('stockH2');
        const narcoticEl = document.getElementById('stockNarcotic');
        if (hEl) hEl.checked = false;
        if (h1El) h1El.checked = false;
        if (h2El) h2El.checked = false;
        if (narcoticEl) narcoticEl.checked = false;
        if (document.getElementById('batchRowsContainer')) initBatchRows();
    }

    function _setValue(id, val) {
        const el = document.getElementById(id);
        if (el) el.value = val;
    }

    function _hide(id) {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    }

    function _resetFormStyle() {
        const wrapper = document.getElementById('stockFormWrapper');
        wrapper.style.border = '1.5px solid #e2e8f0';
        wrapper.style.background = '#f8f9fa';
        const btn = document.getElementById('btnStockSave');
        btn.textContent = 'Save Item';
        btn.className = 'btn-success';
    }

    function getBatchRowsData() {
        const rows = document.querySelectorAll('#batchRowsContainer .batch-row');
        const batches = [];
        const seenBatches = new Set();
        for (let idx = 0; idx < rows.length; idx++) {
            const row = rows[idx];
            const batchNo = row.querySelector('.batch-no').value.trim();
            const expiry = row.querySelector('.batch-expiry').value.trim();
            const qtyRaw = parseInt(row.querySelector('.batch-qty').value, 10);
            const qty = isNaN(qtyRaw) ? 0 : qtyRaw;
            const stripSizeInp = row.querySelector('.batch-strip-size');
            const stripPriceInp = row.querySelector('.batch-strip-price');
            const stripSize = stripSizeInp.valueAsNumber || 0;
            const stripPrice = stripPriceInp.valueAsNumber;
            if (!batchNo) { UI.showToast('Row ' + (idx + 1) + ': Batch No. daalna zaroori hai!', 'error', 3000); return null; }
            var batchKey = batchNo + '|' + expiry;
            if (seenBatches.has(batchKey)) { UI.showToast('Row ' + (idx + 1) + ': Duplicate batch "' + batchNo + '" with same expiry "' + expiry + '"!', 'error', 3000); return null; }
            seenBatches.add(batchKey);
            if (!expiry) { UI.showToast('Row ' + (idx + 1) + ': Expiry date poori bharein!', 'error', 3000); return null; }
            if (!/^\d{2}\/\d{4}$/.test(expiry)) { UI.showToast('Row ' + (idx + 1) + ': Expiry MM/YYYY format mein bharein!', 'error', 3000); return null; }
            var expMonth = parseInt(expiry.substring(0, 2), 10);
            if (expMonth < 1 || expMonth > 12) { UI.showToast('Row ' + (idx + 1) + ': Expiry ka month 01-12 ke beech hona chahiye!', 'error', 3000); return null; }
            if (qty < 0) { UI.showToast('Row ' + (idx + 1) + ': Quantity 0 ya usse zyada honi chahiye!', 'error', 3000); return null; }
            if (!stripSize || stripSize < 1) { UI.showToast('Row ' + (idx + 1) + ': Strip Size daalna zaroori hai!', 'error', 3000); return null; }
            if (isNaN(stripPrice) || stripPrice <= 0) { UI.showToast('Row ' + (idx + 1) + ': Strip Price sahi daalna zaroori hai!', 'error', 3000); return null; }
            const perPillPrice = parseFloat((stripPrice / stripSize).toFixed(2));
            const existingBatch = _editIdx >= 0 ? AppState.stockData[_editIdx]?.batches?.find(b => b.batch === batchNo && b.expiry === expiry) : null;
            batches.push({ id: existingBatch?.id || Utils.generateId('batch'), batch: batchNo, expiry, qty, stripSize, price: perPillPrice });
        }
        return batches;
    }

    function saveMedicineToInventory() {
        const name = document.getElementById('stockName').value.trim();
        const wholesaler = document.getElementById('stockWholesaler').value.trim();
        const make = document.getElementById('stockMake').value.trim();
        const editIdx = parseInt(document.getElementById('editIndex').value, 10);

        if (!name) { UI.showToast('Medicine naam daalna zaroori hai!', 'error'); document.getElementById('stockName').focus(); return; }
        const batches = getBatchRowsData();
        if (!batches) return;

        if (wholesaler) AppState.addWholesaler(wholesaler);
        if (make) AppState.addMake(make);

        const h = document.getElementById('stockH').checked;
        const h1 = document.getElementById('stockH1').checked;
        const h2 = document.getElementById('stockH2').checked;
        const narcotic = document.getElementById('stockNarcotic').checked;
        const medObj = { name, wholesaler, make, batches, h, h1, h2, narcotic };

        const result = AppState.addOrUpdateMedicine(medObj, editIdx);
        if (result) {
            if (result.merged) UI.showToast(result.name + ' ki duplicate entry merge ho gayi!', 'info');
            else if (result.updated) UI.showToast(result.name + ' updated!', 'success');
            else if (result.batchAdded) UI.showToast(result.name + ' mein nayi batch add ho gayi!', 'success');
            else if (result.saved) UI.showToast(result.name + ' saved!', 'success');
        }

        document.getElementById('editIndex').value = '-1';
        _resetFormStyle();
        _setValue('stockName', '');
        _setValue('stockMake', '');
        _setValue('stockWholesaler', '');
        document.getElementById('stockH').checked = false;
        document.getElementById('stockH1').checked = false;
        document.getElementById('stockH2').checked = false;
        document.getElementById('stockNarcotic').checked = false;
        initBatchRows();
        setTimeout(() => document.getElementById('stockWholesaler').focus(), 50);
        renderStockTable();
        _hide('deleteConfirmBar');
        _editIdx = -1;
        _pendingDeleteIdx = -1;
        if (typeof Notifications !== 'undefined') Notifications.renderPanel();
    }

    function editStockItem(index) {
        const item = AppState.stockData[index];
        _setValue('stockName', item.name);
        _setValue('stockWholesaler', item.wholesaler || '');
        _setValue('stockMake', item.make || '');
        document.getElementById('stockH').checked = !!item.h;
        document.getElementById('stockH1').checked = !!item.h1;
        document.getElementById('stockH2').checked = !!item.h2;
        document.getElementById('stockNarcotic').checked = !!item.narcotic;
        document.getElementById('editIndex').value = String(index);
        _editIdx = index;

        const btn = document.getElementById('btnStockSave');
        btn.textContent = 'Update Details';
        btn.className = 'btn-primary';
        const wrapper = document.getElementById('stockFormWrapper');
        wrapper.style.border = '2px solid #1a56db';
        wrapper.style.background = '#eff6ff';
        _hide('deleteConfirmBar');
        _pendingDeleteIdx = -1;
        initBatchRows(item.batches);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function showMakeSuggestions(str) {
        const box = document.getElementById('makeSuggestions');
        if (str.trim().length < 1) { box.style.display = 'none'; return; }
        const filtered = AppState.makeList.filter(m => m.toLowerCase().includes(str.toLowerCase()));
        Utils.clearElement(box);
        if (!filtered.length) { box.style.display = 'none'; return; }
        filtered.forEach((m, i) => {
            const div = document.createElement('div');
            div.className = 'suggestion-item' + (i === 0 ? ' highlighted' : '');
            div.textContent = m;
            div.addEventListener('click', () => {
                document.getElementById('stockMake').value = m;
                box.style.display = 'none';
                const f = document.querySelector('#batchRowsContainer .batch-row .batch-no');
                if (f) f.focus();
            });
            box.appendChild(div);
        });
        box.style.display = 'block';
    }

    function showWholesalerSuggestions(str) {
        const box = document.getElementById('wholesalerSuggestions');
        if (str.trim().length < 1) { box.style.display = 'none'; return; }
        const filtered = AppState.wholesalerList.filter(w => w.toLowerCase().includes(str.toLowerCase()));
        Utils.clearElement(box);
        if (!filtered.length) { box.style.display = 'none'; return; }
        filtered.forEach((w, i) => {
            const div = document.createElement('div');
            div.className = 'suggestion-item' + (i === 0 ? ' highlighted' : '');
            div.textContent = w;
            div.addEventListener('click', () => {
                document.getElementById('stockWholesaler').value = w;
                box.style.display = 'none';
                document.getElementById('stockName').focus();
            });
            box.appendChild(div);
        });
        box.style.display = 'block';
    }

    function stockNameEnter(e) {
        if (e.key === 'Enter') { e.preventDefault(); document.getElementById('stockMake').focus(); }
        if (e.key === 'ArrowRight' && e.target.selectionStart === e.target.value.length && e.target.selectionEnd === e.target.value.length) { e.preventDefault(); document.getElementById('stockMake').focus(); }
    }

    function makeFieldKeydown(e) {
        const box = document.getElementById('makeSuggestions');
        const items = box.querySelectorAll('.suggestion-item');
        if (box.style.display === 'none' || !items.length) {
            _makeHL = -1;
            if (e.key === 'Enter') { e.preventDefault(); const f = document.querySelector('#batchRowsContainer .batch-row .batch-no'); if (f) f.focus(); }
            return;
        }
        if (e.key === 'ArrowDown') { e.preventDefault(); _makeHL = Math.min(_makeHL + 1, items.length - 1); items.forEach((it, i) => it.classList.toggle('highlighted', i === _makeHL)); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); _makeHL = Math.max(_makeHL - 1, -1); items.forEach((it, i) => it.classList.toggle('highlighted', i === _makeHL)); }
        else if (e.key === 'Enter') { e.preventDefault(); const toClick = (_makeHL >= 0 && items[_makeHL]) ? items[_makeHL] : items[0]; toClick.click(); }
        else if (e.key === 'Escape') { box.style.display = 'none'; _makeHL = -1; }
    }

    function wholesalerFieldKeydown(e) {
        const box = document.getElementById('wholesalerSuggestions');
        const items = box.querySelectorAll('.suggestion-item');
        if (box.style.display === 'none' || !items.length) {
            _wholeHL = -1;
            if (e.key === 'Enter') { e.preventDefault(); document.getElementById('stockName').focus(); }
            return;
        }
        if (e.key === 'ArrowDown') { e.preventDefault(); _wholeHL = Math.min(_wholeHL + 1, items.length - 1); items.forEach((it, i) => it.classList.toggle('highlighted', i === _wholeHL)); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); _wholeHL = Math.max(_wholeHL - 1, -1); items.forEach((it, i) => it.classList.toggle('highlighted', i === _wholeHL)); }
        else if (e.key === 'Enter') { e.preventDefault(); const toClick = (_wholeHL >= 0 && items[_wholeHL]) ? items[_wholeHL] : items[0]; toClick.click(); document.getElementById('stockName').focus(); }
        else if (e.key === 'Escape') { box.style.display = 'none'; _wholeHL = -1; }
    }

    // ==================== STOCK PDF ====================

    function downloadStockPDF() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const dateStr = Utils.getTodayStr();
        const in30 = new Date(today);
        in30.setDate(in30.getDate() + CONFIG.EXPIRY_WARNING_DAYS);

        const filteredData = _getFilteredData();
        let rows = '';
        let sr = 1;
        filteredData.forEach(item => {
            const batchList = (item.batches && item.batches.length)
                ? item.batches
                : [{ batch: '-', expiry: '-', qty: 0, price: 0, _empty: true }];
            batchList.forEach((b, bIdx) => {
                const isLow = (b.qty || 0) < CONFIG.LOW_STOCK_THRESHOLD;
                const exp = Utils.parseExpiry(b.expiry);
                const isExpired = !!(exp && exp < today);
                const isExpiring = !!(exp && !isExpired && exp <= in30);
                const lowStyle = isLow ? 'color:#c62828;font-weight:bold;' : '';
                const expiryStyle = isExpired ? 'color:#c62828;font-weight:bold;' : (isExpiring ? 'color:#b45309;font-weight:bold;' : '');
                rows += '<tr>';
                if (bIdx === 0) {
                    rows += '<td rowspan="' + batchList.length + '" style="vertical-align:middle;font-weight:bold;">' + sr++ + '. ' + Utils.escapeHtml(item.name) + '</td>';
                    rows += '<td rowspan="' + batchList.length + '" style="vertical-align:middle;">' + Utils.escapeHtml(item.wholesaler || '-') + '</td>';
                    rows += '<td rowspan="' + batchList.length + '" style="vertical-align:middle;">' + Utils.escapeHtml(item.make || '-') + '</td>';
                }
                rows += '<td>' + Utils.escapeHtml(b.batch) + '</td>';
                rows += '<td style="' + expiryStyle + '">' + Utils.escapeHtml(b.expiry) + (isExpired ? ' ✕' : (isExpiring ? ' ⚠' : '')) + '</td>';
                rows += '<td style="text-align:right;' + lowStyle + '">' + (b.qty || 0) + (isLow ? ' ⚠' : '') + '</td>';
                rows += '<td style="text-align:right;">₹' + Number(b.price || 0).toFixed(2) + '</td>';
                rows += '</tr>';
            });
        });

        const totalMeds = filteredData.length;
        const totalBatches = filteredData.reduce((s, i) => s + ((i.batches && i.batches.length) || 0), 0);
        const totalItems = filteredData.reduce((s, i) => ((i.batches || []).reduce((ss, b) => ss + (Number(b.qty) || 0), 0) + s), 0);
        const lowStock = filteredData.reduce((s, i) => {
            var bs = Array.isArray(i.batches) ? i.batches : [];
            if (!bs.length) return s + (CONFIG.LOW_STOCK_THRESHOLD > 0 ? 1 : 0);
            return s + bs.filter(b => (Number(b.qty) || 0) < CONFIG.LOW_STOCK_THRESHOLD).length;
        }, 0);
        const expiring = filteredData.reduce((s, i) => s + (i.batches || []).filter(b => { const e = Utils.parseExpiry(b.expiry); return e && e >= today && e <= in30; }).length, 0);

        const info = CONFIG.STORE_INFO;
        const html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>' +
            'body{font-family:Arial,sans-serif;margin:0;padding:20px;color:#222;font-size:13px;}' +
            '.header{text-align:center;border-bottom:2px solid #1a237e;padding-bottom:10px;margin-bottom:16px;}' +
            '.header h1{margin:0;font-size:17px;color:#1a237e;}' +
            '.header p{margin:3px 0;font-size:11px;color:#555;}' +
            '.report-title{text-align:center;font-size:14px;font-weight:bold;margin:10px 0 2px 0;color:#1a237e;}' +
            '.report-date{text-align:center;font-size:11px;color:#777;margin-bottom:14px;}' +
            '.summary{display:flex;gap:14px;margin-bottom:16px;}' +
            '.summary-box{flex:1;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;}' +
            '.summary-box .val{font-size:20px;font-weight:bold;color:#1565c0;}' +
            '.summary-box .lbl{font-size:10px;color:#888;margin-top:2px;}' +
            '.summary-box.red .val{color:#c62828;}' +
            '.summary-box.amber .val{color:#b45309;}' +
            'table{width:100%;border-collapse:collapse;}' +
            'th{background:#1a237e;color:white;padding:8px 10px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;}' +
            'td{border:1px solid #e0e0e0;padding:7px 10px;}' +
            'tr:nth-child(even) td{background:#f5f5f5;}' +
            '.footer{margin-top:18px;text-align:right;font-size:10px;color:#aaa;border-top:1px solid #eee;padding-top:8px;}' +
            '.legend{font-size:10px;color:#888;margin-bottom:10px;}' +
            '</style></head><body>' +
            '<div class="header"><h1>' + Utils.escapeHtml(info.name) + '</h1><p>' + Utils.escapeHtml(info.address) + ' | Mob: ' + info.mob + '</p><p>D.L. No: ' + info.dlNo + ' | FOOD Re.No: ' + info.fssai + '</p></div>' +
            '<div class="report-title">STOCK INVENTORY REPORT</div>' +
            '<div class="report-date">Generated on: ' + dateStr + '</div>' +
            '<div class="summary">' +
            '<div class="summary-box"><div class="val">' + totalMeds + '</div><div class="lbl">Total Medicines</div></div>' +
            '<div class="summary-box"><div class="val">' + totalBatches + '</div><div class="lbl">Total Batches</div></div>' +
            '<div class="summary-box"><div class="val">' + totalItems + '</div><div class="lbl">Total Units</div></div>' +
            '<div class="summary-box red"><div class="val">' + lowStock + '</div><div class="lbl">Low Stock (<' + CONFIG.LOW_STOCK_THRESHOLD + ')</div></div>' +
            '<div class="summary-box amber"><div class="val">' + expiring + '</div><div class="lbl">Expiring in ' + CONFIG.EXPIRY_WARNING_DAYS + ' Days</div></div>' +
            '</div>' +
            '<div class="legend">⚠ = Low Stock or Expiring Soon</div>' +
            '<table><thead><tr><th style="width:23%;">Medicine Name</th><th>Wholesaler</th><th>MAKE</th><th>Batch No</th><th>Expiry Date</th><th style="text-align:right;">Qty</th><th style="text-align:right;">Price (₹)</th></tr></thead><tbody>' + rows + '</tbody></table>' +
            '<div class="footer">Report by Ramdevbaba Medical Store | ' + dateStr + '</div>' +
            '</body></html>';

        _openPrintWindow(html);
    }

    function downloadStockExcel() {
        const filteredData = _getFilteredData();
        if (!filteredData.length) { UI.showToast('Koi medicine nahi mila export karne ke liye!', 'warn'); return; }
        const dateStr = Utils.getTodayStr().replace(/\//g, '-');

        const header = ['Sr', 'Medicine Name', 'Wholesaler', 'MAKE', 'Batch No', 'Expiry Date', 'Qty', 'Price (Rs)', 'Value (Rs)'];
        const aoa = [header];
        let sr = 1;
        let totalQty = 0;
        let totalValue = 0;
        filteredData.forEach(item => {
            const batchList = (item.batches && item.batches.length)
                ? item.batches
                : [{ batch: '-', expiry: '-', qty: 0, price: 0, _empty: true }];
            batchList.forEach(b => {
                const value = (b.qty || 0) * (b.price || 0);
                totalQty += (b.qty || 0);
                totalValue += value;
                aoa.push([
                    sr++,
                    item.name || '',
                    item.wholesaler || '-',
                    item.make || '-',
                    b.batch || '',
                    b.expiry || '',
                    b.qty || 0,
                    Number((b.price || 0).toFixed(2)),
                    Number(value.toFixed(2))
                ]);
            });
        });
        aoa.push(['', '', '', '', '', 'TOTAL', totalQty, '', Number(totalValue.toFixed(2))]);

        const filename = 'ramdevbaba_stock_' + dateStr;
        try {
            if (typeof XLSX !== 'undefined' && XLSX.utils && XLSX.writeFile) {
                const ws = XLSX.utils.aoa_to_sheet(aoa);
                ws['!cols'] = [{ wch: 5 }, { wch: 28 }, { wch: 20 }, { wch: 16 }, { wch: 14 }, { wch: 12 }, { wch: 8 }, { wch: 12 }, { wch: 13 }];
                const wb = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, 'Stock');
                XLSX.writeFile(wb, filename + '.xlsx');
                UI.showToast('Excel download ho raha hai!', 'info');
                return;
            }
        } catch (e) {
            console.warn('XLSX export failed, fallback to HTML table:', e);
        }

        let rows = '';
        aoa.forEach((r, idx) => {
            rows += '<tr>';
            r.forEach(c => {
                const tag = idx === 0 ? 'th' : 'td';
                rows += '<' + tag + '>' + Utils.escapeHtml(String(c)) + '</' + tag + '>';
            });
            rows += '</tr>';
        });
        const table = '<table border="1" cellpadding="5" cellspacing="0" style="font-family:Arial;font-size:12px;border-collapse:collapse;width:100%;">' + rows + '</table>';
        const fullHtml = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>' + table + '</body></html>';
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([fullHtml], { type: 'application/vnd.ms-excel;charset=utf-8' }));
        a.download = filename + '.xls';
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
        UI.showToast('Excel download ho raha hai!', 'info');
    }

    function _openPrintWindow(html) {
        const printWindow = window.open('', '_blank');
        if (!printWindow) {
            UI.showToast('Popup blocker! PDF ke liye popup allow karo.', 'error');
            return;
        }
        printWindow.document.write(html);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => { try { printWindow.print(); } catch (e) { UI.showToast('Print error!', 'error'); } }, 500);
    }

    // ==================== PURCHASE BILL IMPORT ====================

    let _pbPharma = '';
    let _pbFileHeaders = [];
    let _pbFileData = [];
    let _pbMapping = {};
    let _pbPreviewItems = [];
    const INVENTORY_FIELDS = [
        { value: 'batch', label: 'BATCH NO' },
        { value: 'make', label: 'MAKE' },
        { value: 'medicineName', label: 'MEDICINE NAME' },
        { value: 'expiry', label: 'EXPIRY' },
        { value: 'mrp', label: 'MRP' },
        { value: '', label: '— Skip —' }
    ];

    const AUTO_MAP_RULES = [
        { re: /batch\s*no|batch\s*number|batch|batchno|batch_no|lot/i, field: 'batch' },
        { re: /make|brand|company|manufacturer|mfg\s*by/i, field: 'make' },
        { re: /medicine|med\s*name|product|item\s*name|particular|description|dawa/i, field: 'medicineName' },
        { re: /expir|exp\s*date|expiry\s*date|exp_date|expiry/i, field: 'expiry' },
        { re: /mrp|price|rate|cost|amount|rs|value/i, field: 'mrp' }
    ];

    function openPurchaseBillImport() {
        _pbPharma = '';
        _pbFileHeaders = [];
        _pbFileData = [];
        _pbMapping = {};
        document.getElementById('pbPharmaName').value = '';
        document.getElementById('pbSelectedPharma').textContent = '';
        document.getElementById('pbFileName').style.display = 'none';
        document.getElementById('pbFileName').textContent = '';
        document.getElementById('pbPreviewBody').innerHTML = '';
        document.getElementById('pbPreviewCount').textContent = '0';
        document.getElementById('pbImportStep1').style.display = 'block';
        document.getElementById('pbImportStep2').style.display = 'none';
        document.getElementById('pbImportStep3').style.display = 'none';
        document.getElementById('pbImportStep4').style.display = 'none';
        document.getElementById('pbColumnMapping').innerHTML = '';
        document.getElementById('purchaseBillFileInput').value = '';
        document.getElementById('pbBtnParse').disabled = true;
        document.getElementById('stockSection').style.display = 'none';
        document.getElementById('purchaseBillImportSection').style.display = 'block';
        setTimeout(() => document.getElementById('pbPharmaName').focus(), 50);
    }

    function closePurchaseBillImport() {
        document.getElementById('purchaseBillImportSection').style.display = 'none';
        document.getElementById('stockSection').style.display = 'block';
    }

    function pbPharmaSuggest(str) {
        const box = document.getElementById('pbPharmaSuggestions');
        if (str.trim().length < 1) { box.style.display = 'none'; return; }
        const fromStock = new Set();
        AppState.stockData.forEach(item => { if (item.wholesaler) fromStock.add(item.wholesaler); });
        const allNames = Array.from(new Set([...AppState.wholesalerList, ...fromStock]));
        const q = str.toLowerCase();
        const exact = allNames.filter(w => w.toLowerCase() === q);
        const startsWith = allNames.filter(w => w.toLowerCase() !== q && w.toLowerCase().startsWith(q));
        const includes = allNames.filter(w => w.toLowerCase() !== q && !w.toLowerCase().startsWith(q) && w.toLowerCase().includes(q));
        const filtered = [...exact, ...startsWith, ...includes];
        Utils.clearElement(box);
        if (!filtered.length) { box.style.display = 'none'; return; }
        filtered.forEach((w, i) => {
            const div = document.createElement('div');
            div.className = 'suggestion-item' + (i === 0 ? ' highlighted' : '');
            div.textContent = w;
            div.addEventListener('click', () => {
                document.getElementById('pbPharmaName').value = w;
                box.style.display = 'none';
            });
            box.appendChild(div);
        });
        box.style.display = 'block';
    }

    function pbPharmaKeydown(e) {
        const box = document.getElementById('pbPharmaSuggestions');
        const items = box.querySelectorAll('.suggestion-item');
        if (box.style.display === 'none' || !items.length) {
            if (e.key === 'Enter') { e.preventDefault(); pbStep1Next(); }
            return;
        }
        let hl = Array.from(items).findIndex(it => it.classList.contains('highlighted'));
        if (e.key === 'ArrowDown') { e.preventDefault(); hl = Math.min(hl + 1, items.length - 1); items.forEach((it, i) => it.classList.toggle('highlighted', i === hl)); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); hl = Math.max(hl - 1, -1); items.forEach((it, i) => it.classList.toggle('highlighted', i === hl)); }
        else if (e.key === 'Enter') { e.preventDefault(); const toClick = (hl >= 0 && items[hl]) ? items[hl] : items[0]; toClick.click(); pbStep1Next(); }
        else if (e.key === 'Escape') { box.style.display = 'none'; }
    }

    function pbStep1Next() {
        const name = document.getElementById('pbPharmaName').value.trim();
        if (!name) { UI.showToast('Pharma company naam daalna zaroori hai!', 'error'); document.getElementById('pbPharmaName').focus(); return; }
        _pbPharma = name;
        document.getElementById('pbSelectedPharma').textContent = name;
        document.getElementById('pbImportStep1').style.display = 'none';
        document.getElementById('pbImportStep2').style.display = 'block';
        document.getElementById('pbPharmaSuggestions').style.display = 'none';
    }

    function pbBackToStep1() {
        document.getElementById('pbImportStep2').style.display = 'none';
        document.getElementById('pbImportStep1').style.display = 'block';
    }

    function pbBackToStep2() {
        document.getElementById('pbImportStep3').style.display = 'none';
        document.getElementById('pbImportStep2').style.display = 'block';
    }

    function pbBackToStep3() {
        document.getElementById('pbImportStep4').style.display = 'none';
        document.getElementById('pbImportStep3').style.display = 'block';
    }

    // file input change — set up by app.js or inline
    function pbResetFileInput() {
        _pbFileData = [];
        _pbFileHeaders = [];
        _pbMapping = {};
        document.getElementById('pbColumnMapping').innerHTML = '';
        document.getElementById('pbPreviewBody').innerHTML = '';
        document.getElementById('pbPreviewCount').textContent = '0';
    }

    function pbParseFile() {
        const inp = document.getElementById('purchaseBillFileInput');
        const file = inp.files[0];
        if (!file) { UI.showToast('Pehle file select karo!', 'error'); return; }

        const reader = new FileReader();
        const name = file.name.toLowerCase();

        reader.onload = function (e) {
            try {
                let headers = [];
                let rows = [];

                if (name.endsWith('.csv')) {
                    const text = e.target.result;
                    const lines = text.split(/\r?\n/).filter(l => l.trim());
                    if (!lines.length) { UI.showToast('File empty hai!', 'error'); return; }
                    headers = _parseCSVLine(lines[0]);
                    for (let i = 1; i < lines.length; i++) {
                        const vals = _parseCSVLine(lines[i]);
                        if (vals.some(v => v.trim())) rows.push(vals);
                    }
                } else if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
                    const data = new Uint8Array(e.target.result);
                    // cellDates:true — Excel date cells ko serial number (e.g. 46023)
                    // ki jagah asli Date object mein laata hai.
                    const workbook = XLSX.read(data, { type: 'array', cellDates: true });
                    const sheet = workbook.Sheets[workbook.SheetNames[0]];
                    const json = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true });
                    if (!json.length) { UI.showToast('File empty hai!', 'error'); return; }
                    headers = json[0].map(h => String(h || ''));
                    for (let i = 1; i < json.length; i++) {
                        const vals = json[i].map(v => {
                            if (v === undefined || v === null) return '';
                            if (v instanceof Date && !isNaN(v.getTime())) {
                                return String(v.getMonth() + 1).padStart(2, '0') + '/' + v.getFullYear();
                            }
                            return String(v);
                        });
                        if (vals.some(v => v.trim())) rows.push(vals);
                    }
                } else {
                    UI.showToast('Sirf .csv, .xlsx, .xls files support hain!', 'error');
                    return;
                }

                if (!headers.length) { UI.showToast('File mein koi column nahi mila!', 'error'); return; }
                if (!rows.length) { UI.showToast('File mein koi data nahi mila!', 'error'); return; }

                _pbFileHeaders = headers;
                _pbFileData = rows;

                // auto-detect mapping
                _pbMapping = {};
                const used = new Set();
                headers.forEach((h, idx) => {
                    let matched = false;
                    for (const rule of AUTO_MAP_RULES) {
                        if (rule.re.test(h) && !used.has(rule.field)) {
                            _pbMapping[idx] = rule.field;
                            used.add(rule.field);
                            matched = true;
                            break;
                        }
                    }
                    if (!matched) _pbMapping[idx] = '';
                });

                _renderColumnMapping();
                document.getElementById('pbImportStep2').style.display = 'none';
                document.getElementById('pbImportStep3').style.display = 'block';
            } catch (err) {
                UI.showToast('File parse karte waqt error: ' + err.message, 'error');
                console.error('Parse error:', err);
            }
        };

        if (name.endsWith('.csv')) {
            reader.readAsText(file);
        } else {
            reader.readAsArrayBuffer(file);
        }
    }

    function _parseCSVLine(line) {
        const result = [];
        let current = '';
        let inQuotes = false;
        for (let i = 0; i < line.length; i++) {
            const ch = line[i];
            if (inQuotes) {
                if (ch === '"') {
                    if (i + 1 < line.length && line[i + 1] === '"') {
                        current += '"';
                        i++;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    current += ch;
                }
            } else {
                if (ch === '"') {
                    inQuotes = true;
                } else if (ch === ',') {
                    result.push(current.trim());
                    current = '';
                } else {
                    current += ch;
                }
            }
        }
        result.push(current.trim());
        return result;
    }

    function _renderColumnMapping() {
        const container = document.getElementById('pbColumnMapping');
        Utils.clearElement(container);

        _pbFileHeaders.forEach((h, idx) => {
            const div = document.createElement('div');
            div.style.cssText = 'display:flex;align-items:center;gap:12px;margin-bottom:8px;padding:8px 12px;background:#f8f9fa;border-radius:6px;';

            const sr = document.createElement('span');
            sr.style.cssText = 'font-size:11px;color:#9ca3af;font-weight:700;min-width:22px;text-align:right;';
            sr.textContent = (idx + 1) + '.';
            div.appendChild(sr);

            const label = document.createElement('span');
            label.style.cssText = 'font-weight:600;font-size:13px;color:#374151;min-width:220px;';
            label.textContent = '📄 ' + h;
            div.appendChild(label);

            const arrow = document.createElement('span');
            arrow.textContent = '→';
            arrow.style.cssText = 'color:#9ca3af;font-weight:700;';
            div.appendChild(arrow);

            const select = document.createElement('select');
            select.style.cssText = 'min-width:200px;padding:8px 12px;border:1.5px solid #d1d9e0;border-radius:6px;font-size:13px;background:white;';
            select.dataset.colIdx = idx;

            INVENTORY_FIELDS.forEach(f => {
                const opt = document.createElement('option');
                opt.value = f.value;
                opt.textContent = f.label;
                if (f.value === _pbMapping[idx]) opt.selected = true;
                select.appendChild(opt);
            });

            select.addEventListener('change', function () {
                _pbMapping[idx] = this.value;
            });

            div.appendChild(select);
            container.appendChild(div);
        });
    }

    function pbShowPreview() {
        const usedFields = Object.values(_pbMapping).filter(v => v);
        if (!usedFields.includes('medicineName')) { UI.showToast('Medicine Name column map karna zaroori hai!', 'error'); return; }

        const items = [];
        _pbFileData.forEach((row, rowIdx) => {
            const medName = row[_pbFileHeaders.findIndex((h, i) => _pbMapping[i] === 'medicineName')];
            const batch = row[_pbFileHeaders.findIndex((h, i) => _pbMapping[i] === 'batch')] || '';
            const expiry = row[_pbFileHeaders.findIndex((h, i) => _pbMapping[i] === 'expiry')] || '';
            const mrp = parseFloat(row[_pbFileHeaders.findIndex((h, i) => _pbMapping[i] === 'mrp')]) || 0;
            const make = row[_pbFileHeaders.findIndex((h, i) => _pbMapping[i] === 'make')] || '';

            if (!medName || !medName.trim()) return;

            items.push({
                _rowIdx: rowIdx,
                name: medName.trim(),
                batch: batch.trim(),
                expiry: _formatImportExpiry(expiry.trim()),
                make: make.trim(),
                qty: 0,
                stripSize: 0,
                stripPrice: mrp,
                h1: false
            });
        });

        if (!items.length) { UI.showToast('Koi valid medicine data nahi mila!', 'error'); return; }

        _pbPreviewItems = items;
        _renderPreviewTableBody();
        _setupPreviewNav();

        document.getElementById('pbImportStep3').style.display = 'none';
        document.getElementById('pbImportStep4').style.display = 'block';
    }

    function _renderPreviewTableBody() {
        const items = _pbPreviewItems;
        const tbody = document.getElementById('pbPreviewBody');
        Utils.clearElement(tbody);
        document.getElementById('pbPreviewCount').textContent = items.length;

        items.forEach((item, idx) => {
            const tr = document.createElement('tr');

            function _makeInput(type, val, opts, onChange, colIdx) {
                const inp = document.createElement('input');
                inp.type = type;
                inp.value = val;
                if (opts) Object.assign(inp, opts);
                inp.style.cssText = 'width:100%;padding:3px 5px;border:1px solid #d1d9e0;border-radius:4px;font-size:12px;box-sizing:border-box;' + (opts?.style || '');
                inp.dataset.col = colIdx;
                inp.addEventListener('input', onChange);
                return inp;
            }

            // #
            tr.appendChild(Utils.createElement('td', { style: 'text-align:center;color:#9ca3af;font-weight:600;', innerText: String(idx + 1) }));

            // name (editable)
            const tdName = document.createElement('td');
            tdName.appendChild(_makeInput('text', item.name, {}, function () { items[idx].name = this.value; }, 1));
            tr.appendChild(tdName);

            // make (editable)
            const tdMake = document.createElement('td');
            tdMake.appendChild(_makeInput('text', item.make || '', { placeholder: '-' }, function () { items[idx].make = this.value; }, 2));
            tr.appendChild(tdMake);

            // batch (editable)
            const tdBatch = document.createElement('td');
            tdBatch.appendChild(_makeInput('text', item.batch || '', { placeholder: '-' }, function () { items[idx].batch = this.value; }, 3));
            tr.appendChild(tdBatch);

            // expiry (editable)
            const tdExpiry = document.createElement('td');
            const expiryInp = _makeInput('text', item.expiry || '', { placeholder: 'MM/YYYY', maxLength: 7 }, function () { items[idx].expiry = this.value; }, 4);
            expiryInp.addEventListener('input', function () { Utils.formatAndValidateExpiry(this); });
            tdExpiry.appendChild(expiryInp);
            tr.appendChild(tdExpiry);

            // Qty (manual entry) — starts empty
            const tdQty = document.createElement('td');
            tdQty.style.cssText = 'text-align:right;';
            tdQty.appendChild(_makeInput('number', '', { min: 0, style: 'width:55px;text-align:right;', placeholder: '0' }, function () {
                items[idx].qty = parseInt(this.value, 10) || 0;
            }, 5));
            tr.appendChild(tdQty);

            // Strip Size (manual entry)
            const tdStripSize = document.createElement('td');
            tdStripSize.style.cssText = 'text-align:right;';
            const ssInp = _makeInput('number', item.stripSize > 0 ? String(item.stripSize) : '', { min: 0, style: 'width:50px;text-align:right;', placeholder: '0' }, function () {
                items[idx].stripSize = parseInt(this.value, 10) || 0;
                _updateRowDisplay();
            }, 6);
            tdStripSize.appendChild(ssInp);
            tr.appendChild(tdStripSize);

            // MRP / Strip Price (manual entry)
            const tdStripPrice = document.createElement('td');
            tdStripPrice.style.cssText = 'text-align:right;';
            const spInp = _makeInput('number', item.stripPrice > 0 ? String(item.stripPrice) : '', { min: 0, step: 0.01, style: 'width:70px;text-align:right;', placeholder: '0' }, function () {
                items[idx].stripPrice = parseFloat(this.value) || 0;
                _updateRowDisplay();
            }, 7);
            tdStripPrice.appendChild(spInp);
            tr.appendChild(tdStripPrice);

            // Per Pill (auto-calc)
            const perPillCell = document.createElement('td');
            perPillCell.style.cssText = 'text-align:right;color:#166534;font-weight:700;font-size:13px;';
            tr.appendChild(perPillCell);

            function _updateRowDisplay() {
                const pp = item.stripSize > 0 ? item.stripPrice / item.stripSize : 0;
                perPillCell.textContent = pp > 0 ? '₹' + pp.toFixed(2) : '-';
            }
            _updateRowDisplay();

            // H1 tick (Schedule H1)
            const tdH1 = document.createElement('td');
            tdH1.style.cssText = 'text-align:center;';
            const h1Chk = document.createElement('input');
            h1Chk.type = 'checkbox';
            h1Chk.checked = !!item.h1;
            h1Chk.dataset.col = 8;
            h1Chk.style.cssText = 'width:16px;height:16px;cursor:pointer;accent-color:#d97706;';
            h1Chk.addEventListener('change', function () { items[idx].h1 = this.checked; });
            tdH1.appendChild(h1Chk);
            tr.appendChild(tdH1);

            // Delete button
            const tdAction = document.createElement('td');
            tdAction.style.cssText = 'text-align:center;';
            const delBtn = document.createElement('button');
            delBtn.textContent = '✕';
            delBtn.style.cssText = 'padding:2px 8px;font-size:12px;border:none;border-radius:4px;background:#fee2e2;color:#dc2626;cursor:pointer;font-weight:700;';
            delBtn.addEventListener('click', function () {
                items.splice(idx, 1);
                _renderPreviewTableBody();
            });
            tdAction.appendChild(delBtn);
            tr.appendChild(tdAction);

            tbody.appendChild(tr);
        });

        // Add row button
        const addRowTr = document.createElement('tr');
        const addRowTd = document.createElement('td');
        addRowTd.colSpan = 11;
        addRowTd.style.cssText = 'text-align:center;padding:8px;';
        const addBtn = document.createElement('button');
        addBtn.textContent = '➕ Add Row';
        addBtn.style.cssText = 'padding:6px 18px;font-size:13px;border:none;border-radius:6px;background:#22c55e;color:white;font-weight:700;cursor:pointer;';
        addBtn.addEventListener('click', function () {
            items.push({ _rowIdx: -1, name: '', batch: '', expiry: '', make: '', qty: 0, stripSize: 0, stripPrice: 0, h1: false });
            _renderPreviewTableBody();
        });
        addRowTd.appendChild(addBtn);
        addRowTr.appendChild(addRowTd);
        tbody.appendChild(addRowTr);
    }

    function _setupPreviewNav() {
        const tbody = document.getElementById('pbPreviewBody');
        if (tbody._navSetup) return;
        tbody._navSetup = true;
        tbody.addEventListener('keydown', function (e) {
            const tgt = e.target;
            if (tgt.tagName !== 'INPUT') return;
            const key = e.key;
            if (!['Enter', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(key)) return;
            e.preventDefault();

            if (tgt.type === 'checkbox' && key === 'Enter') {
                tgt.checked = !tgt.checked;
                tgt.dispatchEvent(new Event('change'));
                return;
            }

            const tr = tgt.closest('tr');
            if (!tr) return;
            const allRows = Array.from(tbody.querySelectorAll('tr'));
            const rowIdx = allRows.indexOf(tr);

            const inputs = tr.querySelectorAll('input');
            const curIdx = Array.from(inputs).indexOf(tgt);
            if (curIdx < 0) return;

            if (key === 'Enter' || key === 'ArrowRight') {
                const next = inputs[curIdx + 1];
                if (next) next.focus();
                else if (rowIdx < allRows.length - 1) {
                    const nextRow = allRows[rowIdx + 1];
                    const nextInputs = nextRow.querySelectorAll('input');
                    if (nextInputs.length) nextInputs[0].focus();
                }
            } else if (key === 'ArrowLeft') {
                const prev = inputs[curIdx - 1];
                if (prev) prev.focus();
                else if (rowIdx > 0) {
                    const prevRow = allRows[rowIdx - 1];
                    const prevInputs = prevRow.querySelectorAll('input');
                    if (prevInputs.length) prevInputs[prevInputs.length - 1].focus();
                }
            } else if (key === 'ArrowDown') {
                const targetCol = tgt.dataset.col;
                if (rowIdx < allRows.length - 1) {
                    const nextRow = allRows[rowIdx + 1];
                    const candidates = nextRow.querySelectorAll('input[data-col="' + targetCol + '"]');
                    if (candidates.length) candidates[0].focus();
                }
            } else if (key === 'ArrowUp') {
                const targetCol = tgt.dataset.col;
                if (rowIdx > 0) {
                    const prevRow = allRows[rowIdx - 1];
                    const candidates = prevRow.querySelectorAll('input[data-col="' + targetCol + '"]');
                    if (candidates.length) candidates[0].focus();
                }
            }
        });
    }

    function _formatImportExpiry(exp) {
        if (exp === undefined || exp === null) return '';
        exp = String(exp).trim();
        if (!exp) return '';
        var mm, yyyy;

        // Already MM/YYYY
        var m1 = /^(\d{1,2})\s*[\/\-.]\s*(\d{4})$/.exec(exp);
        if (m1) {
            mm = parseInt(m1[1], 10); yyyy = parseInt(m1[2], 10);
            return (mm >= 1 && mm <= 12 && yyyy >= 1900 && yyyy <= 2200) ? String(mm).padStart(2, '0') + '/' + yyyy : '';
        }
        // YYYY-MM / YYYY/MM
        var m2 = /^(\d{4})\s*[\/\-.]\s*(\d{1,2})$/.exec(exp);
        if (m2) {
            yyyy = parseInt(m2[1], 10); mm = parseInt(m2[2], 10);
            return (mm >= 1 && mm <= 12 && yyyy >= 1900 && yyyy <= 2200) ? String(mm).padStart(2, '0') + '/' + yyyy : '';
        }
        // Pure digits: Excel serial (e.g. 46023), MYYYY (e.g. 22027 = 02/2027),
        // MMYYYY (e.g. 012026) ya YYYYMM (202601)
        var digits = exp.replace(/\D/g, '');
        // 5-digit MYYYY pehle check karo. Excel date cells cellDates:true se
        // Date object ban jaate hain, isliye raw 5-digit number zyadatar
        // month-year hi hota hai (Feb 2027 -> 22027, warna 1960 ban jata tha).
        if (digits.length === 5) {
            var m5 = parseInt(digits.charAt(0), 10);
            var y5 = parseInt(digits.substring(1), 10);
            if (m5 >= 1 && m5 <= 9 && y5 >= 1990 && y5 <= 2099) {
                return '0' + m5 + '/' + y5;
            }
        }
        if (/^\d+(\.\d+)?$/.test(exp) && digits.length >= 4 && digits.length <= 5) {
            var serial = parseFloat(exp);
            if (serial > 20000 && serial < 80000) {
                // Excel epoch = 1899-12-30
                var d = new Date(Date.UTC(1899, 11, 30) + Math.round(serial) * 86400000);
                if (!isNaN(d.getTime())) {
                    return String(d.getUTCMonth() + 1).padStart(2, '0') + '/' + d.getUTCFullYear();
                }
            }
        }
        if (digits.length === 6) {
            var a = parseInt(digits.substring(0, 2), 10);
            var b = parseInt(digits.substring(2, 6), 10);
            if (a >= 1 && a <= 12) return digits.substring(0, 2) + '/' + digits.substring(2, 6); // MMYYYY
            var y = parseInt(digits.substring(0, 4), 10);
            var mo = parseInt(digits.substring(4, 6), 10);
            if (mo >= 1 && mo <= 12 && y >= 1900) return digits.substring(4, 6) + '/' + digits.substring(0, 4); // YYYYMM
        }
        // General date string (e.g. "Jan 2026", "01 Jan 2026", ISO date)
        var d2 = new Date(exp);
        if (!isNaN(d2.getTime())) {
            return String(d2.getMonth() + 1).padStart(2, '0') + '/' + d2.getFullYear();
        }
        return '';
    }

    async function pbSaveToInventory() {
        if (!_pbPreviewItems || !_pbPreviewItems.length) { UI.showToast('Save karne ke liye kuch nahi hai!', 'error'); return; }

        var allIssues = [];
        _pbPreviewItems.forEach(function (item, idx) {
            var rowIssues = [];
            if (!item.name) rowIssues.push('naam missing');
            if (!item.batch) rowIssues.push('batch missing');
            if (!item.expiry || !/^\d{2}\/\d{4}$/.test(item.expiry)) rowIssues.push('expiry missing/invalid (MM/YYYY)');
            if (!item.qty || item.qty <= 0) rowIssues.push('qty missing');
            if (!item.stripSize || item.stripSize <= 0) rowIssues.push('strip size missing');
            if (!item.stripPrice || item.stripPrice <= 0) rowIssues.push('strip price missing');
            if (rowIssues.length) allIssues.push('Row ' + (idx + 1) + ' (' + (item.name || 'unnamed') + '): ' + rowIssues.join(', '));
        });

        if (allIssues.length) {
            UI.showToast('❌ Pehle saari entries poori bharein!', 'error', 3000);
            alert('Neeche di gayi rows mein data adhoora hai. Pehle sab kuch bharein:\n\n' + allIssues.join('\n'));
            return;
        }

        if (_pbPharma) AppState.addWholesaler(_pbPharma);

        var saved = 0;
        var merged = 0;

        _pbPreviewItems.forEach(function (item) {
            var perPillPrice = item.stripPrice / item.stripSize;
            var medObj = {
                name: item.name,
                wholesaler: _pbPharma,
                make: item.make || '',
                batches: [{
                    batch: item.batch,
                    expiry: item.expiry,
                    qty: item.qty,
                    price: perPillPrice,
                    stripSize: item.stripSize
                }],
                h: false, h1: !!item.h1, h2: false, narcotic: false
            };

            if (item.make) AppState.addMake(item.make);

            var result = AppState.addOrUpdateMedicine(medObj, -1);
            if (result) {
                if (result.merged || result.batchAdded) merged++;
                else if (result.saved) saved++;
            }
        });

        var saveRes = await AppState.saveStock();
        renderStockTable();
        if (typeof Notifications !== 'undefined') Notifications.renderPanel();
        var saveOk = !!(saveRes && saveRes.ok);

        // auto-save CSV bill to PurchaseModule
        try {
            var csvRows = [['Medicine Name', 'Make', 'Batch No', 'Expiry', 'Qty', 'Strip Size', 'MRP', 'Per Pill Price']];
            _pbPreviewItems.forEach(function (it) {
                csvRows.push([
                    '"' + (it.name || '').replace(/"/g, '""') + '"',
                    '"' + (it.make || '').replace(/"/g, '""') + '"',
                    '"' + (it.batch || '').replace(/"/g, '""') + '"',
                    it.expiry || '',
                    it.qty || 0,
                    it.stripSize || 0,
                    (it.stripPrice || 0).toFixed(2),
                    (it.stripSize > 0 ? (it.stripPrice / it.stripSize).toFixed(2) : '0.00')
                ]);
            });
            var csvStr = csvRows.map(function (r) { return r.join(','); }).join('\r\n');
            var csvDataUrl = 'data:text/csv;base64,' + btoa(unescape(encodeURIComponent(csvStr)));
            var today = new Date();
            var dateStr = String(today.getDate()).padStart(2, '0') + '/' + String(today.getMonth() + 1).padStart(2, '0') + '/' + today.getFullYear();
            PurchaseModule.saveBill({
                id: Utils.generateId('pch'),
                pharmaName: _pbPharma || 'Unknown',
                fileName: 'purchase_' + today.getFullYear() + String(today.getMonth() + 1).padStart(2, '0') + String(today.getDate()).padStart(2, '0') + '_' + Date.now() + '.csv',
                fileType: 'csv',
                fileData: csvDataUrl,
                date: dateStr,
                addedAt: Date.now()
            });
        } catch (e) {
            console.warn('Auto-save purchase bill CSV failed:', e);
        }

        if (saveOk) {
            UI.showToast('✅ ' + saved + ' nayi medicine(s) saved, ' + merged + ' merge/updated', 'success', 4000);
        } else {
            UI.showToast('⚠️ Data memory mein hai par save nahi hua — turant Offline Backup download karein!', 'error', 9000);
        }
        closePurchaseBillImport();
    }

    // ==================== END PURCHASE BILL IMPORT ====================

    return {
        renderStockTable,
        filterStockTable,
        initBatchRows,
        addNewBatchRow,
        batchRowEnter,
        batchRowStripPriceEnter,
        deleteBatchRow,
        confirmDeleteMedicine,
        cancelDeleteMedicine,
        getBatchRowsData,
        saveMedicineToInventory,
        editStockItem,
        showMakeSuggestions,
        showWholesalerSuggestions,
        stockNameEnter,
        makeFieldKeydown,
        wholesalerFieldKeydown,
        downloadStockPDF,
        downloadStockExcel,
        _updatePerPillHint,
        openPrintWindow: _openPrintWindow,
        resetEditState,
        openPurchaseBillImport,
        closePurchaseBillImport,
        pbPharmaSuggest,
        pbPharmaKeydown,
        pbStep1Next,
        pbBackToStep1,
        pbBackToStep2,
        pbBackToStep3,
        pbParseFile,
        pbShowPreview,
        pbSaveToInventory,
        pbResetFileInput
    };
})();
