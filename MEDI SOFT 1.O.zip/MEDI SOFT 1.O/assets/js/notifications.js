const Notifications = (() => {
    const LS_DISMISSED = 'rb_notif_dismissed';
    const LS_LAST_BACKUP = 'rb_last_backup_time';
    const LS_LAST_EOD_DATE = 'rb_last_eod_date';
    const LS_LAST_DAILY_NOTIF = 'rb_last_daily_notif_date';

    function _getDismissed() {
        try { return JSON.parse(localStorage.getItem(LS_DISMISSED)) || []; }
        catch (e) { return []; }
    }

    function _addDismissed(id) {
        var list = _getDismissed();
        if (!list.includes(id)) {
            list.push(id);
            try { localStorage.setItem(LS_DISMISSED, JSON.stringify(list)); } catch (e) {}
        }
    }

    function _getAllNotifications() {
        var list = [];
        var dismissed = _getDismissed();

        var eod = _getEodNotification();
        if (eod && !dismissed.includes(eod.id)) list.push(eod);

        var backup = _getBackupReminder();
        if (backup && !dismissed.includes(backup.id)) list.push(backup);

        var daily = _getDailyBackupAlert();
        if (daily && !dismissed.includes(daily.id)) list.push(daily);

        var expiryNotes = _getExpiryNotifications();
        expiryNotes.forEach(function(n) {
            if (!dismissed.includes(n.id)) list.push(n);
        });

        list.sort(function(a, b) { return b.time - a.time; });
        return list;
    }

    function _getEodNotification() {
        var today = Utils.getTodayStr();
        var todayBills = AppState.billsHistory.filter(function(b) {
            return !b.cancelled && b.date === today;
        });
        if (!todayBills.length) return null;

        var total = todayBills.reduce(function(s, b) { return s + b.total; }, 0);
        var items = todayBills.reduce(function(s, b) { return s + (b.items || []).length; }, 0);
        var id = 'eod_' + today.replace(/\//g, '');

        return {
            id: id,
            type: 'eod',
            title: '📊 End of Day Summary',
            message: 'Aaj ka total: ₹' + total.toFixed(2) + ' | ' + todayBills.length + ' bills | ' + items + ' items sold',
            time: Date.now()
        };
    }

    function _getBackupReminder() {
        var lastBackup = parseInt(localStorage.getItem(LS_LAST_BACKUP), 10) || 0;
        var hasData = AppState.stockData.length > 0 || AppState.billsHistory.length > 0;
        if (!lastBackup) {
            // Kabhi backup nahi liya — reminders sirf tab jab data maujood ho.
            if (!hasData) return null;
            return {
                id: 'backup_never',
                type: 'backup',
                title: '⚠️ Backup Reminder',
                message: 'Aapne abhi tak koi backup nahi liya. Backup & Restore section se Offline Backup download karein.',
                time: Date.now()
            };
        }
        var hoursSince = (Date.now() - lastBackup) / (1000 * 60 * 60);
        if (hoursSince < 48) return null;

        var id = 'backup_' + Math.floor(lastBackup / 86400000);
        return {
            id: id,
            type: 'backup',
            title: '⚠️ Backup Reminder',
            message: 'Last backup ko ' + Math.floor(hoursSince) + ' ghante se zyada ho gaye. Backup lein!',
            time: Date.now()
        };
    }

    function _getDailyBackupAlert() {
        var today = Utils.getTodayStr();
        var lastBackup = parseInt(localStorage.getItem(LS_LAST_BACKUP), 10) || 0;
        if (!lastBackup) return null;
        var hoursSince = (Date.now() - lastBackup) / (1000 * 60 * 60);
        if (hoursSince < 12) return null;

        return {
            id: 'daily_backup_' + today.replace(/\//g, ''),
            type: 'backup',
            title: '💾 Daily Backup Reminder',
            message: '⏰ Aaj ka backup lena mat bhoolna! Last backup ko ' + Math.floor(hoursSince) + ' ghante ho gaye.',
            time: Date.now()
        };
    }

    function _getExpiryNotifications() {
        var today = new Date();
        today.setHours(0, 0, 0, 0);
        var in30 = new Date(today);
        in30.setDate(in30.getDate() + (CONFIG.EXPIRY_WARNING_DAYS || 30));
        var result = [];

        AppState.stockData.forEach(function(item) {
            (item.batches || []).forEach(function(b) {
                var exp = Utils.parseExpiry(b.expiry);
                if (!exp) return;
                // Fully returned / zero-stock batch ke liye notification nahi.
                if ((parseInt(b.qty, 10) || 0) <= 0) return;

                var id = 'exp_' + item.id + '_' + b.batch + '_' + b.expiry;
                if (exp < today) {
                    result.push({
                        id: id,
                        type: 'expiry',
                        title: '🔴 Expired: ' + item.name,
                        message: 'Batch ' + b.batch + ' (' + b.expiry + ') expire ho gayi! Qty: ' + b.qty,
                        time: Date.now()
                    });
                } else if (exp <= in30) {
                    result.push({
                        id: id,
                        type: 'expiry',
                        title: '🟡 Expiring Soon: ' + item.name,
                        message: 'Batch ' + b.batch + ' (' + b.expiry + ') 30 din mein expire. Qty: ' + b.qty,
                        time: Date.now()
                    });
                }
            });
        });

        return result;
    }

    function _typeLabel(t) {
        return { eod: 'eod', backup: 'backup', expiry: 'expiry' }[t] || '';
    }

    function renderPanel() {
        var body = document.getElementById('notifPanelBody');
        if (!body) return;
        var notes = _getAllNotifications();
        Utils.clearElement(body);

        if (!notes.length) {
            body.innerHTML = '<div class="notif-empty">✨ Koi notification nahi hai</div>';
            _updateBadge(0);
            return;
        }

        notes.forEach(function(n) {
            var div = document.createElement('div');
            div.className = 'notif-item ' + _typeLabel(n.type);

            var title = document.createElement('div');
            title.className = 'notif-title';
            title.textContent = n.title;

            var msg = document.createElement('div');
            msg.className = 'notif-msg';
            msg.textContent = n.message;

            var time = document.createElement('div');
            time.className = 'notif-time';
            var d = new Date(n.time);
            time.textContent = d.toLocaleString();

            var dismiss = document.createElement('button');
            dismiss.className = 'notif-dismiss';
            dismiss.textContent = '✕';
            dismiss.setAttribute('data-id', n.id);
            dismiss.addEventListener('click', function(e) {
                e.stopPropagation();
                _addDismissed(n.id);
                renderPanel();
            });

            div.appendChild(title);
            div.appendChild(msg);
            div.appendChild(time);
            div.appendChild(dismiss);
            body.appendChild(div);
        });

        _updateBadge(notes.length);
    }

    function _updateBadge(count) {
        var badge = document.getElementById('notifBadge');
        if (!badge) return;
        if (count > 0) {
            badge.textContent = String(count);
            badge.style.display = 'flex';
        } else {
            badge.style.display = 'none';
        }
    }

    function togglePanel() {
        var panel = document.getElementById('notifPanel');
        var overlay = document.getElementById('notifOverlay');
        if (!panel) return;
        var isOpen = panel.classList.contains('open');
        panel.classList.toggle('open');
        if (overlay) overlay.classList.toggle('show');
        if (!isOpen) renderPanel();
    }

    function dismissAll() {
        var notes = _getAllNotifications();
        notes.forEach(function(n) { _addDismissed(n.id); });
        renderPanel();
    }

    function markBackupDone() {
        try {
            localStorage.setItem(LS_LAST_BACKUP, String(Date.now()));
            localStorage.removeItem(LS_LAST_DAILY_NOTIF);
            _addDismissed('daily_backup_' + Utils.getTodayStr().replace(/\//g, ''));
        } catch (e) {}
    }

    function init() {
        renderPanel();
    }

    return {
        init: init,
        togglePanel: togglePanel,
        dismissAll: dismissAll,
        renderPanel: renderPanel,
        markBackupDone: markBackupDone
    };
})();
