const PurchaseOrder = (() => {
    const LS_KEY = 'rb_purchase_orders';
    const LS_PHARMA = 'rb_pharma_names';

    let _orders = [];
    let _currentItems = [];
    let _currentEditId = null;
    let _pharmaNames = [];
    let _medHL = -1;
    let _pharmaHL = -1;
    let _searchQuery = '';

    function _loadOrders() {
        try {
            _orders = JSON.parse(localStorage.getItem(LS_KEY)) || [];
        } catch (e) {
            _orders = [];
        }
    }

    function _saveOrders() {
        try {
            localStorage.setItem(LS_KEY, JSON.stringify(_orders));
        } catch (e) {
            console.error('PO save error:', e);
        }
    }

    function _loadPharmaNames() {
        try {
            _pharmaNames = JSON.parse(localStorage.getItem(LS_PHARMA)) || [];
        } catch (e) {
            _pharmaNames = [];
        }
    }

    function _savePharmaName(name) {
        if (!name || _pharmaNames.includes(name)) return;
        _pharmaNames.push(name);
        _pharmaNames.sort();
        try { localStorage.setItem(LS_PHARMA, JSON.stringify(_pharmaNames)); } catch (e) {}
    }

    function openOrderHome() {
        AppModules.openSection('purchaseOrderSection');
        document.getElementById('poHomeView').style.display = 'block';
        document.getElementById('poEditorView').style.display = 'none';
        _loadOrders();
        _renderOrderTable();
    }

    function _renderOrderTable() {
        const tbody = document.getElementById('poTableBody');
        Utils.clearElement(tbody);
        const filtered = _searchQuery ? _orders.filter(o => (o.pharma || '').toLowerCase().includes(_searchQuery)) : _orders;
        if (!filtered.length) {
            const msg = _searchQuery ? 'Koi matching order nahi mila.' : 'Koi purchase order nahi hai. Naya order banayein!';
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#9ca3af;padding:30px;">' + msg + '</td></tr>';
            return;
        }
        filtered.sort((a, b) => b.createdAt - a.createdAt);
        filtered.forEach(o => {
            const tr = document.createElement('tr');
            const tdDate = document.createElement('td');
            tdDate.textContent = o.date;
            tr.appendChild(tdDate);

            const tdPharma = document.createElement('td');
            tdPharma.textContent = o.pharma || '-';
            tr.appendChild(tdPharma);

            const tdItems = document.createElement('td');
            tdItems.style.cssText = 'text-align:right;font-weight:700;';
            tdItems.textContent = o.items.length;
            tr.appendChild(tdItems);

            const tdAction = document.createElement('td');
            tdAction.style.cssText = 'text-align:center;white-space:nowrap;';
            const viewBtn = document.createElement('button');
            viewBtn.className = 'btn-primary';
            viewBtn.style.cssText = 'padding:4px 12px;font-size:11px;margin-right:6px;';
            viewBtn.textContent = '👁 View';
            viewBtn.addEventListener('click', () => _viewOrder(o.id));
            tdAction.appendChild(viewBtn);

            const pdfBtn = document.createElement('button');
            pdfBtn.className = 'btn-pdf';
            pdfBtn.style.cssText = 'padding:4px 12px;font-size:11px;margin-right:6px;';
            pdfBtn.textContent = '📄 PDF';
            pdfBtn.addEventListener('click', () => _printOrder(o.id));
            tdAction.appendChild(pdfBtn);

            const shareBtn = document.createElement('button');
            shareBtn.className = 'btn-primary';
            shareBtn.style.cssText = 'padding:4px 12px;font-size:11px;background:#0891b2;';
            shareBtn.textContent = '📤 Share';
            shareBtn.addEventListener('click', () => _shareOrder(o.id));
            tdAction.appendChild(shareBtn);

            const delBtn = document.createElement('button');
            delBtn.className = 'btn-danger';
            delBtn.style.cssText = 'padding:4px 12px;font-size:11px;margin-left:6px;';
            delBtn.textContent = '🗑 Delete';
            delBtn.addEventListener('click', () => _deleteOrder(o.id));
            tdAction.appendChild(delBtn);

            tr.appendChild(tdAction);
            tbody.appendChild(tr);
        });
    }

    function onSearch(val) {
        _searchQuery = val.trim().toLowerCase();
        _renderOrderTable();
    }

    function _deleteOrder(id) {
        const order = _orders.find(o => o.id === id);
        if (!order) return;
        if (!confirm('Is purchase order ko delete kar dein?')) return;
        const pharma = order.pharma;
        _orders = _orders.filter(o => o.id !== id);
        _saveOrders();
        if (pharma && !_orders.some(o => o.pharma === pharma)) {
            _pharmaNames = _pharmaNames.filter(n => n !== pharma);
            try { localStorage.setItem(LS_PHARMA, JSON.stringify(_pharmaNames)); } catch (e) {}
        }
        _renderOrderTable();
        UI.showToast('Order delete ho gaya!', 'success');
    }

    function createNewOrder() {
        _currentItems = [];
        _currentEditId = null;
        document.getElementById('poHomeView').style.display = 'none';
        document.getElementById('poEditorView').style.display = 'block';
        document.getElementById('poEditorTitle').textContent = '🆕 New Purchase Order';
        document.getElementById('poPharmaInput').value = '';
        document.getElementById('poMedInput').value = '';
        document.getElementById('poQtyInput').value = '';
        _renderItems();
        _hideMedSuggestions();
        _hidePharmaSuggestions();
        setTimeout(() => document.getElementById('poMedInput').focus(), 100);
    }

    function _viewOrder(id) {
        const order = _orders.find(o => o.id === id);
        if (!order) {
            UI.showToast('Order nahi mila! Ho sakta hai delete ho gaya ho.', 'error');
            return;
        }
        _currentItems = order.items.map(it => ({ ...it }));
        _currentEditId = order.id;
        document.getElementById('poHomeView').style.display = 'none';
        document.getElementById('poEditorView').style.display = 'block';
        document.getElementById('poEditorTitle').textContent = '📋 View Order';
        document.getElementById('poPharmaInput').value = order.pharma || '';
        _hideMedSuggestions();
        _hidePharmaSuggestions();
        _renderItems();
    }

    function backToHome() {
        if (_currentItems.length > 0) {
            if (!confirm('Current order save nahi hoga. Kya aap wapas jana chahte hain?')) return;
        }
        openOrderHome();
    }

    function addItem() {
        const medInput = document.getElementById('poMedInput');
        const qtyInput = document.getElementById('poQtyInput');
        const unitSelect = document.getElementById('poUnitInput');
        const name = medInput.value.trim();
        const rawQty = qtyInput.value.trim();
        const qty = parseInt(rawQty, 10);
        const unit = unitSelect.value;

        if (!name) {
            UI.showToast('Medicine name daalein!', 'error');
            medInput.focus();
            return;
        }
        if (!rawQty || isNaN(qty) || qty < 1) {
            UI.showToast('Sahi quantity daalein!', 'error');
            qtyInput.focus();
            return;
        }

        _currentItems.push({ medicine: name, qty, unit });
        medInput.value = '';
        qtyInput.value = '';
        _renderItems();
        medInput.focus();
        UI.showToast('Item add ho gaya!', 'success');
    }

    function _removeItem(idx) {
        _currentItems.splice(idx, 1);
        _renderItems();
    }

    function _editItem(idx) {
        const item = _currentItems[idx];
        document.getElementById('poMedInput').value = item.medicine;
        document.getElementById('poQtyInput').value = item.qty;
        document.getElementById('poUnitInput').value = item.unit;
        _currentItems.splice(idx, 1);
        _renderItems();
        document.getElementById('poMedInput').focus();
    }

    function _renderItems() {
        const tbody = document.getElementById('poItemsBody');
        const countSpan = document.getElementById('poItemCount');
        Utils.clearElement(tbody);

        countSpan.textContent = _currentItems.length;

        if (!_currentItems.length) {
            tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#9ca3af;padding:20px;">Abhi tak koi medicine add nahi hui</td></tr>';
            return;
        }

        _currentItems.forEach((it, i) => {
            const tr = document.createElement('tr');
            const tdNum = document.createElement('td');
            tdNum.textContent = i + 1;
            tr.appendChild(tdNum);

            const tdName = document.createElement('td');
            tdName.innerHTML = '<strong>' + Utils.escapeHtml(it.medicine) + '</strong>';
            tr.appendChild(tdName);

            const tdQty = document.createElement('td');
            tdQty.style.cssText = 'text-align:right;font-weight:700;';
            tdQty.textContent = it.qty;
            tr.appendChild(tdQty);

            const tdUnit = document.createElement('td');
            tdUnit.style.cssText = 'text-align:right;';
            tdUnit.textContent = it.unit;
            tr.appendChild(tdUnit);

            const tdAction = document.createElement('td');
            tdAction.style.cssText = 'text-align:center;white-space:nowrap;';

            const editBtn = document.createElement('button');
            editBtn.className = 'btn-primary';
            editBtn.style.cssText = 'padding:3px 10px;font-size:11px;margin-right:4px;';
            editBtn.textContent = '✏ Edit';
            editBtn.addEventListener('click', () => _editItem(i));
            tdAction.appendChild(editBtn);

            const delBtn = document.createElement('button');
            delBtn.className = 'btn-danger';
            delBtn.style.cssText = 'padding:3px 10px;font-size:11px;';
            delBtn.textContent = '✕ Remove';
            delBtn.addEventListener('click', () => _removeItem(i));
            tdAction.appendChild(delBtn);

            tr.appendChild(tdAction);
            tbody.appendChild(tr);
        });
    }

    function _getOrderData() {
        const pharma = document.getElementById('poPharmaInput').value.trim();
        // Edit karte waqt original date/createdAt preserve karo — pehle har edit
        // par date aaj ki ho jati thi aur list ka sorting order badal jata tha.
        const existing = _currentEditId ? _orders.find(o => o.id === _currentEditId) : null;
        return {
            id: _currentEditId || Utils.generateId('po'),
            date: existing ? existing.date : Utils.getTodayStr(),
            pharma: pharma || '',
            items: _currentItems.map(it => ({ ...it })),
            createdAt: existing && existing.createdAt ? existing.createdAt : Date.now()
        };
    }

    function _preparePrint(order) {
        const detailDiv = document.getElementById('poPrintDetails');
        const body = document.getElementById('poPrintBody');
        Utils.clearElement(body);

        const pharmaLine = order.pharma ? '<strong>Order To:</strong> ' + Utils.escapeHtml(order.pharma) : '';
        detailDiv.innerHTML = '<div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:8px;">'
            + '<span><strong>Order By:</strong> Shri Ramdevbaba Medical &amp; General Store' + (pharmaLine ? ' | ' + pharmaLine : '') + '</span>'
            + '<span><strong>Date:</strong> ' + Utils.escapeHtml(order.date || '') + '</span>'
            + '</div>';

        order.items.forEach((it, i) => {
            const tr = document.createElement('tr');
            const bg = i % 2 === 0 ? '#f9f9f9' : '#ffffff';
            tr.innerHTML = '<td style="padding:7px 10px;border:1px solid #ddd;text-align:center;background:' + bg + ';">' + (i + 1) + '</td>'
                + '<td style="padding:7px 10px;border:1px solid #ddd;background:' + bg + ';">' + Utils.escapeHtml(it.medicine) + '</td>'
                + '<td style="padding:7px 10px;border:1px solid #ddd;text-align:right;font-weight:700;background:' + bg + ';">' + it.qty + ' ' + Utils.escapeHtml(it.unit || '') + '</td>';
            body.appendChild(tr);
        });
    }

    function _downloadPDF(filename) {
        const printArea = document.getElementById('poPrintArea');
        printArea.style.display = 'block';
        const opt = {
            margin:       [0.5, 0.5, 0.5, 0.5],
            filename:     filename + '.pdf',
            image:        { type: 'jpeg', quality: 0.98 },
            html2canvas:  { scale: 2, useCORS: true, allowTaint: false },
            jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
        };
        return html2pdf().set(opt).from(printArea).save().then(function () {
            printArea.style.display = 'none';
        }).catch(function (err) {
            printArea.style.display = 'none';
            throw err;
        });
    }

    function savePDF() {
        if (!_currentItems.length) {
            UI.showToast('Pehle medicines add karein!', 'error');
            return;
        }
        const orderData = _getOrderData();
        _savePharmaName(orderData.pharma);
        if (_currentEditId) {
            const idx = _orders.findIndex(o => o.id === _currentEditId);
            if (idx > -1) _orders[idx] = orderData;
            else _orders.push(orderData);
        } else {
            _orders.push(orderData);
        }
        _saveOrders();
        _preparePrint(orderData);
        const filename = 'Purchase_Order_' + orderData.date.replace(/\//g, '-');
        _downloadPDF(filename).then(function () {
            UI.showToast('PDF save aur download ho gaya!', 'success');
            _currentItems = [];
            _currentEditId = null;
            openOrderHome();
        }).catch(function () {
            UI.showToast('PDF generate nahi hua, print try karein.', 'error');
        });
    }

    function _printOrder(id) {
        const order = _orders.find(o => o.id === id);
        if (!order) {
            UI.showToast('Order nahi mila!', 'error');
            return;
        }
        _preparePrint(order);
        const filename = 'Purchase_Order_' + order.date.replace(/\//g, '-');
        _downloadPDF(filename).then(function () {
            UI.showToast('PDF download ho gaya!', 'success');
        }).catch(function () {
            UI.showToast('PDF generate nahi hua.', 'error');
        });
    }

    function _shareOrder(id) {
        const order = _orders.find(o => o.id === id);
        if (!order) return;
        const isMobile = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(navigator.userAgent);
        let text = '📋 *PURCHASE ORDER*\n';
        text += '🏪 *Order By:* Shri Ramdevbaba Medical & General Store\n';
        text += '📅 Date: ' + order.date + '\n';
        if (order.pharma) text += '🏭 *Order To:* ' + order.pharma + '\n';
        text += '\n📦 *Items:*\n';
        order.items.forEach((it, i) => {
            text += (i + 1) + '. ' + it.medicine + ' — ' + it.qty + ' ' + it.unit + '\n';
        });
        if (isMobile && navigator.share) {
            navigator.share({ title: 'Purchase Order - ' + order.date, text: text }).catch(() => {});
        } else {
            _copyToClipboard(text);
        }
    }

    function _copyToClipboard(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(() => {
                UI.showToast('Order text copy ho gaya! Kahi bhi paste karein.', 'success', 3000);
            }).catch(() => {
                prompt('Copy this order text:', text);
            });
        } else {
            prompt('Copy this order text:', text);
        }
    }

    // Medicine suggestions
    function onMedInput(val) {
        _medHL = -1;
        const box = document.getElementById('poMedSuggestions');
        if (!box) return;
        const q = val.trim().toLowerCase();
        if (!q) { _hideMedSuggestions(); return; }
        const allNames = AppState.stockData.map(s => s.name);
        const unique = [...new Set(allNames)];
        const filtered = unique.filter(n => n.toLowerCase().includes(q)).slice(0, 15);
        Utils.clearElement(box);
        if (!filtered.length) { _hideMedSuggestions(); return; }
        filtered.forEach((n, i) => {
            const totalQty = AppState.stockData.filter(s => s.name === n).reduce((sum, s) => {
                if (s.batches) return sum + s.batches.reduce((a, b) => a + (b.qty || 0), 0);
                return sum + (s.qty || 0);
            }, 0);

            const div = document.createElement('div');
            div.className = 'suggestion-item' + (i === 0 ? ' highlighted' : '');

            const nameSpan = document.createElement('span');
            nameSpan.textContent = n;

            const badge = document.createElement('span');
            badge.className = 'sug-badge' + (totalQty <= 0 ? ' out' : '');
            badge.textContent = totalQty <= 0 ? 'Out of Stock' : totalQty + ' in stock';

            div.appendChild(nameSpan);
            div.appendChild(badge);
            div.addEventListener('click', () => {
                document.getElementById('poMedInput').value = n;
                _hideMedSuggestions();
                document.getElementById('poQtyInput').focus();
            });
            box.appendChild(div);
        });
        box.style.display = 'block';
    }

    function medKeydown(e) {
        const box = document.getElementById('poMedSuggestions');
        if (!box || box.style.display === 'none') {
            if (e.key === 'ArrowDown' || e.key === 'Enter') {
                e.preventDefault();
                document.getElementById('poQtyInput').focus();
            }
            return;
        }
        const items = box.querySelectorAll('.suggestion-item');
        if (!items.length) {
            if (e.key === 'ArrowDown' || e.key === 'Enter') {
                e.preventDefault();
                document.getElementById('poQtyInput').focus();
            }
            return;
        }
        if (e.key === 'ArrowDown') { e.preventDefault(); _medHL = Math.min(_medHL + 1, items.length - 1); items.forEach((it, i) => it.classList.toggle('highlighted', i === _medHL)); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); _medHL = Math.max(_medHL - 1, -1); items.forEach((it, i) => it.classList.toggle('highlighted', i === _medHL)); }
        else if (e.key === 'Enter') { e.preventDefault(); const toClick = (_medHL >= 0 && items[_medHL]) ? items[_medHL] : items[0]; toClick.click(); }
        else if (e.key === 'Escape') { _hideMedSuggestions(); }
    }

    function qtyKeydown(e) {
        if (e.key === 'ArrowDown' || e.key === 'Enter') {
            e.preventDefault();
            document.getElementById('poUnitInput').focus();
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            document.getElementById('poMedInput').focus();
        }
    }

    function unitKeydown(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            addItem();
        }
    }

    function _hideMedSuggestions() {
        const box = document.getElementById('poMedSuggestions');
        if (box) box.style.display = 'none';
        _medHL = -1;
    }

    // Pharma suggestions
    function onPharmaInput(val) {
        _pharmaHL = -1;
        const box = document.getElementById('poPharmaSuggestions');
        if (!box) return;
        const q = val.trim().toLowerCase();
        if (!q) { _hidePharmaSuggestions(); return; }
        Utils.clearElement(box);
        const stockWholesalers = (AppState.wholesalerList || []).filter(function (w) { return typeof w === 'string' && w; });
        const allNames = [...new Set(_pharmaNames.concat(stockWholesalers))].sort();
        const filtered = allNames.filter(n => n.toLowerCase().includes(q));
        if (!filtered.length) { _hidePharmaSuggestions(); return; }
        filtered.forEach((n, i) => {
            const div = document.createElement('div');
            div.className = 'suggestion-item' + (i === 0 ? ' highlighted' : '');
            div.textContent = n;
            div.addEventListener('click', () => {
                document.getElementById('poPharmaInput').value = n;
                _hidePharmaSuggestions();
            });
            box.appendChild(div);
        });
        box.style.display = 'block';
    }

    function pharmaKeydown(e) {
        const box = document.getElementById('poPharmaSuggestions');
        if (!box || box.style.display === 'none') {
            if (e.key === 'Enter') {
                e.preventDefault();
                document.getElementById('poMedInput').focus();
            }
            return;
        }
        const items = box.querySelectorAll('.suggestion-item');
        if (!items.length) {
            if (e.key === 'Enter') {
                e.preventDefault();
                document.getElementById('poMedInput').focus();
            }
            return;
        }
        if (e.key === 'ArrowDown') { e.preventDefault(); _pharmaHL = Math.min(_pharmaHL + 1, items.length - 1); items.forEach((it, i) => it.classList.toggle('highlighted', i === _pharmaHL)); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); _pharmaHL = Math.max(_pharmaHL - 1, -1); items.forEach((it, i) => it.classList.toggle('highlighted', i === _pharmaHL)); }
        else if (e.key === 'Enter') { e.preventDefault(); var toClick = (_pharmaHL >= 0 && items[_pharmaHL]) ? items[_pharmaHL] : items[0]; toClick.click(); document.getElementById('poMedInput').focus(); }
        else if (e.key === 'Escape') { _hidePharmaSuggestions(); }
    }

    function _hidePharmaSuggestions() {
        const box = document.getElementById('poPharmaSuggestions');
        if (box) box.style.display = 'none';
        _pharmaHL = -1;
    }

    function _clone(value) {
        try { return JSON.parse(JSON.stringify(value)); } catch (e) { return null; }
    }

    // Backup/restore APIs — offline JSON backup mein purchase orders bhi jaate hain.
    function getAllOrders() {
        _loadOrders();
        return _orders.filter(function (o) { return o && o.id; }).map(function (o) { return _clone(o); });
    }

    function importOrders(list, replace) {
        if (!Array.isArray(list)) return 0;
        if (replace) {
            _orders = [];
        } else {
            _loadOrders();
        }
        var seen = {};
        _orders.forEach(function (o) { if (o && o.id) seen[o.id] = true; });
        var added = 0;
        list.forEach(function (o) {
            if (!o || typeof o !== 'object' || !o.id || !Array.isArray(o.items)) return;
            if (seen[o.id]) return;
            seen[o.id] = true;
            _orders.push({
                id: String(o.id),
                date: typeof o.date === 'string' ? o.date : Utils.getTodayStr(),
                pharma: typeof o.pharma === 'string' ? o.pharma : '',
                items: o.items.filter(function (it) { return it && it.medicine; }).map(function (it) {
                    return { medicine: String(it.medicine), qty: parseInt(it.qty, 10) || 0, unit: String(it.unit || '') };
                }),
                createdAt: Number(o.createdAt) || Date.now()
            });
            added++;
        });
        if (added) _saveOrders();
        return added;
    }

    function reloadFromStorage() {
        _loadOrders();
        _loadPharmaNames();
        _currentItems = [];
        _currentEditId = null;
    }

    function clearAllOrders() {
        _orders = [];
        _pharmaNames = [];
        try { localStorage.removeItem(LS_KEY); localStorage.removeItem(LS_PHARMA); } catch (e) {}
        _currentItems = [];
        _currentEditId = null;
    }

    // Init
    function init() {
        _loadPharmaNames();
    }

    return {
        init,
        openOrderHome,
        onSearch,
        createNewOrder,
        backToHome,
        addItem,
        onMedInput,
        medKeydown,
        qtyKeydown,
        unitKeydown,
        onPharmaInput,
        pharmaKeydown,
        savePDF,
        getAllOrders,
        importOrders,
        reloadFromStorage,
        clearAllOrders
    };
})();
