const Auth = (() => {
    const MAX_ATTEMPTS = 5;
    const LOCKOUT_DURATION_MS = 60000;
    const LS_LOGIN_ATTEMPTS = 'rb_login_attempts';
    const LS_LOCKOUT_AT = 'rb_lockout_at';

    function _getLockoutState() {
        const attempts = parseInt(Database.Storage.getString(LS_LOGIN_ATTEMPTS, '0'), 10) || 0;
        const lockAt = parseInt(Database.Storage.getString(LS_LOCKOUT_AT, '0'), 10) || 0;
        return { attempts, lockAt };
    }

    function _saveLockoutState(attempts, lockAt) {
        Database.Storage.setString(LS_LOGIN_ATTEMPTS, String(attempts));
        Database.Storage.setString(LS_LOCKOUT_AT, String(lockAt));
    }

    function _clearLockoutState() {
        Database.Storage.remove(LS_LOGIN_ATTEMPTS);
        Database.Storage.remove(LS_LOCKOUT_AT);
    }

    const LS_CUSTOM_PASSWORD = 'rb_custom_password_hash';

    function _getUsers() {
        const customHash = Database.Storage.getString(LS_CUSTOM_PASSWORD, '');
        const defaultHash = '5b40171489659251097e7790fc2f1892e2183a72546fe1df283d07865db9149c';
        return [
            { username: 'ADMIN', passwordHash: customHash || defaultHash }
        ];
    }

    function isLoggedIn() {
        const loggedIn = Database.Storage.getString(CONFIG.LS_KEYS.LOGGED_IN);
        if (loggedIn !== 'true') return false;
        const loginAt = parseInt(Database.Storage.getString(CONFIG.LS_KEYS.LOGIN_AT, '0'), 10);
        if (Date.now() - loginAt > CONFIG.SESSION_TIMEOUT_MS) {
            doLogout();
            return false;
        }
        return true;
    }

    function doLogin() {
        const userInput = document.getElementById('loginUser');
        const passInput = document.getElementById('loginPass');
        const errorDiv = document.getElementById('loginError');

        const username = userInput.value.trim();
        const password = passInput.value.trim();

        if (!username || !password) {
            errorDiv.textContent = 'Username aur password daalna zaroori hai!';
            errorDiv.style.display = 'block';
            return;
        }

        const now = Date.now();
        const { attempts, lockAt } = _getLockoutState();

        if (attempts >= MAX_ATTEMPTS && (now - lockAt) < LOCKOUT_DURATION_MS) {
            const waitSec = Math.ceil((LOCKOUT_DURATION_MS - (now - lockAt)) / 1000);
            errorDiv.textContent = 'Bahut zyada attempts! ' + waitSec + ' second ruko.';
            errorDiv.style.display = 'block';
            return;
        }

        if (now - lockAt > LOCKOUT_DURATION_MS) {
            _clearLockoutState();
        }

        Utils.sha256(password).then(async hash => {
            const user = _getUsers().find(u => u.username === username && u.passwordHash === hash);
            if (user) {
                _clearLockoutState();
                Database.Storage.setString(CONFIG.LS_KEYS.LOGGED_IN, 'true');
                Database.Storage.setString(CONFIG.LS_KEYS.LOGIN_AT, String(Date.now()));

                document.getElementById('loginScreen').style.display = 'none';
                document.getElementById('homeMenu').style.display = 'flex';
                userInput.value = '';
                passInput.value = '';
                errorDiv.style.display = 'none';

                await AppState.init();

                if (typeof Inventory !== 'undefined' && Inventory.renderStockTable) Inventory.renderStockTable();
                if (typeof History !== 'undefined' && History.renderHistoryTable) History.renderHistoryTable();
                if (typeof Notifications !== 'undefined') Notifications.renderPanel();
                Billing.resetBillingForm();

                // NOTE: Login par koi automatic cloud sync nahi hota.
                // App poora offline chalta hai; online backup sirf user ke
                // "Backup to DB" button dabane par hi hota hai.
            } else {
                _saveLockoutState(attempts + 1, now);
                errorDiv.textContent = 'Wrong username ya password!';
                errorDiv.style.display = 'block';
                passInput.value = '';
                passInput.focus();
            }
        }).catch(() => {
            errorDiv.textContent = 'Login system error!';
            errorDiv.style.display = 'block';
        });
    }

    function doLogout() {
        Database.Storage.remove(CONFIG.LS_KEYS.LOGGED_IN);
        Database.Storage.remove(CONFIG.LS_KEYS.LOGIN_AT);
        document.getElementById('loginScreen').style.display = 'flex';
        document.getElementById('homeMenu').style.display = 'none';
        document.querySelectorAll('.app-section').forEach(s => s.style.display = 'none');
        document.getElementById('loginUser').value = '';
        document.getElementById('loginPass').value = '';
        document.getElementById('loginError').style.display = 'none';
        document.getElementById('loginUser').focus();
    }

    function showLogin() {
        document.getElementById('loginScreen').style.display = 'flex';
        document.getElementById('homeMenu').style.display = 'none';
        document.getElementById('loginUser').focus();
    }

    function setup() {
        document.getElementById('loginPass').addEventListener('keydown', (e) => {
            if (e.key === 'Enter') doLogin();
        });
        document.getElementById('loginUser').addEventListener('keydown', (e) => {
            if (e.key === 'Enter') document.getElementById('loginPass').focus();
        });
    }

    function verifyPassword(password) {
        return Utils.sha256(password).then(hash => {
            return _getUsers().some(u => u.passwordHash === hash);
        });
    }

    return {
        isLoggedIn,
        doLogin,
        doLogout,
        showLogin,
        setup,
        verifyPassword
    };
})();
