const Sync = (() => {

    function _hasError(res) { return !res || (typeof res === 'object' && res.error); }
    function _chunk(arr, size) {
        var out = [];
        for (var i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
        return out;
    }

    // ==================== LOCAL -> CLOUD (manual backup only) ====================
    // Yeh functions sirf tab chalte hain jab user "Backup to DB" dabata hai.
    // App startup, login ya timer par koi automatic sync nahi hota.

    async function syncStockToCloud() {
        const stockData = AppState.stockData;
        if (!stockData || !stockData.length) return true;

        // Ensure every batch has an ID before syncing (prevent duplicate creation)
        var needsSave = false;
        stockData.forEach(s => {
            (s.batches || []).forEach(b => {
                if (!b.id) { b.id = Utils.generateId('batch'); needsSave = true; }
            });
        });
        if (needsSave) await AppState.saveStock();

        const stockRows = stockData.map(s => ({
            id: s.id,
            name: s.name,
            wholesaler: s.wholesaler || '',
            make: s.make || '',
            h1: !!s.h1,
            h: !!s.h,
            h2: !!s.h2,
            narcotic: !!s.narcotic
        }));
        for (const part of _chunk(stockRows, 500)) {
            const stockRes = await Database.cloudUpsert('stock', part);
            if (_hasError(stockRes)) { console.error('STOCK SYNC ERROR:', stockRes.error); return stockRes; }
        }

        const allBatchRows = [];
        const localBatchIds = {};
        stockData.forEach(s => {
            (s.batches || []).forEach(b => {
                const bid = b.id || Utils.generateId('batch');
                b.id = bid;
                localBatchIds[bid] = true;
                allBatchRows.push({
                    id: bid,
                    stock_id: s.id,
                    batch: b.batch || '',
                    expiry: b.expiry || '',
                    qty: b.qty || 0,
                    strip_size: b.stripSize || 0,
                    price: b.price || 0
                });
            });
        });
        for (const part of _chunk(allBatchRows, 500)) {
            const batchRes = await Database.cloudUpsert('batches', part);
            if (_hasError(batchRes)) { console.error('BATCH SYNC ERROR:', batchRes.error); return batchRes; }
        }

        // Stale cloud batch rows clean karo — sirf un stock items ke liye jo
        // local mein maujood hain. Doosre device ke stock ko delete nahi karte.
        const localStockIds = {};
        stockData.forEach(s => { localStockIds[s.id] = true; });
        try {
            var remoteBatches = await Database.cloudFetch('batches');
            if (Array.isArray(remoteBatches) && remoteBatches.length) {
                var staleIds = [];
                remoteBatches.forEach(function (rb) {
                    if (rb && rb.id && localStockIds[rb.stock_id] && !localBatchIds[rb.id]) {
                        staleIds.push(rb.id);
                    }
                });
                if (staleIds.length) await Database.cloudDeleteMany('batches', 'id', staleIds);
            }
        } catch (dedupErr) {
            console.error('SYNC: Batch cleanup error:', dedupErr);
        }

        await AppState.saveStock();
        return true;
    }

    async function syncBillsToCloud() {
        const billsHistory = AppState.billsHistory;
        if (!billsHistory || !billsHistory.length) return true;

        const billRows = [];
        const itemRows = [];
        const localBillIds = {};
        const localItemIds = {};

        billsHistory.forEach(bill => {
            if (!bill || !bill.id) return;
            localBillIds[bill.id] = true;
            billRows.push({
                id: bill.id,
                bill_no: bill.billNo || 0,
                date: bill.date || '',
                time: bill.time || '',
                patient: bill.patient || '',
                doctor: bill.doctor || '',
                payment_mode: bill.paymentMode || 'Cash',
                total: bill.total || 0,
                cancelled: !!bill.cancelled,
                cancel_reason: bill.cancelReason || '',
                cancelled_at: bill.cancelledAt || ''
            });
            (bill.items || []).forEach((item, idx) => {
                let sid = item.stockId;
                if (!sid) {
                    const byName = AppState.stockData.find(s => s.name === item.particulars);
                    if (byName) sid = byName.id;
                }
                const itemId = item.id || (bill.id + '_' + idx);
                item.id = itemId;
                localItemIds[itemId] = true;
                itemRows.push({
                    id: itemId,
                    bill_id: bill.id,
                    stock_id: sid || '',
                    particulars: item.particulars || '',
                    make: item.make || '',
                    h: !!item.h,
                    h1: !!item.h1,
                    h2: !!item.h2,
                    narcotic: !!item.narcotic,
                    batch: item.batch || '',
                    expiry: item.expiry || '',
                    qty: item.qty || 0,
                    amount: item.amount || 0
                });
            });
        });

        for (const part of _chunk(billRows, 200)) {
            const billRes = await Database.cloudUpsert('bills', part);
            if (_hasError(billRes)) { console.error('BILL SYNC ERROR:', billRes.error); return billRes; }
        }
        for (const part of _chunk(itemRows, 500)) {
            const itemRes = await Database.cloudUpsert('bill_items', part);
            if (_hasError(itemRes)) { console.error('BILL_ITEMS SYNC ERROR:', itemRes.error); return itemRes; }
        }

        // Stale bill items clean karo (sirf local bills ke andar).
        try {
            var remoteItems = await Database.cloudFetch('bill_items');
            if (Array.isArray(remoteItems) && remoteItems.length) {
                var staleItemIds = [];
                remoteItems.forEach(function (ri) {
                    if (ri && ri.id && localBillIds[ri.bill_id] && !localItemIds[ri.id]) {
                        staleItemIds.push(ri.id);
                    }
                });
                if (staleItemIds.length) await Database.cloudDeleteMany('bill_items', 'id', staleItemIds);
            }
        } catch (cleanupErr) {
            console.error('SYNC: bill_items cleanup error:', cleanupErr);
        }

        await AppState.saveHistory();
        return true;
    }

    async function syncSuggestionsToCloud() {
        for (const { table, data, col } of [
            { table: 'doctors', data: AppState.doctorsList.map(n => ({ name: n })), col: 'name' },
            { table: 'make_list', data: AppState.makeList.map(n => ({ name: n })), col: 'name' },
            { table: 'wholesaler_list', data: AppState.wholesalerList.map(n => ({ name: n })), col: 'name' },
            { table: 'patient_words', data: AppState.patientWords.map(w => ({ word: w })), col: 'word' }
        ]) {
            if (!data || !data.length) continue;
            const res = await Database.cloudUpsert(table, data, col);
            if (_hasError(res)) { console.error(table + ' SYNC ERROR:', res.error); return res; }
        }
        return true;
    }

    async function syncPurchaseBillsToCloud() {
        let bills;
        try { bills = await PurchaseModule.getAllBills(); } catch (e) { console.error('PURCHASE GET ERROR:', e); return { error: e.message || 'PurchaseModule getAllBills failed' }; }
        if (!bills || !bills.length) return true;
        for (const rec of bills) {
            const row = {
                id: rec.id,
                pharma_name: rec.pharmaName || '',
                file_name: rec.fileName || '',
                file_type: rec.fileType || '',
                file_data: rec.fileData || '',
                date: rec.date || '',
                added_at: rec.addedAt || Date.now()
            };
            const res = await Database.cloudUpsert('purchase_bills', row);
            if (_hasError(res)) { console.error('PURCHASE_BILLS SYNC ERROR:', res.error); return res; }
        }
        return true;
    }

    // Return audit history optional table hai — agar Neon DB mein
    // medicine_returns table abhi nahi bani, to baaki backup fail nahi hota.
    async function syncReturnsToCloud() {
        const returns = AppState.returnHistory || [];
        if (!returns.length) return true;
        const rows = returns.map(function (r) {
            return {
                id: r.id,
                request_id: r.requestId || '',
                stock_id: r.stockId || '',
                batch_id: r.batchId || '',
                medicine_name: r.medicineName || '',
                make: r.make || '',
                supplier: r.supplier || '',
                batch: r.batch || '',
                expiry: r.expiry || '',
                qty: parseInt(r.qty, 10) || 0,
                return_date: r.returnDate || '',
                remarks: r.remarks || '',
                status_before: r.statusBefore || '',
                status_after: r.statusAfter || '',
                remaining_after: parseInt(r.remainingAfter, 10) || 0,
                stock_before: parseInt(r.stockBefore, 10) || 0,
                stock_after: parseInt(r.stockAfter, 10) || 0,
                returned_before: parseInt(r.returnedBefore, 10) || 0,
                source_type: r.sourceType || 'inventory',
                created_at: r.createdAt || '',
                timestamp: parseInt(r.timestamp, 10) || Date.now()
            };
        });
        for (const part of _chunk(rows, 500)) {
            const res = await Database.cloudUpsert('medicine_returns', part);
            if (_hasError(res)) { console.error('MEDICINE_RETURNS SYNC ERROR:', res.error); return res; }
        }
        return true;
    }

    async function syncBillCounterToCloud() {
        const c = AppState.getBillCounter ? AppState.getBillCounter() : Database.Storage.getString(CONFIG.LS_KEYS.BILL_COUNTER, '0');
        const val = parseInt(c, 10);
        var maxNo = 0;
        AppState.billsHistory.forEach(function (b) { maxNo = Math.max(maxNo, (b && b.billNo) || 0); });
        const res = await Database.cloudUpsert('bill_counter', { id: 1, counter: Math.max(isNaN(val) ? 0 : val, maxNo) });
        if (_hasError(res)) { console.error('BILL_COUNTER SYNC ERROR:', res.error); return res; }
        return true;
    }

    var _syncLock = false;

    async function _retry(name, fn, retries) {
        for (var i = 1; i <= retries; i++) {
            try {
                var res = await fn();
                if (_hasError(res)) {
                    if (i < retries) {
                        var delay = Math.min(1000 * Math.pow(2, i - 1), 5000);
                        await new Promise(function (r) { setTimeout(r, delay); });
                        continue;
                    }
                    return res;
                }
                return res;
            } catch (e) {
                if (i < retries) {
                    var delay2 = Math.min(1000 * Math.pow(2, i - 1), 5000);
                    await new Promise(function (r) { setTimeout(r, delay2); });
                    continue;
                }
                return { error: e.message || 'Unknown error' };
            }
        }
    }

    async function syncAllToCloud() {
        if (_syncLock) {
            console.warn('SYNC: pehle se backup chal raha hai, dobara nahi shuru kiya.');
            return false;
        }
        _syncLock = true;
        try {
            // Cloud backup se pehle local pending saves flush karo aur doosre
            // tab ka data merge karo — warna naye bills cloud par miss ho jate.
            await AppState.flushSaves();
            try { await AppState.reconcile(); } catch (_) {}
            await AppState.flushSaves();

            const steps = [
                { name: 'Stock & Batches', fn: syncStockToCloud },
                { name: 'Bills & Items', fn: syncBillsToCloud },
                { name: 'Medicine Returns', fn: syncReturnsToCloud, optional: true },
                { name: 'Suggestions (Doctors/Make/Wholesaler/PatientWords)', fn: syncSuggestionsToCloud },
                { name: 'Bill Counter', fn: syncBillCounterToCloud },
                { name: 'Purchase Bills', fn: syncPurchaseBillsToCloud }
            ];

            let allOk = true;
            for (const step of steps) {
                const res = await _retry(step.name, step.fn, 2);
                if (_hasError(res)) {
                    console.error('SYNC FAILED:', step.name, res.error || '');
                    if (step.optional) {
                        console.warn('SYNC: Optional table skipped — ' + step.name + '. Neon schema check karein.');
                    } else {
                        allOk = false;
                    }
                }
            }
            return allOk;
        } finally {
            _syncLock = false;
        }
    }

    // ==================== CLOUD -> LOCAL (safe merge restore) ====================

    function _buildBackupFromCloud(sStock, sBatches, sBills, sBillItems, sDoctors, sMake, sWhole, sWords, sCounter, sPurchase, sReturns) {
        var batchMap = {};
        (sBatches || []).forEach(function (b) {
            if (!b || !b.stock_id) return;
            if (!batchMap[b.stock_id]) batchMap[b.stock_id] = [];
            batchMap[b.stock_id].push({
                id: b.id || null,
                batch: b.batch || '',
                expiry: b.expiry || '',
                qty: Number(b.qty) || 0,
                stripSize: Number(b.strip_size) || 0,
                price: Number(b.price) || 0
            });
        });

        var stock = (sStock || []).map(function (s) {
            return {
                id: s.id,
                name: s.name,
                wholesaler: s.wholesaler || '',
                make: s.make || '',
                h: !!s.h,
                h1: !!s.h1,
                h2: !!s.h2,
                narcotic: !!s.narcotic,
                batches: batchMap[s.id] || []
            };
        });

        var itemMap = {};
        (sBillItems || []).forEach(function (it) {
            if (!it || !it.bill_id) return;
            if (!itemMap[it.bill_id]) itemMap[it.bill_id] = [];
            itemMap[it.bill_id].push({
                id: it.id || null,
                stockIdx: -1,
                stockId: it.stock_id || null,
                batchIdx: -1,
                particulars: it.particulars || '',
                make: it.make || '',
                h: !!it.h,
                h1: !!it.h1,
                h2: !!it.h2,
                narcotic: !!it.narcotic,
                batch: it.batch || '',
                expiry: it.expiry || '',
                qty: Number(it.qty) || 0,
                amount: Number(it.amount) || 0
            });
        });

        var history = (sBills || []).map(function (b) {
            return {
                id: b.id,
                billNo: Number(b.bill_no) || 0,
                date: b.date || '',
                time: b.time || '',
                patient: b.patient || '',
                doctor: b.doctor || '',
                paymentMode: b.payment_mode || 'Cash',
                total: Number(b.total) || 0,
                items: itemMap[b.id] || [],
                cancelled: !!b.cancelled,
                cancelReason: b.cancel_reason || '',
                cancelledAt: b.cancelled_at || ''
            };
        });

        var purchaseBills = (sPurchase || []).map(function (row) {
            return {
                id: row.id,
                pharmaName: row.pharma_name || '',
                fileName: row.file_name || '',
                fileType: row.file_type || '',
                fileData: row.file_data || '',
                date: row.date || '',
                addedAt: row.added_at || Date.now()
            };
        });

        var returnHistory = (sReturns || []).map(function (row) {
            return {
                id: row.id,
                requestId: row.request_id || '',
                stockId: row.stock_id || '',
                batchId: row.batch_id || '',
                medicineName: row.medicine_name || '',
                make: row.make || '',
                supplier: row.supplier || '',
                batch: row.batch || '',
                expiry: row.expiry || '',
                qty: parseInt(row.qty, 10) || 0,
                returnDate: row.return_date || '',
                remarks: row.remarks || '',
                statusBefore: row.status_before || '',
                statusAfter: row.status_after || '',
                remainingAfter: parseInt(row.remaining_after, 10) || 0,
                stockBefore: parseInt(row.stock_before, 10) || 0,
                stockAfter: parseInt(row.stock_after, 10) || 0,
                returnedBefore: parseInt(row.returned_before, 10) || 0,
                sourceType: row.source_type || 'inventory',
                createdAt: row.created_at || '',
                timestamp: parseInt(row.timestamp, 10) || Date.now()
            };
        });

        return {
            stock: stock,
            history: history,
            doctors: Array.isArray(sDoctors) ? sDoctors.map(function (d) { return d.name; }).filter(Boolean) : [],
            makeList: Array.isArray(sMake) ? sMake.map(function (m) { return m.name; }).filter(Boolean) : [],
            wholesalerList: Array.isArray(sWhole) ? sWhole.map(function (w) { return w.name; }).filter(Boolean) : [],
            patientWords: Array.isArray(sWords) ? sWords.map(function (w) { return w.word; }).filter(Boolean) : [],
            billCounter: (Array.isArray(sCounter) && sCounter.length && Number(sCounter[0].counter)) || 0,
            purchaseBills: purchaseBills,
            returnHistory: returnHistory
        };
    }

    async function fetchAllFromCloud() {
        // Core tables — inme se koi bhi fail ho to restore abort (partial import
        // se data corrupt na ho).
        var core = await Promise.all([
            Database.cloudFetch('stock'),
            Database.cloudFetch('batches'),
            Database.cloudFetch('bills'),
            Database.cloudFetch('bill_items')
        ]);
        var coreNames = ['Stock', 'Batches', 'Bills', 'Bill items'];
        for (var i = 0; i < core.length; i++) {
            if (_hasError(core[i])) {
                return { ok: false, message: coreNames[i] + ' cloud se fetch nahi hua (' + ((core[i] && core[i].error) || 'unknown') + '). Restore cancel — koi change nahi hua.' };
            }
        }
        var sStock = core[0], sBatches = core[1], sBills = core[2], sBillItems = core[3];

        // Empty / partial remote protection — khali cloud se restore karne par
        // bhi kuch nahi hota, par user ko saaf batana zaroori hai.
        if ((!sStock || !sStock.length) && (!sBills || !sBills.length)) {
            return { ok: false, message: 'Cloud backup khali hai — restore karne ke liye pehle "Backup to DB" karein.' };
        }
        if (sBills && sBills.length && (!sBillItems || !sBillItems.length)) {
            return { ok: false, message: 'Cloud mein bills hain lekin unke items nahi mile. Partial backup hai — restore cancel.' };
        }
        if (sStock && sStock.length && (!sBatches || !sBatches.length)) {
            return { ok: false, message: 'Cloud mein stock hain lekin batches nahi mile. Partial backup hai — restore cancel.' };
        }

        // Optional tables — fail ho to bhi core restore chalega.
        var optional = await Promise.all([
            Database.cloudFetch('doctors'),
            Database.cloudFetch('make_list'),
            Database.cloudFetch('wholesaler_list'),
            Database.cloudFetch('patient_words'),
            Database.cloudFetch('bill_counter'),
            Database.cloudFetch('purchase_bills'),
            Database.cloudFetch('medicine_returns')
        ]);
        var sDoctors = _hasError(optional[0]) ? [] : optional[0];
        var sMake = _hasError(optional[1]) ? [] : optional[1];
        var sWhole = _hasError(optional[2]) ? [] : optional[2];
        var sWords = _hasError(optional[3]) ? [] : optional[3];
        var sCounter = _hasError(optional[4]) ? [] : optional[4];
        var sPurchase = _hasError(optional[5]) ? [] : optional[5];
        var sReturns = _hasError(optional[6]) ? [] : optional[6];

        var backup = _buildBackupFromCloud(
            sStock, sBatches, sBills, sBillItems,
            sDoctors, sMake, sWhole, sWords, sCounter, sPurchase, sReturns
        );

        // Safe merge — existing local data delete/overwrite nahi hota.
        var report = await AppState.importAllData(backup);
        if (!report || !report.ok) {
            return { ok: false, message: (report && report.fatal && report.fatal.join(' | ')) || 'Import fail hua.', report: report };
        }
        return { ok: true, report: report };
    }

    // ==================== CLOUD CLEAR (explicit user action only) ====================

    async function deleteAllFromCloud() {
        var hadError = false;
        var FETCH_EMPTY = {};

        var _fetchIds = async function (table, idCol) {
            try {
                var data = await Database.cloudFetch(table);
                if (!data) { console.error('DELETE: fetch ' + table + ' returned null/undefined'); hadError = true; return FETCH_EMPTY; }
                if (typeof data === 'object' && data.error) { console.error('DELETE: fetch ' + table + ' failed:', data.error); hadError = true; return FETCH_EMPTY; }
                if (!Array.isArray(data)) { console.error('DELETE: fetch ' + table + ' returned non-array:', typeof data); hadError = true; return FETCH_EMPTY; }
                var ids = data.map(function (r) { return r[idCol]; }).filter(Boolean);
                return ids;
            } catch (e) {
                console.error('DELETE: fetch ' + table + ' threw:', e.message || e);
                hadError = true;
                return FETCH_EMPTY;
            }
        };

        var _del = async function (table, col, vals) {
            if (vals === FETCH_EMPTY || !vals || !vals.length) return;
            try {
                var res = await Database.cloudDeleteMany(table, col, vals);
                if (!res || (typeof res === 'object' && res.error)) {
                    console.error('DELETE: ' + table + ' failed:', res && res.error);
                    hadError = true;
                }
            } catch (e) {
                console.error('DELETE: ' + table + ' threw:', e.message || e);
                hadError = true;
            }
        };

        // Delete stock & batches
        var stockIds = await _fetchIds('stock', 'id');
        if (stockIds !== FETCH_EMPTY && stockIds.length) {
            await _del('batches', 'stock_id', stockIds);
            await _del('stock', 'id', stockIds);
        } else {
            try {
                var allBatchIds = await _fetchIds('batches', 'id');
                if (allBatchIds !== FETCH_EMPTY && allBatchIds.length) {
                    await _del('batches', 'id', allBatchIds);
                }
            } catch (e2) { console.error('DELETE: batch fallback error:', e2); }
            try {
                var retryStockIds = await _fetchIds('stock', 'id');
                if (retryStockIds !== FETCH_EMPTY && retryStockIds.length) {
                    await _del('stock', 'id', retryStockIds);
                }
            } catch (e3) { console.error('DELETE: stock retry error:', e3); }
        }

        // Delete bills & items
        var billIds = await _fetchIds('bills', 'id');
        if (billIds !== FETCH_EMPTY && billIds.length) {
            await _del('bill_items', 'bill_id', billIds);
            await _del('bills', 'id', billIds);
        }

        // Delete suggestion tables
        var tblDefs = [
            { table: 'doctors', col: 'name' },
            { table: 'make_list', col: 'name' },
            { table: 'wholesaler_list', col: 'name' },
            { table: 'patient_words', col: 'word' }
        ];
        for (var ti = 0; ti < tblDefs.length; ti++) {
            var td = tblDefs[ti];
            var ids = await _fetchIds(td.table, td.col);
            if (ids !== FETCH_EMPTY) await _del(td.table, td.col, ids);
        }

        // Delete bill counter
        try {
            var cnt = await Database.cloudFetch('bill_counter');
            if (Array.isArray(cnt) && cnt.length) {
                await _del('bill_counter', 'id', cnt.map(function (r) { return r.id; }));
            }
        } catch (e) {
            console.error('DELETE: bill_counter error:', e);
        }

        // Delete purchase bills
        try {
            var pbData = await Database.cloudFetch('purchase_bills');
            if (Array.isArray(pbData) && pbData.length) {
                await _del('purchase_bills', 'id', pbData.map(function (r) { return r.id; }));
            }
        } catch (e) {
            console.error('DELETE: purchase_bills error:', e);
        }

        // Delete return audit history (optional table — missing table ignore)
        try {
            var retData = await Database.cloudFetch('medicine_returns');
            if (Array.isArray(retData) && retData.length) {
                var retIds = retData.map(function (r) { return r.id; }).filter(Boolean);
                if (retIds.length) await Database.cloudDeleteMany('medicine_returns', 'id', retIds);
            } else if (retData && typeof retData === 'object' && retData.error) {
                console.warn('DELETE: medicine_returns optional table skipped:', retData.error);
            }
        } catch (e) {
            console.warn('DELETE: medicine_returns optional table skipped:', e.message || e);
        }

        return !hadError;
    }

    return {
        syncAllToCloud,
        fetchAllFromCloud,
        deleteAllFromCloud,
        syncStockToCloud,
        syncBillsToCloud,
        syncSuggestionsToCloud,
        syncBillCounterToCloud,
        syncPurchaseBillsToCloud,
        syncReturnsToCloud
    };
})();
