const Billing = (() => {
    let _activeBillItems = [];
    let _activeTotal = 0;
    let _selectedBatchIdx = -1;
    let _selectedStockIdx = -1;
    let _isFreeEntry = false;
    let _sugHighlight = -1;
    let _patHighlight = -1;
    let _lastPreviewBill = null;
    let _billSaving = false;
    // Recovery re-entry: printed copy ka asli bill number use karna hai.
    let _recoveryBillNo = null;
    let _recoverySkipStock = true;

    function resetBillingForm() {
        _lastPreviewBill = null;
        _resetBatchUI();
        _activeBillItems = [];
        _activeTotal = 0;
        _selectedStockIdx = -1;
        _isFreeEntry = false;
        _renderCurrentBillList();
        _setValue('medNameInput', '');
        _setValue('entryQty', '');
        _setValue('billPatient', '');
        _setValue('billDoctor', '');
        document.getElementById('billPaymentMode').value = 'Cash';
        _resetDateToToday();
    }

    function _resetDateToToday() {
        document.getElementById('billDate').value = Utils.formatDateForInput();
    }

    function _resetBatchUI() {
        _selectedBatchIdx = -1;
        _hide('batchSelectorArea');
        _hide('selectedBatchInfo');
        _hide('freeMedFields');
        const bs = document.getElementById('selByBatch');
        const es = document.getElementById('selByExpiry');
        if (bs) { bs.innerHTML = '<option value="">-- Batch No. Chunein --</option>'; bs.size = 1; }
        if (es) { es.innerHTML = '<option value="">-- Expiry Chunein --</option>'; es.size = 1; }
        _hide('qtyWarning');
    }

    function _setValue(id, val) {
        const el = document.getElementById(id);
        if (el) el.value = val;
    }

    function _hide(id) {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    }

    function _show(id, display) {
        const el = document.getElementById(id);
        if (el) el.style.display = display || 'block';
    }

    // Expired batch kabhi bill mein nahi ja sakti — suggestion, batch select,
    // add-item aur final stock check, sab jagah same rule.
    function _isSellableBatch(batch) {
        if (!batch) return false;
        return (parseInt(batch.qty, 10) || 0) > 0 && !Utils.isExpired(batch.expiry);
    }

    function _sellableBatchIndexes(med) {
        const out = [];
        (med && med.batches || []).forEach(function (b, idx) {
            if (_isSellableBatch(b)) out.push(idx);
        });
        return out;
    }

    function _hasExpiredQty(med) {
        return (med && med.batches || []).some(function (b) {
            return (parseInt(b.qty, 10) || 0) > 0 && Utils.isExpired(b.expiry);
        });
    }

    // ==================== MEDICINE SEARCH ====================

    function onMedNameInput(val) {
        _sugHighlight = -1;
        const box = document.getElementById('medNameSuggestions');
        _selectedStockIdx = -1;
        _isFreeEntry = false;
        _resetBatchUI();
        _hide('freeMedFields');

        const q = val.trim().toLowerCase();
        if (!q) { _hideMedSuggestions(); return; }

        const isBatchSearch = /^[a-zA-Z0-9-]+$/.test(q) && q.length >= 2;
        const matches = AppState.stockData
            .map((item, idx) => {
                let matchedBatch = -1;
                if (isBatchSearch) matchedBatch = (item.batches || []).findIndex(b => _isSellableBatch(b) && b.batch && b.batch.toLowerCase().includes(q));
                return { item, idx, matchedBatch, nameMatched: item.name.toLowerCase().includes(q) };
            })
            .filter(({ matchedBatch, nameMatched }) => nameMatched || matchedBatch >= 0);

        Utils.clearElement(box);

        matches.sort((a, b) => {
            if (a.matchedBatch >= 0 && b.matchedBatch < 0) return -1;
            if (a.matchedBatch < 0 && b.matchedBatch >= 0) return 1;
            return a.item.name.localeCompare(b.item.name);
        });

        matches.forEach(({ item, idx, matchedBatch }) => {
            const totalQty = (item.batches || []).reduce((s, b) => s + (_isSellableBatch(b) ? (parseInt(b.qty, 10) || 0) : 0), 0);
            const row = document.createElement('div');
            row.className = 'suggestion-item';

            const nameSpan = document.createElement('span');
            nameSpan.textContent = item.name;
            if (item.wholesaler) {
                var wsBadge = document.createElement('span');
                wsBadge.style.cssText = 'background:#e0e7ff;color:#3730a3;font-size:10px;font-weight:600;padding:1px 6px;border-radius:8px;margin-left:4px;';
                wsBadge.textContent = item.wholesaler;
                nameSpan.appendChild(wsBadge);
            }
            if (item.h1) {
                const h1Badge = document.createElement('span');
                h1Badge.className = 'sug-badge';
                h1Badge.textContent = ' H1';
                nameSpan.appendChild(h1Badge);
            }
            if (matchedBatch >= 0) {
                const batchBadge = document.createElement('span');
                batchBadge.style.cssText = 'background:#e0e7ff;color:#3730a3;font-size:10px;font-weight:700;padding:1px 6px;border-radius:8px;margin-left:4px;';
                batchBadge.textContent = 'Batch: ' + item.batches[matchedBatch].batch;
                nameSpan.appendChild(batchBadge);
            }

            const badge = document.createElement('span');
            const expiredOnly = totalQty <= 0 && _hasExpiredQty(item);
            badge.className = 'sug-badge' + (totalQty <= 0 ? ' out' : '');
            badge.textContent = expiredOnly ? 'Expired only' : (totalQty <= 0 ? 'Out of Stock' : totalQty + ' available');
            row.title = expiredOnly ? 'Expired stock bill mein add nahi ho sakta — Return History se supplier ko return karein.' : '';

            row.appendChild(nameSpan);
            row.appendChild(badge);
            row.addEventListener('click', () => _selectMedFromSuggestion(idx, matchedBatch));
            box.appendChild(row);
        });

        const freeDiv = document.createElement('div');
        freeDiv.className = 'suggestion-item free-entry';
        const freeSpan = document.createElement('span');
        freeSpan.textContent = '➕ "' + val.trim() + '" — Manually add (not in inventory)';
        freeDiv.appendChild(freeSpan);
        freeDiv.addEventListener('click', () => _selectFreeEntry(val.trim()));
        box.appendChild(freeDiv);

        box.style.display = 'block';
    }

    function _hideMedSuggestions() {
        var el = document.getElementById('medNameSuggestions');
        if (el) el.style.display = 'none';
        _sugHighlight = -1;
    }

    function _selectMedFromSuggestion(stockIdx, preselectBatch) {
        _selectedStockIdx = stockIdx;
        _isFreeEntry = false;
        const med = AppState.stockData[stockIdx];
        const sellable = _sellableBatchIndexes(med);
        document.getElementById('medNameInput').value = med.name;
        _hideMedSuggestions();
        _hide('freeMedFields');

        if (!sellable.length) {
            _selectedStockIdx = -1;
            _selectedBatchIdx = -1;
            _resetBatchUI();
            UI.showToast('❌ Is medicine ki koi bhi batch sale ke liye available nahi hai (expired/out of stock). Expired stock Return History se return karein.', 'error', 5000);
            return;
        }

        if (sellable.length === 1) {
            _selectedBatchIdx = sellable[0];
            _showSelectedBatchInfo(med, sellable[0]);
            _hide('batchSelectorArea');
            setTimeout(() => document.getElementById('entryQty').focus(), 50);
        } else if (typeof preselectBatch === 'number' && preselectBatch >= 0 && sellable.indexOf(preselectBatch) !== -1) {
            _selectedBatchIdx = preselectBatch;
            _showSelectedBatchInfo(med, preselectBatch);
            _hide('batchSelectorArea');
            setTimeout(() => document.getElementById('entryQty').focus(), 50);
        } else {
            _selectedBatchIdx = -1;
            _populateBatchSelectors(med);
            setTimeout(() => {
                const sel = document.getElementById('selByBatch');
                sel.focus();
                const visibleRows = Math.min(sellable.length + 1, 7);
                sel.size = visibleRows;
                document.getElementById('selByExpiry').size = visibleRows;
            }, 60);
        }
    }

    function _populateBatchSelectors(med) {
        const batchSel = document.getElementById('selByBatch');
        const expirySel = document.getElementById('selByExpiry');
        Utils.clearElement(batchSel);
        Utils.clearElement(expirySel);
        batchSel.appendChild(Utils.createOption('', '-- Batch No. Chunein --'));
        expirySel.appendChild(Utils.createOption('', '-- Expiry Chunein --'));

        (med.batches || []).forEach((b, bIdx) => {
            if (!_isSellableBatch(b)) return;
            const bOpt = Utils.createOption(String(bIdx), b.batch + '  (Stock: ' + b.qty + ')');
            batchSel.appendChild(bOpt);

            const eOpt = Utils.createOption(String(bIdx), b.expiry + '  — Batch: ' + b.batch);
            expirySel.appendChild(eOpt);
        });
        _show('batchSelectorArea');
    }

    function _selectFreeEntry(name) {
        _isFreeEntry = true;
        _selectedStockIdx = -1;
        _selectedBatchIdx = -1;
        document.getElementById('medNameInput').value = name;
        _hideMedSuggestions();
        _hide('batchSelectorArea');
        _hide('selectedBatchInfo');
        _show('freeMedFields');
        setTimeout(() => document.getElementById('freeBatch').focus(), 50);
    }

    function _showSelectedBatchInfo(med, bIdx) {
        const b = med.batches[bIdx];
        if (!b) { _hide('selectedBatchInfo'); return; }
        if (!_isSellableBatch(b)) {
            _selectedBatchIdx = -1;
            _hide('selectedBatchInfo');
            UI.showToast('❌ Yeh batch expired ya out of stock hai — bill mein add nahi ho sakti.', 'error', 4500);
            return;
        }
        const alreadyInBill = _activeBillItems
            .filter(item => item.stockIdx === _selectedStockIdx && item.batchIdx === bIdx)
            .reduce((sum, item) => sum + item.qty, 0);
        const actualAvailable = b.qty - alreadyInBill;

        Utils.sanitizeAndSet(document.getElementById('infoBatch'), b.batch || 'N/A');
        Utils.sanitizeAndSet(document.getElementById('infoExpiry'), b.expiry || 'N/A');
        Utils.sanitizeAndSet(document.getElementById('infoPrice'), Number(b.price || 0).toFixed(2));
        Utils.sanitizeAndSet(document.getElementById('infoStock'), actualAvailable + (alreadyInBill > 0 ? ' (Bill mein ' + alreadyInBill + ' already hai)' : ''));

        const chip = document.getElementById('infoStockChip');
        chip.className = 'info-chip' + (actualAvailable <= 0 ? ' danger' : actualAvailable < 20 ? ' warn' : '');
        _show('selectedBatchInfo');
    }

    function validateQtyInput() {
        if (_isFreeEntry || _selectedStockIdx < 0 || _selectedBatchIdx < 0) return;
        const batches = AppState.stockData[_selectedStockIdx]?.batches;
        const b = batches ? batches[_selectedBatchIdx] : undefined;
        if (!b) return;
        const qty = parseInt(document.getElementById('entryQty').value, 10);
        const alreadyInBill = _activeBillItems
            .filter(item => item.stockIdx === _selectedStockIdx && item.batchIdx === _selectedBatchIdx)
            .reduce((sum, item) => sum + item.qty, 0);
        const actualAvailable = b.qty - alreadyInBill;
        const warn = document.getElementById('qtyWarning');
        if (!isNaN(qty) && qty > actualAvailable) {
            warn.textContent = '⚠ Sirf ' + actualAvailable + ' units available hain (bill mein pehle se ' + alreadyInBill + ' add hai)!';
            warn.style.display = 'block';
        } else {
            warn.style.display = 'none';
        }
    }

    // ==================== ADD ITEM ====================

    function addItemToCurrentBill() {
        const nameVal = document.getElementById('medNameInput').value.trim();
        if (!nameVal) { UI.showToast('Medicine naam daalna zaroori hai!', 'error'); return; }

        if (_isFreeEntry) {
            _addFreeEntryItem(nameVal);
            return;
        }

        if (_selectedStockIdx < 0) { UI.showToast('Medicine chunna ya naam type karke select karna zaroori hai!', 'error'); return; }
        if (_selectedBatchIdx < 0) { UI.showToast('Batch / Expiry select karein!', 'error'); return; }

        _addInventoryItem();
    }

    function _addFreeEntryItem(nameVal) {
        const batch = document.getElementById('freeBatch').value.trim();
        const expiry = document.getElementById('freeExpiry').value.trim();
        const price = parseFloat(document.getElementById('freePrice').value);
        const qty = parseInt(document.getElementById('entryQty').value, 10);

        if (!batch) { UI.showToast('Batch number daalna zaroori hai!', 'error'); document.getElementById('freeBatch').focus(); return; }
        if (expiry.length < 7 || !/^\d{2}\/\d{4}$/.test(expiry)) { UI.showToast('Expiry date MM/YYYY format mein bharein!', 'error'); document.getElementById('freeExpiry').focus(); return; }
        const expMonth = parseInt(expiry.split('/')[0], 10);
        if (expMonth < 1 || expMonth > 12) { UI.showToast('Month 1-12 ke beech me daalein!', 'error'); document.getElementById('freeExpiry').focus(); return; }
        if (Utils.isExpired(expiry)) { UI.showToast('❌ Expired medicine bill mein add nahi ho sakti! Return History se supplier ko return karein.', 'error', 5000); document.getElementById('freeExpiry').focus(); return; }
        if (isNaN(price) || price < 0) { UI.showToast('Price sahi daalna zaroori hai!', 'error'); document.getElementById('freePrice').focus(); return; }
        if (isNaN(qty) || qty <= 0) { UI.showToast('Quantity sahi daalna zaroori hai!', 'error'); document.getElementById('entryQty').focus(); return; }

        _activeBillItems.push({
            stockIdx: -1, stockId: null, batchIdx: -1, manual: true,
            particulars: nameVal, make: '', h: false, h1: false, h2: false, narcotic: false,
            batch, expiry, qty, amount: price * qty
        });
        _renderCurrentBillList();
        _clearBillingInputs();
    }

    function _addInventoryItem() {
        const med = AppState.stockData[_selectedStockIdx];
        const b = med.batches[_selectedBatchIdx];
        if (!b) { UI.showToast('Batch select karein!', 'error'); return; }
        if (Utils.isExpired(b.expiry)) { UI.showToast('❌ Expired batch bill mein add nahi ho sakti! Return History se return karein.', 'error', 5000); return; }
        const qty = parseInt(document.getElementById('entryQty').value, 10);
        if (isNaN(qty) || qty <= 0) { UI.showToast('Quantity sahi daalna zaroori hai!', 'error'); return; }

        const alreadyInBill = _activeBillItems
            .filter(item => item.stockIdx === _selectedStockIdx && item.batchIdx === _selectedBatchIdx)
            .reduce((sum, item) => sum + item.qty, 0);
        const actualAvailable = b.qty - alreadyInBill;

        if (qty > actualAvailable) {
            const msg = alreadyInBill > 0
                ? 'Is batch mein sirf ' + b.qty + ' units hain. Bill mein pehle se ' + alreadyInBill + ' add ho chuki hain. Ab sirf ' + actualAvailable + ' aur add kar sakte ho!'
                : 'Sirf ' + b.qty + ' units available hain is batch mein!';
            UI.showToast(msg, 'warn', 4000);
            return;
        }

        _activeBillItems.push({
            stockIdx: _selectedStockIdx, stockId: med.id, batchIdx: _selectedBatchIdx, manual: false,
            particulars: med.name, make: med.make || '',
            h: med.h || false, h1: med.h1 || false, h2: med.h2 || false, narcotic: med.narcotic || false,
            batch: b.batch, expiry: b.expiry, qty, amount: b.price * qty
        });
        _renderCurrentBillList();
        _clearBillingInputs();
    }

    function _clearBillingInputs() {
        _setValue('medNameInput', '');
        _setValue('entryQty', '');
        _setValue('freeBatch', '');
        _setValue('freeExpiry', '');
        _setValue('freePrice', '');
        _selectedStockIdx = -1;
        _isFreeEntry = false;
        _resetBatchUI();
        _hideMedSuggestions();
        setTimeout(() => document.getElementById('medNameInput').focus(), 30);
    }

    function _renderCurrentBillList() {
        const tbody = document.getElementById('currentBillTableBody');
        Utils.clearElement(tbody);
        _activeTotal = 0;

        _activeBillItems.forEach((item, index) => {
            _activeTotal += item.amount;
            const tr = document.createElement('tr');

            const tdName = document.createElement('td');
            const strong = document.createElement('strong');
            strong.textContent = item.particulars;
            tdName.appendChild(strong);
            if (item.manual === true || (!item.stockId && item.stockIdx === -1)) {
                const manualBadge = document.createElement('span');
                manualBadge.style.cssText = 'font-size:10px;background:#fef3c7;color:#92400e;padding:1px 6px;border-radius:8px;font-weight:700;margin-left:4px;';
                manualBadge.textContent = 'Manual';
                tdName.appendChild(manualBadge);
            }
            tr.appendChild(tdName);

            const tdBatch = document.createElement('td');
            tdBatch.style.cssText = 'color:#6b7280;';
            tdBatch.textContent = item.batch;
            tr.appendChild(tdBatch);

            const tdExpiry = document.createElement('td');
            tdExpiry.style.cssText = 'color:#6b7280;';
            tdExpiry.textContent = item.expiry;
            tr.appendChild(tdExpiry);

            const tdQty = document.createElement('td');
            tdQty.style.cssText = 'text-align:right;font-weight:700;';
            tdQty.textContent = String(item.qty);
            tr.appendChild(tdQty);

            const tdAmount = document.createElement('td');
            tdAmount.style.cssText = 'text-align:right;font-weight:700;color:#1a56db;';
            tdAmount.textContent = '₹' + item.amount.toFixed(2);
            tr.appendChild(tdAmount);

            const tdAction = document.createElement('td');
            const removeBtn = document.createElement('button');
            removeBtn.className = 'btn-danger';
            removeBtn.textContent = '✕ Remove';
            removeBtn.addEventListener('click', () => _removeCurrentBillItem(index));
            tdAction.appendChild(removeBtn);
            tr.appendChild(tdAction);

            tbody.appendChild(tr);
        });

        document.getElementById('currentTotalDisplay').textContent = _activeTotal.toFixed(2);
        document.getElementById('billItemCount').textContent = String(_activeBillItems.length);
    }

    function _removeCurrentBillItem(index) {
        _activeBillItems.splice(index, 1);
        _renderCurrentBillList();
    }

    // ==================== MISSING BILL RE-ENTRY (PRINTED COPY) ====================
    function _setRecoveryStatus(msg, isError) {
        var el = document.getElementById('recoveryBillStatus');
        if (!el) return;
        el.textContent = msg || '';
        el.style.color = isError ? '#b91c1c' : '#047857';
    }

    function toggleRecoveryPanel() {
        var panel = document.getElementById('recoveryBillPanel');
        if (!panel) return;
        var show = panel.style.display === 'none';
        panel.style.display = show ? 'block' : 'none';
        if (show) {
            var inp = document.getElementById('recoveryBillNoInput');
            if (inp) inp.focus();
        }
    }

    function setRecoveryBillNo(rawNo, skipStock) {
        var n = parseInt(rawNo, 10);
        if (!n || n <= 0) {
            _setRecoveryStatus('Valid bill number daalein (printed copy wala).', true);
            UI.showToast('Valid recovery bill number daalein!', 'error');
            return false;
        }
        var used = (AppState.billsHistory || []).find(function (b) { return (b && b.billNo) === n; });
        if (used) {
            _setRecoveryStatus('#' + n + ' pehle se history mein hai — dobara na daalein.', true);
            UI.showToast('Bill #' + n + ' pehle se save hai!', 'error');
            return false;
        }
        _recoveryBillNo = n;
        _recoverySkipStock = skipStock !== false;
        _setRecoveryStatus('✔ Recovery mode ON: bill #' + n + (_recoverySkipStock ? ' — stock dobara nahi kata jayega.' : ' — stock dobara kata jayega.'));
        UI.showToast('Recovery mode ON — is bill ke liye printed number #' + n + ' use hoga.', 'warn', 6000);
        return true;
    }

    function applyRecoveryBillNo() {
        var inp = document.getElementById('recoveryBillNoInput');
        var skip = document.getElementById('recoverySkipStock');
        return setRecoveryBillNo(inp ? inp.value : '', !!(skip && skip.checked));
    }

    function clearRecoveryMode() {
        _recoveryBillNo = null;
        _recoverySkipStock = true;
        var inp = document.getElementById('recoveryBillNoInput');
        if (inp) inp.value = '';
        _setRecoveryStatus('');
    }

    // ==================== PRINT BILL ====================

    async function _submitBill(printAfterSave) {
        if (_billSaving) {
            UI.showToast('⏳ Bill save ho raha hai — ek second rukein.', 'warn', 3000);
            return;
        }
        const patient = document.getElementById('billPatient').value.trim() || 'Cash Customer';
        var doctorRaw = document.getElementById('billDoctor').value.trim();
        const doctor = !doctorRaw ? 'Self' : (doctorRaw.toLowerCase() === 'self' ? 'Self' : doctorRaw);
        const dateRaw = document.getElementById('billDate').value;
        if (!dateRaw) { UI.showToast('Bill Date select karein!', 'error'); return; }
        const date = dateRaw.split('-').reverse().join('/');
        if (_activeBillItems.length === 0) { UI.showToast('Bill khali hai!', 'error'); return; }

        if (_recoveryBillNo) {
            var already = (AppState.billsHistory || []).find(function (b) { return (b && b.billNo) === _recoveryBillNo; });
            if (already) {
                _setRecoveryStatus('#' + _recoveryBillNo + ' ab pehle se save ho gaya — recovery mode band.', true);
                clearRecoveryMode();
                UI.showToast('Bill #' + already.billNo + ' pehle se hai — duplicate nahi banaya.', 'error', 7000);
                return;
            }
        }

        // Recovery mode me stock already kata ho to dobara check/cut nahi karo.
        if (!_recoverySkipStock && !_checkStockAvailable()) return;
        AppState.savePatientName(patient);
        _saveDoctorName(doctor);
        const billNo = _recoveryBillNo || AppState.getNextBillNumber();
        const paymentMode = document.getElementById('billPaymentMode').value;
        const timeStr = Utils.getTimeStr();

        const bill = {
            id: Utils.generateId('bill'),
            billNo,
            date,
            time: timeStr,
            patient,
            doctor: doctor === 'Self' ? 'Self' : (doctor.startsWith('Dr.') ? doctor : 'Dr. ' + doctor),
            paymentMode,
            items: [..._activeBillItems],
            total: _activeTotal
        };

        _billSaving = true;
        try {
            const billRes = await AppState.addBill(bill);
            if (!billRes || !billRes.ok) {
                // addBill failure par memory rollback ho chuka hai; form data
                // yahin safe hai. User ko saaf warning do — reset/print nahi.
                UI.showToast('❌ Bill save NAHI hua! Form ka data safe hai — turant Offline Backup download karein, phir dobara Save karein. App band na karein.', 'error', 12000);
                return;
            }

            if (_recoverySkipStock) {
                console.info('Recovery bill #' + bill.billNo + ': stock deduction skipped (printed copy re-entry).');
            } else {
                const stockRes = await _deductStock();
                if (!stockRes || !stockRes.ok) {
                    UI.showToast('⚠️ Bill #' + bill.billNo + ' save ho gaya, lekin stock save fail hua. Turant Offline Backup download karein.', 'warn', 10000);
                }
            }

            if (_recoveryBillNo) clearRecoveryMode();
            _resetAfterPrint();
            if (typeof Notifications !== 'undefined') Notifications.renderPanel();

            if (printAfterSave) {
                // SINGLE PRINT MODE — sirf RAW ESC/P Dot Matrix LX-310
                printRawBill(bill);
            } else {
                // Save + Preview only — NO automatic printing
                showBillPreview(bill);
                UI.showToast('✅ Bill #' + bill.billNo + ' save ho gaya! Preview dikh raha hai.', 'success', 3000);
            }
        } catch (e) {
            console.error('BILL SAVE ERROR:', e);
            UI.showToast('❌ Bill save error: ' + (e.message || e) + ' — form safe hai, dobara try karein.', 'error', 10000);
        } finally {
            _billSaving = false;
        }
    }

    function processAndPrintBill() {
        return _submitBill(true);
    }

    // ==================== PREVIEW & SAVE BILL (NEW — no auto print) ====================

    function previewAndSaveBill() {
        return _submitBill(false);
    }

    function showBillPreview(bill) {
        if (!bill) return;
        _lastPreviewBill = bill;
        const area = document.getElementById('billPreviewArea');
        const modal = document.getElementById('billPreviewModal');
        if (!area || !modal) return;
        // Reuse existing bill template — Preview and Print look identical
        area.innerHTML = buildBillHtml(bill);
        modal.style.display = 'flex';
        // close on overlay click
        modal.onclick = function(e) { if (e.target === modal) closePreview(); };
    }

    function closePreview() {
        const modal = document.getElementById('billPreviewModal');
        if (modal) modal.style.display = 'none';
    }

    function printLastPreviewedBill() {
        if (!_lastPreviewBill) { UI.showToast('Koi preview bill nahi hai!', 'error'); return; }
        printRawBill(_lastPreviewBill);
    }

    function previewOldBillByNo(billNo) {
        const bill = AppState.billsHistory.find(function(b) { return b.billNo === billNo; });
        if (!bill) { UI.showToast('Bill nahi mila!', 'error'); return; }
        showBillPreview(bill);
    }

    // Native / printer-friendly text print — new window mein <pre> dikha ke browser
    // print dialog kholta hai (frontend-only, koi server nahi chahiye)
    function printNativeText(bill) {
        const text = Utils.buildBillText(bill);
        const w = window.open('', '_blank');
        if (!w) { UI.showToast('Popup blocked! Print ke liye allow karein.', 'error'); return; }
        w.document.write('<pre style="font-family:monospace;font-size:12px;white-space:pre;margin:0;padding:10px;">' + text.replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</pre>');
        w.document.title = 'Bill-' + bill.billNo;
        w.document.close();
        setTimeout(function () { try { w.focus(); w.print(); } catch (e) {} }, 400);
    }

    // Raw ESC/P print — printer ke liye raw bytes banaye (condensed pitch wala) aur
    // server ke /api/print-raw endpoint pe bheje (LX-310 dot matrix ke liye direct)
    function printRawBill(bill) {
        const bytes = Utils.buildBillEscP(bill);
        Database.printRawEscP(bytes).then(function (ok) {
            if (ok) UI.showToast('Raw ESC/P print bhej diya!', 'success');
            else UI.showToast('Raw print fail — check printer / server.', 'error');
        });
    }

    // Notepad print — compact text banaye aur server ke /api/print-text endpoint pe
    // bheje jo Notepad mein khol deta hai (manual print ke liye)
    function notepadPrint(bill) {
        const text = Utils.buildBillTextCompact(bill);
        Database.printTextToNotepad(text).then(function () {
            UI.showToast('Notepad print file taiyaar!', 'info');
        });
    }

    function _triggerPrint(iframe) {
        try { iframe.contentWindow.focus(); iframe.contentWindow.print(); }
        catch (e) { iframe.contentWindow.print(); }
    }

    // HTML print fallback — browser print dialog use karo (new window mein inline-styled
    // bill HTML likhte hain taaki bina kisi CSS ke bhi sahi print aaye)
    function _smartPrintHtml(bill) {
        const w = window.open('', '_blank');
        if (!w) { UI.showToast('Popup blocked! Print ke liye allow karein.', 'error'); return; }
        w.document.write('<div class="bill-card">' + buildBillHtml(bill) + '</div>');
        w.document.title = 'Bill-' + bill.billNo;
        w.document.close();
        setTimeout(function () { try { w.focus(); w.print(); } catch (e) {} }, 400);
    }

    function buildBillHtml(bill) {
        const items = bill.items || [];
        let rows = '';
        items.forEach(function (it, i) {
            rows += '<tr>'
                + '<td>' + (i + 1) + '</td>'
                + '<td>' + Utils.escapeHtml(it.particulars || '') + ((it.manual === true || (!it.stockId && it.stockIdx === -1)) ? ' <span style="font-size:10px;background:#fef3c7;color:#92400e;padding:1px 6px;border-radius:8px;font-weight:700;">Manual</span>' : '') + '</td>'
                + '<td>' + Utils.escapeHtml(it.make || '') + '</td>'
                + '<td>' + Utils.escapeHtml(it.batch || '') + '</td>'
                + '<td>' + Utils.escapeHtml(it.expiry || '') + '</td>'
                + '<td style="text-align:right;">' + it.qty + '</td>'
                + '<td style="text-align:right;">Rs.' + (it.amount || 0).toFixed(2) + '</td>'
                + '</tr>';
        });
        const info = CONFIG.STORE_INFO;
        return '<div style="font-family:Arial, sans-serif;padding:12px;color:#000;">'
            + '<h2 style="text-align:center;margin:0 0 4px;">CASH MEMO</h2>'
            + '<h3 style="text-align:center;margin:0 0 2px;">' + Utils.escapeHtml(info.name) + '</h3>'
            + '<p style="text-align:center;margin:0 0 2px;font-size:12px;">' + Utils.escapeHtml(info.address) + '</p>'
            + '<p style="text-align:center;margin:0 0 2px;font-size:12px;">Mob: ' + Utils.escapeHtml(info.mob) + '</p>'
            + '<p style="text-align:center;margin:0 0 2px;font-size:12px;">FSSAI No: ' + Utils.escapeHtml(info.fssai) + ' &nbsp; D.L. No: ' + Utils.escapeHtml(info.dlNo) + '</p>'
            + '<hr style="border:none;border-top:1px dashed #000;margin:6px 0;">'
            + '<p style="margin:2px 0;font-size:13px;"><b>Invoice No:</b> ' + (Number(bill.billNo) || 0) + ' &nbsp; <b>Date:</b> ' + Utils.escapeHtml(bill.date) + '</p>'
            + '<p style="margin:2px 0;font-size:13px;"><b>Patient:</b> ' + Utils.escapeHtml(bill.patient || 'Cash Customer') + ' &nbsp; <b>Doctor:</b> ' + Utils.escapeHtml(bill.doctor || 'Self') + '</p>'
            + '<p style="margin:2px 0 6px;font-size:12px; color:#555;"><b>Payment:</b> ' + Utils.escapeHtml(bill.paymentMode || 'Cash') + '</p>'
            + '<table style="width:100%;border-collapse:collapse;font-size:12px;">'
            + '<thead><tr style="border-bottom:1px solid #000;"><th style="text-align:left;">#</th><th style="text-align:left;">Particulars</th><th style="text-align:left;">Make</th><th style="text-align:left;">Batch</th><th style="text-align:left;">Expiry</th><th style="text-align:right;">Qty</th><th style="text-align:right;">Amount</th></tr></thead>'
            + '<tbody>' + rows + '</tbody></table>'
            + '<hr style="border:none;border-top:1px dashed #000;margin:6px 0;">'
            + '<p style="text-align:right;font-size:16px;margin:4px 0;"><b>GRAND TOTAL: Rs.' + (bill.total || 0).toFixed(2) + '</b></p>'
            + '<p style="text-align:center;font-size:11px;margin:6px 0 0;">* Thank you! Medicine once sold will not be taken back.</p>'
            + '<p style="text-align:center;font-size:11px;margin:2px 0;">* Please show medicine to doctor *</p>'
            + '</div>';
    }

    function _checkStockAvailable() {
        for (var i = 0; i < _activeBillItems.length; i++) {
            var item = _activeBillItems[i];
            // Manual entries inventory ka hissa nahi hain — inhe stock se
            // match/deduct nahi karna chahiye (warna same naam wali medicine
            // ka stock galti se block/ghata sakta hai). Lekin expired manual
            // entry bhi bill mein nahi ja sakti.
            if (item.manual === true) {
                if (Utils.isExpired(item.expiry)) {
                    UI.showToast('❌ ' + item.particulars + ' expired hai — bill se remove karein.', 'error', 5000);
                    return false;
                }
                continue;
            }
            var stockItem = AppState.findStockByIdOrIndex(item.stockId, item.stockIdx, item.particulars);
            if (!stockItem) continue;
            var batch = stockItem.batches.find(function (b) { return b.batch === item.batch && b.expiry === item.expiry; });
            if (!batch) { UI.showToast(item.particulars + ' ka batch nahi mila!', 'error'); return false; }
            if (Utils.isExpired(batch.expiry)) { UI.showToast('❌ ' + item.particulars + ' ka batch ' + batch.expiry + ' expired hai — sale blocked. Return History se return karein.', 'error', 5500); return false; }
            var alreadyInBill = _activeBillItems
                .filter(function (it, idx) { return idx < i && it.stockIdx === item.stockIdx && it.batchIdx === item.batchIdx; })
                .reduce(function (sum, it) { return sum + it.qty; }, 0);
            var actualAvailable = batch.qty - alreadyInBill;
            if (actualAvailable < item.qty) { UI.showToast(item.particulars + ' ka stock kam hai! Sirf ' + actualAvailable + ' units available.', 'error', 4000); return false; }
        }
        return true;
    }

    async function _deductStock() {
        for (var j = 0; j < _activeBillItems.length; j++) {
            var it = _activeBillItems[j];
            if (it.manual === true) continue;
            var si = AppState.findStockByIdOrIndex(it.stockId, it.stockIdx, it.particulars);
            if (!si) continue;
            var bt = si.batches.find(function (b) { return b.batch === it.batch && b.expiry === it.expiry; });
            if (bt && !Utils.isExpired(bt.expiry)) bt.qty -= it.qty;
        }
        return await AppState.saveStock();
    }

    function _saveDoctorName(doctor) {
        if (doctor === 'Self') return;
        const docName = doctor.startsWith('Dr.') ? doctor : 'Dr. ' + doctor;
        AppState.addDoctor(docName);
    }

    function _resetAfterPrint() {
        _setValue('billPatient', '');
        _setValue('billDoctor', '');
        document.getElementById('billPaymentMode').value = 'Cash';
        resetBillingForm();
    }

    // ==================== SUGGESTIONS ====================

    function showDocSuggestions(str) {
        const box = document.getElementById('docSuggestions');
        if (str.trim().length < 1) { box.style.display = 'none'; return; }
        const filtered = AppState.doctorsList.filter(d => d.toLowerCase().includes(str.toLowerCase()));
        Utils.clearElement(box);
        if (!filtered.length) { box.style.display = 'none'; return; }
        filtered.forEach(doc => {
            const item = document.createElement('div');
            item.className = 'suggestion-item';
            item.textContent = doc;
            item.addEventListener('click', () => {
                document.getElementById('billDoctor').value = doc;
                box.style.display = 'none';
            });
            box.appendChild(item);
        });
        box.style.display = 'block';
    }

    function showPatientSuggestions(str) {
        const box = document.getElementById('patientSuggestions');
        const trimmed = str.trim();
        if (!trimmed) { box.style.display = 'none'; return; }
        const spaceIdx = str.lastIndexOf(' ');
        const currentWord = spaceIdx === -1 ? str : str.slice(spaceIdx + 1);
        if (!currentWord.trim()) { box.style.display = 'none'; return; }
        const matches = AppState.patientWords.filter(
            w => w.toLowerCase().startsWith(currentWord.toLowerCase()) && w.toLowerCase() !== currentWord.toLowerCase()
        );
        Utils.clearElement(box);
        if (!matches.length) { box.style.display = 'none'; return; }
        matches.forEach(word => {
            const div = document.createElement('div');
            div.className = 'suggestion-item';
            div.textContent = word;
            div.addEventListener('click', () => {
                const prefix = spaceIdx === -1 ? '' : str.slice(0, spaceIdx + 1);
                document.getElementById('billPatient').value = prefix + word + ' ';
                box.style.display = 'none';
                document.getElementById('billPatient').focus();
            });
            box.appendChild(div);
        });
        box.style.display = 'block';
    }

    function onSelectByBatch() {
        const bIdx = document.getElementById('selByBatch').value;
        if (bIdx === '' || _selectedStockIdx < 0) return;
        const med = AppState.stockData[_selectedStockIdx];
        const b = med && med.batches ? med.batches[parseInt(bIdx, 10)] : null;
        if (!_isSellableBatch(b)) {
            UI.showToast('❌ Yeh batch expired ya out of stock hai — select nahi ho sakti.', 'error', 4500);
            document.getElementById('selByBatch').value = '';
            return;
        }
        document.getElementById('selByExpiry').value = bIdx;
        _selectedBatchIdx = parseInt(bIdx, 10);
        _collapseBatchSelects();
        _showSelectedBatchInfo(med, _selectedBatchIdx);
        setTimeout(() => document.getElementById('entryQty').focus(), 50);
    }

    function onSelectByExpiry() {
        const bIdx = document.getElementById('selByExpiry').value;
        if (bIdx === '' || _selectedStockIdx < 0) return;
        const med = AppState.stockData[_selectedStockIdx];
        const b = med && med.batches ? med.batches[parseInt(bIdx, 10)] : null;
        if (!_isSellableBatch(b)) {
            UI.showToast('❌ Yeh batch expired ya out of stock hai — select nahi ho sakti.', 'error', 4500);
            document.getElementById('selByExpiry').value = '';
            return;
        }
        document.getElementById('selByBatch').value = bIdx;
        _selectedBatchIdx = parseInt(bIdx, 10);
        _collapseBatchSelects();
        _showSelectedBatchInfo(med, _selectedBatchIdx);
        setTimeout(() => document.getElementById('entryQty').focus(), 50);
    }

    function _collapseBatchSelects() {
        document.getElementById('selByBatch').size = 1;
        document.getElementById('selByExpiry').size = 1;
    }

    // ==================== KEYBOARD ====================

    function medNameKeydown(e) {
        const box = document.getElementById('medNameSuggestions');
        const items = box.querySelectorAll('.suggestion-item');
        if (box.style.display === 'none' || !items.length) {
            if (e.key === 'Enter') e.preventDefault();
            else if (e.key === 'ArrowLeft' && _isAtStart(e.target)) { e.preventDefault(); document.getElementById('billDate').focus(); }
            else if (e.key === 'ArrowRight' && _isAtEnd(e.target)) { e.preventDefault(); document.getElementById('entryQty').focus(); }
            return;
        }
        if (e.key === 'ArrowDown') { e.preventDefault(); _sugHighlight = Math.min(_sugHighlight + 1, items.length - 1); _highlightSugItem(items); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); _sugHighlight = Math.max(_sugHighlight - 1, -1); _highlightSugItem(items); }
        else if (e.key === 'Enter') { e.preventDefault(); const toClick = (_sugHighlight >= 0 && items[_sugHighlight]) ? items[_sugHighlight] : items[0]; toClick.click(); }
        else if (e.key === 'Escape') { _hideMedSuggestions(); }
    }

    function _highlightSugItem(items) {
        items.forEach((it, i) => it.classList.toggle('highlighted', i === _sugHighlight));
        if (_sugHighlight >= 0) items[_sugHighlight].scrollIntoView({ block: 'nearest' });
    }

    function qtyKeydown(e) {
        if (e.key === 'Enter') { e.preventDefault(); addItemToCurrentBill(); }
        else if (e.key === 'ArrowLeft' && _isAtStart(e.target)) { e.preventDefault(); document.getElementById('medNameInput').focus(); }
    }

    function _isAtStart(el) {
        if (el.type === 'number' || el.type === 'date') return false;
        return el.selectionStart !== null && el.selectionStart === 0 && el.selectionEnd === 0;
    }

    function _isAtEnd(el) {
        if (el.type === 'number' || el.type === 'date') return false;
        return el.selectionStart !== null && el.selectionStart === el.value.length && el.selectionEnd === el.value.length;
    }

    function batchSelKeydown(e, selId) {
        if (e.key === 'Enter') {
            e.preventDefault();
            if (selId === 'selByBatch') onSelectByBatch();
            else onSelectByExpiry();
        }
    }

    function freeMedEnter(e, nextId) {
        if (e.key === 'Enter') { e.preventDefault(); document.getElementById(nextId).focus(); }
        else if (e.key === 'ArrowRight' && _isAtEnd(e.target)) { e.preventDefault(); document.getElementById(nextId).focus(); }
        else if (e.key === 'ArrowLeft' && _isAtStart(e.target)) {
            e.preventDefault();
            const map = { freeBatch: 'medNameInput', freeExpiry: 'freeBatch', freePrice: 'freeExpiry', entryQty: 'freePrice' };
            const prevId = map[e.target.id];
            if (prevId) document.getElementById(prevId).focus();
        }
    }

    function expiryFieldKeydown(e, nextId) {
        const input = e.target;
        const val = input.value;
        const pos = input.selectionStart;
        if (e.key === 'Backspace' && pos === 3 && val.length >= 3 && val[2] === '/') {
            e.preventDefault();
            input.value = val.slice(0, 2) + val.slice(3);
            input.setSelectionRange(2, 2);
        } else if (e.key === 'Enter' && nextId) {
            e.preventDefault();
            document.getElementById(nextId).focus();
        } else if (e.key === 'ArrowRight' && _isAtEnd(input) && nextId) {
            e.preventDefault();
            document.getElementById(nextId).focus();
        }
    }

    function docFieldKeydown(e) {
        const box = document.getElementById('docSuggestions');
        const items = box.querySelectorAll('.suggestion-item');
        if (box.style.display === 'none' || !items.length) {
            if (e.key === 'Enter') { e.preventDefault(); document.getElementById('billDate').focus(); }
            else if (e.key === 'ArrowLeft' && _isAtStart(e.target)) { e.preventDefault(); document.getElementById('billPatient').focus(); }
            else if (e.key === 'ArrowRight' && _isAtEnd(e.target)) { e.preventDefault(); document.getElementById('billDate').focus(); }
            return;
        }
        _handleSuggestionsNav(e, items, box, 'billDate', null);
    }

    function patientFieldKeydown(e) {
        const box = document.getElementById('patientSuggestions');
        const items = box.querySelectorAll('.suggestion-item');
        if (box.style.display === 'none' || !items.length) {
            _patHighlight = -1;
            if (e.key === 'Enter') { e.preventDefault(); document.getElementById('billDoctor').focus(); }
            else if (e.key === 'ArrowRight' && e.target.selectionStart === e.target.value.length && e.target.selectionEnd === e.target.value.length) { e.preventDefault(); document.getElementById('billDoctor').focus(); }
            return;
        }
        if (e.key === 'ArrowDown') { e.preventDefault(); _patHighlight = Math.min(_patHighlight + 1, items.length - 1); _highlightSuggestions(items, _patHighlight); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); _patHighlight = Math.max(_patHighlight - 1, -1); _highlightSuggestions(items, _patHighlight); }
        else if (e.key === 'Enter') { e.preventDefault(); const toClick = (_patHighlight >= 0 && items[_patHighlight]) ? items[_patHighlight] : items[0]; toClick.click(); }
        else if (e.key === 'Escape') { box.style.display = 'none'; }
    }

    let _suggestionHighlights = {};

    function _handleSuggestionsNav(e, items, box, nextId, prevId) {
        const key = box.id || 'generic';
        if (!_suggestionHighlights[key]) _suggestionHighlights[key] = -1;

        if (e.key === 'ArrowDown') { e.preventDefault(); _suggestionHighlights[key] = Math.min(_suggestionHighlights[key] + 1, items.length - 1); _highlightSuggestions(items, _suggestionHighlights[key]); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); _suggestionHighlights[key] = Math.max(_suggestionHighlights[key] - 1, -1); _highlightSuggestions(items, _suggestionHighlights[key]); }
        else if (e.key === 'Enter') { e.preventDefault(); const toClick = (_suggestionHighlights[key] >= 0 && items[_suggestionHighlights[key]]) ? items[_suggestionHighlights[key]] : items[0]; toClick.click(); if (nextId) document.getElementById(nextId).focus(); }
        else if (e.key === 'Escape') { box.style.display = 'none'; }
    }

    function _highlightSuggestions(items, highlightIdx) {
        items.forEach((it, i) => it.classList.toggle('highlighted', i === highlightIdx));
        if (highlightIdx >= 0) items[highlightIdx].scrollIntoView({ block: 'nearest' });
    }

    function dateFieldKeydown(e) {
        if (e.key === 'Enter') { e.preventDefault(); document.getElementById('medNameInput').focus(); }
    }

    function fieldEnterNext(e, nextId) {
        if (e.key === 'Enter') { e.preventDefault(); document.getElementById(nextId).focus(); }
    }

    // Close preview modal on Escape (does not interfere with other modals)
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const modal = document.getElementById('billPreviewModal');
            if (modal && modal.style.display === 'flex') {
                closePreview();
            }
        }
    });

    // ==================== PUBLIC API ====================

    function hasUnsavedWork() {
        if (_activeBillItems.length > 0) return true;
        var patient = document.getElementById('billPatient');
        var doctor = document.getElementById('billDoctor');
        if (patient && patient.value.trim()) return true;
        if (doctor && doctor.value.trim()) return true;
        return false;
    }

    return {
        resetBillingForm,
        onMedNameInput,
        addItemToCurrentBill,
        processAndPrintBill,
        previewAndSaveBill,
        toggleRecoveryPanel,
        applyRecoveryBillNo,
        clearRecoveryMode,
        showBillPreview,
        closePreview,
        printLastPreviewedBill,
        previewOldBillByNo,
        printNativeText,
        printRawBill,
        notepadPrint,
        buildBillHtml,
        showDocSuggestions,
        showPatientSuggestions,
        onSelectByBatch,
        onSelectByExpiry,
        validateQtyInput,
        medNameKeydown,
        qtyKeydown,
        batchSelKeydown,
        freeMedEnter,
        expiryFieldKeydown,
        docFieldKeydown,
        patientFieldKeydown,
        dateFieldKeydown,
        fieldEnterNext
    };
})();
