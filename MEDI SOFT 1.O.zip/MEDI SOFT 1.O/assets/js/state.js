const AppState = (() => {
    // ==================== MEMORY ====================
    let _stockData = [];
    let _billsHistory = [];
    let _returnHistory = [];
    let _doctorsList = [];
    let _makeList = [];
    let _wholesalerList = [];
    let _patientWords = [];
    let _listeners = {};

    // ==================== PERSISTENCE STATE ====================
    const LS_STOCK = CONFIG.LS_KEYS.STOCK;
    const LS_HISTORY = CONFIG.LS_KEYS.HISTORY;
    const LS_RETURNS = CONFIG.LS_KEYS.RETURNS;
    const LS_COUNTER = CONFIG.LS_KEYS.BILL_COUNTER;
    const LS_TOMBSTONES = 'rb_stock_tombstones';
    const LS_SYNC_PING = 'rb_sync_ping';

    let _initialized = false;
    let _initPromise = null;
    let _idbReady = false;
    let _storageMode = 'localStorage';
    let _saveChain = Promise.resolve();
    let _dirtyBills = new Set();
    let _dirtyReturns = new Set();
    let _dirtyStock = new Set();
    let _deletedStock = new Set();
    let _stockShadow = new Map();
    let _stockTombstones = {};
    let _billCounter = 0;
    let _clearEpoch = 0;
    let _lastSaveAt = 0;
    let _lastSaveError = '';
    let _snapshotTimer = null;
    let _serverBackupTimer = null;
    let _reconcileTimer = null;
    let _reconciling = null;
    let _lastLegacyReadAt = 0;
    let _suppressBroadcast = false;

    const _tabId = 'tab_' + Date.now() + '_' + Math.random().toString(36).slice(2, 9);
    let _channel = null;

    // ==================== SMALL HELPERS ====================
    function _sanitizeField(val, maxLen) {
        if (typeof val !== 'string') return '';
        return val.replace(/[<>"']/g, '').slice(0, maxLen || 500);
    }

    function _formatExpiry(expiry) {
        if (!expiry || /^\d{2}\/\d{4}$/.test(expiry)) return expiry || '';
        var digits = expiry.replace(/\D/g, '');
        if (digits.length === 6) return digits.substring(0, 2) + '/' + digits.substring(2, 6);
        return expiry;
    }

    function _clonePlain(value) {
        try {
            if (typeof structuredClone === 'function') return structuredClone(value);
        } catch (_) {}
        try { return JSON.parse(JSON.stringify(value)); } catch (_) { return value; }
    }

    function _readLSArray(key) {
        try {
            var raw = localStorage.getItem(key);
            if (!raw) return null;
            var parsed = JSON.parse(raw);
            return Array.isArray(parsed) ? parsed : null;
        } catch (_) { return null; }
    }

    function _writeLSArray(key, list) {
        try {
            var json = JSON.stringify(list || []);
            localStorage.setItem(key, json);
            return localStorage.getItem(key) === json;
        } catch (e) {
            console.error('localStorage write failed:', key, e.message || e);
            return false;
        }
    }

    function _replaceArray(target, source) {
        target.length = 0;
        if (Array.isArray(source)) Array.prototype.push.apply(target, source);
    }

    function _emit(event, data) {
        if (!_listeners[event]) return;
        _listeners[event].slice().forEach(function (fn) {
            try { fn(data); } catch (e) { console.error('Listener error:', e); }
        });
    }

    function _enqueue(fn) {
        var next = _saveChain.catch(function () { return null; }).then(fn);
        _saveChain = next.catch(function () { return null; });
        return next;
    }

    function _persistTombstones() {
        Database.Storage.set(LS_TOMBSTONES, _stockTombstones);
        if (_idbReady) {
            Database.idbSetKv('stockTombstones', _stockTombstones).catch(function () {});
        }
    }

    function _stockSignature(item) {
        if (!item || typeof item !== 'object') return '';
        var copy = {};
        for (var k in item) {
            if (Object.prototype.hasOwnProperty.call(item, k) && k !== '_savedAt') copy[k] = item[k];
        }
        return JSON.stringify(copy);
    }

    function _rebuildStockShadow() {
        _stockShadow = new Map();
        _stockData.forEach(function (s) {
            if (s && s.id) _stockShadow.set(s.id, _stockSignature(s));
        });
    }

    function _stockDirtyCount() {
        var n = 0;
        _stockData.forEach(function (s) {
            if (!s || !s.id) return;
            if (_stockShadow.get(s.id) !== _stockSignature(s)) n++;
        });
        return n + _deletedStock.size;
    }

    function _hasDirty() {
        return _dirtyBills.size > 0 || _dirtyReturns.size > 0 || _stockDirtyCount() > 0;
    }

    // ==================== DATA MIGRATION ====================
    function _migrateStockData(raw) {
        if (!Array.isArray(raw)) return [];
        var result = [];
        for (var i = 0; i < raw.length; i++) {
            try {
                var item = raw[i];
                if (!item || typeof item !== 'object') continue;
                var batches = [];
                if (item.batches && Array.isArray(item.batches)) {
                    for (var j = 0; j < item.batches.length; j++) {
                        var b = item.batches[j];
                        if (!b || typeof b !== 'object') continue;
                        batches.push({
                            id: _sanitizeField(b.id, 100),
                            batch: _sanitizeField(b.batch, 100),
                            expiry: _formatExpiry(_sanitizeField(b.expiry, 20)),
                            qty: Math.max(0, parseInt(b.qty, 10) || 0),
                            price: Math.max(0, parseFloat(b.price) || 0),
                            stripSize: Math.max(0, parseInt(b.strip_size || b.stripSize, 10) || 0)
                        });
                    }
                } else {
                    batches.push({
                        batch: _sanitizeField(item.batch, 100),
                        expiry: _formatExpiry(_sanitizeField(item.expiry, 20)),
                        qty: Math.max(0, parseInt(item.qty, 10) || 0),
                        price: Math.max(0, parseFloat(item.price) || 0),
                        stripSize: Math.max(0, parseInt(item.strip_size || item.stripSize, 10) || 0)
                    });
                }
                var name = _sanitizeField(item.name, 200);
                if (!name) continue;
                var out = {
                    id: _sanitizeField(item.id, 100) || Utils.generateId('med'),
                    name: name,
                    wholesaler: _sanitizeField(item.wholesaler, 200),
                    make: _sanitizeField(item.make, 200),
                    h: !!item.h,
                    h1: !!item.h1,
                    h2: !!item.h2,
                    narcotic: !!item.narcotic,
                    batches: batches
                };
                var savedAt = parseInt(item._savedAt, 10);
                if (savedAt > 0) out._savedAt = savedAt;
                result.push(out);
            } catch (e) {
                console.error('MIGRATE ERROR item ' + i + ':', e);
            }
        }
        return result;
    }

    function _normalizeReturnStatus(value) {
        var s = String(value || '').trim().toLowerCase();
        if (s === 'returned') return 'Returned';
        if (s === 'partially returned' || s === 'partial') return 'Partially Returned';
        return 'Pending Return';
    }

    function _migrateReturnData(raw) {
        if (!Array.isArray(raw)) return [];
        var result = [];
        for (var i = 0; i < raw.length; i++) {
            try {
                var r = raw[i];
                if (!r || typeof r !== 'object') continue;
                var qty = Math.max(0, parseInt(r.qty, 10) || 0);
                if (qty <= 0) continue;
                var id = _sanitizeField(r.id, 100) || Utils.generateId('ret');
                var statusBefore = _normalizeReturnStatus(r.statusBefore || r.status_before);
                var statusAfter = _normalizeReturnStatus(r.statusAfter || r.status_after || r.status);
                var remainingAfter = Math.max(0, parseInt(r.remainingAfter !== undefined ? r.remainingAfter : r.remaining_after, 10) || 0);
                var stockBefore = Math.max(0, parseInt(r.stockBefore !== undefined ? r.stockBefore : r.stock_before, 10) || 0);
                var stockAfter = Math.max(0, parseInt(r.stockAfter !== undefined ? r.stockAfter : r.stock_after, 10) || 0);
                var returnedBefore = Math.max(0, parseInt(r.returnedBefore !== undefined ? r.returnedBefore : r.returned_before, 10) || 0);
                var timestamp = parseInt(r.timestamp, 10);
                if (!timestamp || isNaN(timestamp)) timestamp = Date.now();
                result.push({
                    id: id,
                    requestId: _sanitizeField(r.requestId || r.request_id, 100),
                    stockId: _sanitizeField(r.stockId || r.stock_id, 100),
                    batchId: _sanitizeField(r.batchId || r.batch_id, 100),
                    medicineName: _sanitizeField(r.medicineName || r.medicine_name || r.medicine, 200),
                    make: _sanitizeField(r.make, 200),
                    supplier: _sanitizeField(r.supplier || r.wholesaler, 200),
                    batch: _sanitizeField(r.batch, 100),
                    expiry: _formatExpiry(_sanitizeField(r.expiry, 20)),
                    qty: qty,
                    returnDate: _sanitizeField(r.returnDate || r.return_date, 20),
                    remarks: _sanitizeField(r.remarks, 500),
                    statusBefore: statusBefore,
                    statusAfter: statusAfter,
                    remainingAfter: remainingAfter,
                    stockBefore: stockBefore,
                    stockAfter: stockAfter,
                    returnedBefore: returnedBefore,
                    sourceType: _sanitizeField(r.sourceType || r.source_type, 40) || 'inventory',
                    createdAt: _sanitizeField(r.createdAt || r.created_at, 60) || new Date(timestamp).toLocaleString(),
                    timestamp: timestamp
                });
            } catch (e) {
                console.error('MIGRATE RETURN ERROR item ' + i + ':', e);
            }
        }
        return result;
    }

    function _migrateHistoryData(raw) {
        if (!Array.isArray(raw)) return [];
        return raw.map(function (h) {
            if (!h || typeof h !== 'object') return null;
            return {
                id: typeof h.id === 'string' ? h.id : Utils.generateId('bill'),
                billNo: Math.max(0, parseInt(h.billNo, 10) || 0),
                date: typeof h.date === 'string' ? h.date : '',
                time: typeof h.time === 'string' ? h.time : '',
                patient: _sanitizeField(h.patient, 200),
                doctor: _sanitizeField(h.doctor, 200),
                paymentMode: typeof h.paymentMode === 'string' ? h.paymentMode : 'Cash',
                total: typeof h.total === 'number' && !isNaN(h.total) ? h.total : 0,
                items: Array.isArray(h.items) ? h.items.map(function (it) {
                    if (!it || typeof it !== 'object') return null;
                    return {
                        id: typeof it.id === 'string' ? it.id : null,
                        stockIdx: typeof it.stockIdx === 'number' ? it.stockIdx : -1,
                        stockId: typeof it.stockId === 'string' ? it.stockId : null,
                        batchIdx: typeof it.batchIdx === 'number' ? it.batchIdx : -1,
                        manual: typeof it.manual === 'boolean' ? it.manual : (!it.stockId && (typeof it.stockIdx !== 'number' || it.stockIdx === -1)),
                        particulars: _sanitizeField(it.particulars, 200),
                        make: _sanitizeField(it.make, 200),
                        h: !!it.h, h1: !!it.h1, h2: !!it.h2, narcotic: !!it.narcotic,
                        batch: _sanitizeField(it.batch, 100),
                        expiry: _formatExpiry(_sanitizeField(it.expiry, 20)),
                        qty: Math.max(0, parseInt(it.qty, 10) || 0),
                        amount: Math.max(0, parseFloat(it.amount) || 0)
                    };
                }).filter(function (it) { return it && it.particulars; }) : [],
                cancelled: !!h.cancelled,
                cancelReason: typeof h.cancelReason === 'string' ? h.cancelReason : '',
                cancelledAt: typeof h.cancelledAt === 'string' ? h.cancelledAt : ''
            };
        }).filter(function (h) { return h && h.id; });
    }

    // ==================== MERGE HELPERS ====================
    // Bills append-only merge: id ke basis par union. Same id ho to cancel
    // state monotonic (cancel kabhi un-cancel nahi hota) aur richer items jeette hain.
    function _mergeTwoBills(cur, incoming) {
        var merged = cur;
        if (incoming.cancelled && !merged.cancelled) {
            merged = Object.assign({}, merged, {
                cancelled: true,
                cancelReason: incoming.cancelReason || merged.cancelReason || '',
                cancelledAt: incoming.cancelledAt || merged.cancelledAt || ''
            });
        }
        var curItems = Array.isArray(merged.items) ? merged.items.length : 0;
        var newItems = Array.isArray(incoming.items) ? incoming.items.length : 0;
        if (newItems > curItems) merged = Object.assign({}, merged, { items: incoming.items });
        if ((!merged.total && incoming.total) || (newItems > curItems && incoming.total)) {
            merged = Object.assign({}, merged, { total: incoming.total });
        }
        return merged;
    }

    function _mergeBillArrays() {
        var map = new Map();
        var keyMap = new Map();
        var order = [];
        for (var a = 0; a < arguments.length; a++) {
            var list = arguments[a];
            if (!Array.isArray(list)) continue;
            for (var i = 0; i < list.length; i++) {
                var b = list[i];
                if (!b || typeof b !== 'object' || !b.id) continue;
                // Purane backups mein bill.id nahi hota — migrate karte waqt random
                // id ban jati hai. Isliye billNo+date+total se bhi dedupe karo,
                // warna recovery/reconcile har source ka bill dobaara daal dega.
                var key = _billMergeKey(b);
                var byId = map.get(b.id);
                var byKey = key ? keyMap.get(key) : null;
                var target = byId || byKey;
                if (!target) {
                    map.set(b.id, b);
                    if (key) keyMap.set(key, b);
                    order.push(b.id);
                    continue;
                }
                var merged = _mergeTwoBills(target, b);
                map.set(target.id, merged);
                var targetKey = _billMergeKey(target);
                if (targetKey) keyMap.set(targetKey, merged);
                if (key) keyMap.set(key, merged);
            }
        }
        return order.map(function (id) { return map.get(id); }).filter(Boolean);
    }

    function _mergeReturnArrays() {
        var map = new Map();
        var order = [];
        for (var a = 0; a < arguments.length; a++) {
            var list = arguments[a];
            if (!Array.isArray(list)) continue;
            for (var i = 0; i < list.length; i++) {
                var r = list[i];
                if (!r || typeof r !== 'object' || !r.id) continue;
                if (!map.has(r.id)) {
                    map.set(r.id, r);
                    order.push(r.id);
                }
            }
        }
        return order.map(function (id) { return map.get(id); });
    }

    // Stock merge: per-record _savedAt timestamp jeetta hai. Isse ek stale tab
    // doosre tab ke naye stock record ko overwrite nahi karta. Tombstoned ids
    // (explicitly deleted) wapas resurrect nahi hote.
    function _mergeStockArrays(sources) {
        var chosen = new Map();
        (sources || []).forEach(function (src) {
            var list = src && src.list;
            if (!Array.isArray(list)) return;
            var priority = src.priority || 0;
            for (var i = 0; i < list.length; i++) {
                var item = list[i];
                if (!item || typeof item !== 'object' || !item.id) continue;
                var t = parseInt(item._savedAt, 10) || 0;
                var tomb = parseInt(_stockTombstones[item.id], 10) || 0;
                if (tomb && (!t || t <= tomb)) continue;
                var cur = chosen.get(item.id);
                if (!cur || t > cur.time || (t === cur.time && priority > cur.priority)) {
                    chosen.set(item.id, { item: item, time: t, priority: priority });
                }
            }
        });
        return Array.from(chosen.values()).map(function (x) { return x.item; });
    }

    // ==================== LOCALSTORAGE MIRROR MERGE ====================
    // Har save se pehle localStorage snapshot ko memory ke saath merge karte
    // hain. Agar doosre tab ne sirf localStorage mein naya bill likha ho, to
    // woh yahan memory + IDB dono mein aa jata hai — overwrite nahi hota.
    function _mergeHistoryFromLS() {
        var ls = _readLSArray(LS_HISTORY);
        if (!ls || !ls.length) return;
        var beforeById = new Map();
        var beforeByKey = new Map();
        _billsHistory.forEach(function (b) {
            if (!b || !b.id) return;
            beforeById.set(b.id, _billSignature(b));
            var key = _billMergeKey(b);
            if (key && !beforeByKey.has(key)) beforeByKey.set(key, b.id);
        });
        var merged = _mergeBillArrays(ls, _billsHistory);
        _replaceArray(_billsHistory, merged);
        merged.forEach(function (b) {
            if (!b || !b.id) return;
            var key = _billMergeKey(b);
            var oldId = beforeById.has(b.id) ? b.id : (key ? beforeByKey.get(key) : null);
            var oldSig = oldId ? beforeById.get(oldId) : undefined;
            if (oldSig === undefined || oldSig !== _billSignature(b)) _dirtyBills.add(b.id);
        });
    }

    function _mergeReturnsFromLS() {
        var ls = _readLSArray(LS_RETURNS);
        if (!ls || !ls.length) return;
        var before = new Set(_returnHistory.map(function (r) { return r.id; }));
        var merged = _mergeReturnArrays(ls, _returnHistory);
        _replaceArray(_returnHistory, merged);
        merged.forEach(function (r) {
            if (r && r.id && !before.has(r.id)) _dirtyReturns.add(r.id);
        });
    }

    function _mergeStockFromLS(now) {
        var dirtyIds = new Set();
        var currentIds = new Set();
        _stockData.forEach(function (s) {
            if (!s || !s.id) return;
            currentIds.add(s.id);
            if (_stockShadow.get(s.id) !== _stockSignature(s)) {
                s._savedAt = now;
                dirtyIds.add(s.id);
            }
        });
        _stockShadow.forEach(function (_sig, id) {
            if (!currentIds.has(id)) _deletedStock.add(id);
        });
        _deletedStock.forEach(function (id) {
            if (!_stockTombstones[id]) _stockTombstones[id] = now;
        });
        var ls = _readLSArray(LS_STOCK);
        if (ls && ls.length) {
            var merged = _mergeStockArrays([
                { list: ls, priority: 2 },
                { list: _stockData, priority: 100 }
            ]);
            _replaceArray(_stockData, merged);
            merged.forEach(function (s) {
                if (s && s.id && !currentIds.has(s.id)) dirtyIds.add(s.id);
            });
        }
        return dirtyIds;
    }

    // ==================== URGENT SYNC LOCALSTORAGE MIRROR ====================
    // Yeh writes SYNCHRONOUS hain (localStorage.setItem). Inhe IDB await se
    // PEHLE chalate hain — agar app/tab/computer IDB write ke beech band ho
    // jaye, tab bhi naya bill localStorage se next launch par wapas milta hai.
    // (Yahi wajah thi ki pehle din ke aakhri bills gayab ho jaate the.)
    function _mirrorHistoryToLS() {
        try { _mergeHistoryFromLS(); } catch (_) {}
        var ok = _writeLSArray(LS_HISTORY, _billsHistory);
        Database.Storage.setString(LS_COUNTER, String(_billCounter));
        return ok;
    }

    // App band hone / tab hide hone par turant sync snapshot — koi data loss nahi.
    function _flushToLocalStorageNow() {
        if (!_initialized) return;
        try {
            try { _mergeHistoryFromLS(); } catch (_) {}
            try { _mergeReturnsFromLS(); } catch (_) {}
            try { _mergeStockFromLS(Date.now()); } catch (_) {}
            _writeLSArray(LS_STOCK, _stockData);
            _writeLSArray(LS_HISTORY, _billsHistory);
            _writeLSArray(LS_RETURNS, _returnHistory);
            Database.Storage.setString(LS_COUNTER, String(_billCounter));
            _persistTombstones();
        } catch (_) {}
    }

    // ==================== SAVE FUNCTIONS ====================
    async function _doSaveStock(reason) {
        var now = Date.now();
        var dirtyIds = _mergeStockFromLS(now);
        var dirty = _stockData.filter(function (s) { return s && s.id && dirtyIds.has(s.id); });
        var deleted = Array.from(_deletedStock);
        // localStorage mirror pehle — synchronous safety.
        var lsOk = _writeLSArray(LS_STOCK, _stockData);
        var idbOk = false, idbErr = '';
        if (_idbReady) {
            try {
                if (dirty.length || deleted.length) {
                    await Database.idbWriteBatch({
                        stock: { put: _clonePlain(dirty), delete: deleted }
                    });
                }
                try { await Database.idbSetKv(LS_STOCK, _clonePlain(_stockData)); } catch (_) {}
                idbOk = true;
            } catch (e) {
                idbErr = e.message || String(e);
                console.error('STOCK SAVE (IndexedDB):', idbErr);
            }
        }
        if (idbOk || (!_idbReady && lsOk)) {
            _rebuildStockShadow();
            _deletedStock.clear();
            _dirtyStock.clear();
            _persistTombstones();
            Database.Storage.remove(LS_STOCK + '_idb');
        } else {
            dirty.forEach(function (s) { if (s && s.id) _dirtyStock.add(s.id); });
        }
        _lastSaveAt = Date.now();
        _lastSaveError = (!idbOk && !lsOk) ? ('Stock save failed: ' + (idbErr || 'localStorage full')) : '';
        if (!idbOk && !lsOk) {
            console.error('STOCK SAVE FAILED — stock sirf memory mein hai!');
            _toast('❌ Stock kahin save nahi ho paya! Turant Offline Backup download karein aur app band na karein.', 'error', 9000);
        } else if (!idbOk && lsOk) {
            _toast('⚠️ Stock IndexedDB mein save nahi hua — localStorage fallback active hai.', 'warn', 5000);
        }
        _emit('stockChanged', _stockData);
        if (idbOk || lsOk) _broadcast(['stock']);
        return { ok: idbOk || lsOk, idb: idbOk, localStorage: lsOk, error: idbErr, count: _stockData.length, reason: reason || '' };
    }

    async function _doSaveHistory(reason) {
        _mergeHistoryFromLS();
        // localStorage mirror PEHLE — synchronous. IDB slow/blocked ho ya app
        // band ho jaye, tab bhi bills safe rahenge.
        var lsOk = _writeLSArray(LS_HISTORY, _billsHistory);
        Database.Storage.setString(LS_COUNTER, String(_billCounter));
        var dirtyIds = new Set(_dirtyBills);
        var dirty = _billsHistory.filter(function (b) { return b && b.id && dirtyIds.has(b.id); });
        var idbOk = false, idbErr = '';
        if (_idbReady) {
            try {
                if (dirty.length) await Database.idbPutBatch('bills', _clonePlain(dirty));
                try { await Database.idbSetKv(LS_HISTORY, _clonePlain(_billsHistory)); } catch (_) {}
                try { await Database.idbSetMeta('billCounter', _billCounter); } catch (_) {}
                idbOk = true;
                dirty.forEach(function (b) { _dirtyBills.delete(b.id); });
            } catch (e) {
                idbErr = e.message || String(e);
                console.error('HISTORY SAVE (IndexedDB):', idbErr);
            }
        }
        if (!_idbReady && lsOk) _dirtyBills.clear();
        if (idbOk) Database.Storage.remove(LS_HISTORY + '_idb');
        _lastSaveAt = Date.now();
        _lastSaveError = (!idbOk && !lsOk) ? ('Bill save failed: ' + (idbErr || 'localStorage full')) : '';
        if (!idbOk && !lsOk) {
            console.error('HISTORY SAVE FAILED — bills sirf memory mein hain!');
            _toast('❌ Bill history kahin save nahi ho payi! Turant Offline Backup download karein, app band na karein!', 'error', 9000);
        } else if (!idbOk && lsOk) {
            _toast('⚠️ Bill history IndexedDB mein save nahi hui — localStorage fallback active hai.', 'warn', 5000);
        }
        _emit('historyChanged', _billsHistory);
        if (idbOk || lsOk) _broadcast(['history']);
        return { ok: idbOk || lsOk, idb: idbOk, localStorage: lsOk, error: idbErr, count: _billsHistory.length, reason: reason || '' };
    }

    async function _doSaveReturns(reason) {
        _mergeReturnsFromLS();
        // localStorage mirror pehle — synchronous safety.
        var lsOk = _writeLSArray(LS_RETURNS, _returnHistory);
        var dirtyIds = new Set(_dirtyReturns);
        var dirty = _returnHistory.filter(function (r) { return r && r.id && dirtyIds.has(r.id); });
        var idbOk = false, idbErr = '';
        if (_idbReady) {
            try {
                if (dirty.length) await Database.idbPutBatch('returns', _clonePlain(dirty));
                try { await Database.idbSetKv(LS_RETURNS, _clonePlain(_returnHistory)); } catch (_) {}
                idbOk = true;
                dirty.forEach(function (r) { _dirtyReturns.delete(r.id); });
            } catch (e) {
                idbErr = e.message || String(e);
                console.error('RETURN SAVE (IndexedDB):', idbErr);
            }
        }
        if (!_idbReady && lsOk) _dirtyReturns.clear();
        if (idbOk) Database.Storage.remove(LS_RETURNS + '_idb');
        _lastSaveAt = Date.now();
        _lastSaveError = (!idbOk && !lsOk) ? ('Return save failed: ' + (idbErr || 'localStorage full')) : '';
        if (!idbOk && !lsOk) {
            console.error('RETURN SAVE FAILED — returns sirf memory mein hain!');
            _toast('❌ Return history kahin save nahi ho payi! Turant Offline Backup download karein.', 'error', 9000);
        }
        _emit('returnsChanged', _returnHistory);
        if (idbOk || lsOk) _broadcast(['returns']);
        return { ok: idbOk || lsOk, idb: idbOk, localStorage: lsOk, error: idbErr, count: _returnHistory.length, reason: reason || '' };
    }

    // Stock + return ek hi IDB transaction mein — return operation atomic rahe.
    async function _doSaveStockAndReturns(reason, extraReturnIds) {
        var now = Date.now();
        var dirtyStockIds = _mergeStockFromLS(now);
        _mergeReturnsFromLS();
        var retIds = new Set(_dirtyReturns);
        (extraReturnIds || []).forEach(function (id) { if (id) retIds.add(id); });
        var dirtyStock = _stockData.filter(function (s) { return s && s.id && dirtyStockIds.has(s.id); });
        var dirtyReturns = _returnHistory.filter(function (r) { return r && r.id && retIds.has(r.id); });
        var deleted = Array.from(_deletedStock);
        // localStorage mirror pehle — synchronous safety.
        var stockLs = _writeLSArray(LS_STOCK, _stockData);
        var retLs = _writeLSArray(LS_RETURNS, _returnHistory);
        var lsOk = stockLs && retLs;
        var idbOk = false, idbErr = '';
        if (_idbReady) {
            try {
                await Database.idbWriteBatch({
                    stock: { put: _clonePlain(dirtyStock), delete: deleted },
                    returns: { put: _clonePlain(dirtyReturns) }
                });
                try { await Database.idbSetKv(LS_STOCK, _clonePlain(_stockData)); } catch (_) {}
                try { await Database.idbSetKv(LS_RETURNS, _clonePlain(_returnHistory)); } catch (_) {}
                idbOk = true;
                dirtyReturns.forEach(function (r) { _dirtyReturns.delete(r.id); });
            } catch (e) {
                idbErr = e.message || String(e);
                console.error('STOCK+RETURN SAVE (IndexedDB):', idbErr);
            }
        }
        if (idbOk || (!_idbReady && lsOk)) {
            _rebuildStockShadow();
            _deletedStock.clear();
            _dirtyStock.clear();
            _persistTombstones();
            Database.Storage.remove(LS_STOCK + '_idb');
            Database.Storage.remove(LS_RETURNS + '_idb');
            if (!_idbReady) _dirtyReturns.clear();
        } else {
            dirtyStock.forEach(function (s) { if (s && s.id) _dirtyStock.add(s.id); });
        }
        _lastSaveAt = Date.now();
        _lastSaveError = (!idbOk && !lsOk) ? ('Return save failed: ' + (idbErr || 'localStorage full')) : '';
        if (!idbOk && !lsOk) {
            _toast('❌ Return kahin save nahi hua! Turant Offline Backup download karein.', 'error', 9000);
        } else if (!idbOk && lsOk) {
            _toast('⚠️ Return IndexedDB mein save nahi hua — localStorage fallback active hai.', 'warn', 5000);
        }
        _emit('stockChanged', _stockData);
        _emit('returnsChanged', _returnHistory);
        if (idbOk || lsOk) _broadcast(['stock', 'returns']);
        return { ok: idbOk || lsOk, idb: idbOk, localStorage: lsOk, error: idbErr, reason: reason || '' };
    }

    function _saveStock(reason) { return _enqueue(function () { return _doSaveStock(reason); }); }
    function _saveHistory(reason) { return _enqueue(function () { return _doSaveHistory(reason); }); }
    function _saveReturns(reason) { return _enqueue(function () { return _doSaveReturns(reason); }); }
    function _saveStockAndReturns(reason, extraReturnIds) {
        return _enqueue(function () { return _doSaveStockAndReturns(reason, extraReturnIds); });
    }

    async function _persistAll(reason) {
        var results = [];
        results.push(await _saveStock(reason));
        results.push(await _saveHistory(reason));
        results.push(await _saveReturns(reason));
        _saveMiscLists();
        _saveCounterToIdb();
        return results;
    }

    // ==================== CROSS-TAB SYNC ====================
    function _broadcast(kinds) {
        if (_suppressBroadcast) return;
        var msg = { type: 'data-changed', source: _tabId, at: Date.now(), kinds: kinds || [] };
        try { if (_channel) _channel.postMessage(msg); } catch (_) {}
        try { localStorage.setItem(LS_SYNC_PING, JSON.stringify(msg)); } catch (_) {}
    }

    function _broadcastClear(epoch) {
        var msg = { type: 'cleared', source: _tabId, at: Date.now(), epoch: epoch };
        try { if (_channel) _channel.postMessage(msg); } catch (_) {}
        try { localStorage.setItem(LS_SYNC_PING, JSON.stringify(msg)); } catch (_) {}
    }

    function _scheduleReconcile(delay) {
        if (_reconcileTimer) clearTimeout(_reconcileTimer);
        _reconcileTimer = setTimeout(function () {
            _reconcileTimer = null;
            reconcile().catch(function (e) { console.warn('Reconcile skipped:', e.message || e); });
        }, delay || 300);
    }

    function _setupCrossTab() {
        if (!_channel && typeof BroadcastChannel !== 'undefined') {
            try {
                _channel = new BroadcastChannel('medi_soft_v2_sync');
                _channel.onmessage = function (ev) {
                    var msg = ev.data || {};
                    if (msg.source === _tabId) return;
                    if (msg.type === 'cleared') {
                        _handleExternalClear(msg.epoch);
                        return;
                    }
                    if (msg.type === 'data-changed') _scheduleReconcile(250);
                };
            } catch (e) { _channel = null; }
        }
        window.addEventListener('storage', function (e) {
            if (!e.key) return;
            if (e.key === LS_HISTORY || e.key === LS_STOCK || e.key === LS_RETURNS || e.key === LS_SYNC_PING) {
                _scheduleReconcile(350);
            }
        });
        window.addEventListener('focus', function () { _scheduleReconcile(400); });
        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) _scheduleReconcile(400);
            else _flushToLocalStorageNow();
        });
        // App/tab band hone se pehle turant disk par likho.
        window.addEventListener('pagehide', function () { _flushToLocalStorageNow(); });
        window.addEventListener('beforeunload', function () { _flushToLocalStorageNow(); });
    }

    // ==================== TOAST HELPER ====================
    function _toast(message, type, duration) {
        try {
            if (typeof UI !== 'undefined' && UI.showToast) UI.showToast(message, type || 'info', duration || 5000);
        } catch (_) {}
    }

    const LS_CLEAR_EPOCH = 'rb_clear_epoch';
    const LS_CLEAR_REQUESTED = 'rb_clear_requested';

    function _billSignature(b) {
        if (!b) return '';
        return [
            parseInt(b.billNo, 10) || 0,
            b.date || '', b.time || '', b.patient || '', b.doctor || '',
            Number(b.total) || 0, b.cancelled ? 1 : 0,
            (Array.isArray(b.items) ? b.items.length : 0),
            b.cancelReason || ''
        ].join('|');
    }

    function _loadStringList(key, idbValue) {
        var ls = Database.Storage.get(key, null);
        if (Array.isArray(ls)) return ls.filter(function (x) { return typeof x === 'string'; });
        if (Array.isArray(idbValue)) return idbValue.filter(function (x) { return typeof x === 'string'; });
        return [];
    }

    function _saveMiscLists() {
        Database.Storage.set(CONFIG.LS_KEYS.DOCTORS, _doctorsList);
        Database.Storage.set(CONFIG.LS_KEYS.MAKE_LIST, _makeList);
        Database.Storage.set(CONFIG.LS_KEYS.WHOLESALER_LIST, _wholesalerList);
        Database.Storage.set(CONFIG.LS_KEYS.PATIENT_WORDS, _patientWords);
        if (_idbReady) {
            Database.idbSetKv(CONFIG.LS_KEYS.DOCTORS, _doctorsList).catch(function () {});
            Database.idbSetKv(CONFIG.LS_KEYS.MAKE_LIST, _makeList).catch(function () {});
            Database.idbSetKv(CONFIG.LS_KEYS.WHOLESALER_LIST, _wholesalerList).catch(function () {});
            Database.idbSetKv(CONFIG.LS_KEYS.PATIENT_WORDS, _patientWords).catch(function () {});
        }
    }

    function _saveCounterToIdb() {
        if (!_idbReady) return;
        try { Database.idbSetMeta('billCounter', _billCounter).catch(function () {}); } catch (_) {}
        try { Database.idbSetKv(LS_COUNTER, _billCounter).catch(function () {}); } catch (_) {}
    }

    // ==================== INIT (ASYNC, NO STALE OVERWRITE) ====================
    function init() {
        if (_initPromise) return _initPromise;
        _initPromise = _doInit().catch(function (e) {
            console.error('AppState init failed:', e);
            _idbReady = false;
            _storageMode = 'localStorage';
            _lastSaveError = 'Init failed: ' + (e.message || e);
            _initialized = true;
            _loadFromLocalStorageOnly();
            _setupCrossTab();
            _emit('stockChanged', _stockData);
            _emit('historyChanged', _billsHistory);
            _emit('returnsChanged', _returnHistory);
            return { ok: !_lastSaveError, billCount: _billsHistory.length, storageMode: _storageMode, idbReady: _idbReady };
        });
        return _initPromise;
    }

    function _loadFromLocalStorageOnly() {
        _stockData = _migrateStockData(_readLSArray(LS_STOCK) || []);
        _billsHistory = _migrateHistoryData(_readLSArray(LS_HISTORY) || []);
        _returnHistory = _migrateReturnData(_readLSArray(LS_RETURNS) || []);
        _doctorsList = _loadStringList(CONFIG.LS_KEYS.DOCTORS, null);
        _makeList = _loadStringList(CONFIG.LS_KEYS.MAKE_LIST, null);
        _wholesalerList = _loadStringList(CONFIG.LS_KEYS.WHOLESALER_LIST, null);
        _patientWords = _loadStringList(CONFIG.LS_KEYS.PATIENT_WORDS, null);
        var maxNo = _billsHistory.reduce(function (mx, b) { return Math.max(mx, (b && b.billNo) || 0); }, 0);
        _billCounter = Math.max(parseInt(Database.Storage.getString(LS_COUNTER, '0'), 10) || 0, maxNo);
        var now = Date.now();
        _stockData.forEach(function (s) { if (!s._savedAt) s._savedAt = now; });
        _rebuildStockShadow();
    }

    async function _doInit() {
        var lsStock = _readLSArray(LS_STOCK);
        var lsHist = _readLSArray(LS_HISTORY);
        var lsRet = _readLSArray(LS_RETURNS);
        var flags = {
            stock: Database.Storage.getString(LS_STOCK + '_idb', ''),
            hist: Database.Storage.getString(LS_HISTORY + '_idb', ''),
            ret: Database.Storage.getString(LS_RETURNS + '_idb', '')
        };

        // ---- Crash-safe clear recovery ----
        // Agar pichhle "Clear All Data" ke beech app band hua tha, to purana
        // IDB/legacy data wapas load na ho.
        var clearRequested = parseInt(Database.Storage.getString(LS_CLEAR_REQUESTED, '0'), 10) || 0;
        if (clearRequested > 0 && typeof indexedDB !== 'undefined') {
            var idbEpochProbe = 0;
            try { idbEpochProbe = parseInt(await Database.idbGetKv('clearEpoch', 0), 10) || 0; } catch (_) {}
            if (clearRequested > idbEpochProbe) {
                var clearOk = true;
                try { await Database.idbClearAll(); } catch (e) { clearOk = false; console.error('Pending clear failed:', e.message || e); }
                try { await Database.idbSetKv('clearEpoch', clearRequested); } catch (_) {}
                try { await Database.idbClearLegacy(); } catch (_) {}
                if (clearOk) Database.Storage.remove(LS_CLEAR_REQUESTED);
            } else {
                Database.Storage.remove(LS_CLEAR_REQUESTED);
            }
        }

        // ---- Load new authoritative IDB ----
        var v2 = {
            stock: [], bills: [], returns: [],
            kvStock: null, kvHist: null, kvRet: null,
            counter: 0, epoch: 0,
            lists: {}
        };
        if (typeof indexedDB !== 'undefined') {
            try {
                v2.stock = await Database.idbGetAllRecords('stock');
                v2.bills = await Database.idbGetAllRecords('bills');
                v2.returns = await Database.idbGetAllRecords('returns');
                v2.kvStock = await Database.idbGetKv(LS_STOCK, null);
                v2.kvHist = await Database.idbGetKv(LS_HISTORY, null);
                v2.kvRet = await Database.idbGetKv(LS_RETURNS, null);
                v2.counter = await Database.idbGetMeta('billCounter', 0);
                v2.epoch = await Database.idbGetKv('clearEpoch', 0);
                v2.lists.doctors = await Database.idbGetKv(CONFIG.LS_KEYS.DOCTORS, null);
                v2.lists.make = await Database.idbGetKv(CONFIG.LS_KEYS.MAKE_LIST, null);
                v2.lists.whole = await Database.idbGetKv(CONFIG.LS_KEYS.WHOLESALER_LIST, null);
                v2.lists.words = await Database.idbGetKv(CONFIG.LS_KEYS.PATIENT_WORDS, null);
                var idbTomb = await Database.idbGetKv('stockTombstones', null);
                if (idbTomb && typeof idbTomb === 'object') Object.assign(_stockTombstones, idbTomb);
                _idbReady = true;
                _storageMode = 'indexedDB+localStorage';
            } catch (e) {
                console.error('IndexedDB load failed, localStorage fallback:', e.message || e);
                _idbReady = false;
                _storageMode = 'localStorage';
            }
        }

        // ---- Load legacy DB (read-only migration/recovery) ----
        var legacy = {};
        try {
            legacy = await Database.idbLegacyGetMany([LS_STOCK, LS_HISTORY, LS_RETURNS]);
        } catch (_) {}

        var lsTomb = Database.Storage.get(LS_TOMBSTONES, null);
        if (lsTomb && typeof lsTomb === 'object') Object.assign(_stockTombstones, lsTomb);

        // ---- Clear epoch (old tab resurrection rokne ke liye) ----
        var epochLs = parseInt(Database.Storage.getString(LS_CLEAR_EPOCH, '0'), 10) || 0;
        var epochIdb = parseInt(v2.epoch, 10) || 0;
        _clearEpoch = Math.max(epochLs, epochIdb);
        Database.Storage.setString(LS_CLEAR_EPOCH, String(_clearEpoch));

        // ---- Stock merge: v2 records > v2 snapshot > localStorage/legacy ----
        var stockSources = [];
        if (Array.isArray(v2.stock) && v2.stock.length) {
            stockSources.push({ list: _migrateStockData(v2.stock), priority: 5 });
        }
        if (Array.isArray(v2.kvStock)) {
            stockSources.push({ list: _migrateStockData(v2.kvStock), priority: 4 });
        }
        if (Array.isArray(lsStock)) {
            stockSources.push({ list: _migrateStockData(lsStock), priority: flags.stock === '1' ? 2 : 4 });
        }
        if (Array.isArray(legacy[LS_STOCK])) {
            stockSources.push({ list: _migrateStockData(legacy[LS_STOCK]), priority: flags.stock === '1' ? 4 : 2 });
        }
        _stockData = _mergeStockArrays(stockSources);

        // ---- Bills merge: append-only union across every source ----
        var billSources = [];
        if (Array.isArray(v2.bills) && v2.bills.length) billSources.push(_migrateHistoryData(v2.bills));
        if (Array.isArray(v2.kvHist)) billSources.push(_migrateHistoryData(v2.kvHist));
        if (Array.isArray(lsHist)) billSources.push(_migrateHistoryData(lsHist));
        if (Array.isArray(legacy[LS_HISTORY])) billSources.push(_migrateHistoryData(legacy[LS_HISTORY]));
        _billsHistory = _mergeBillArrays.apply(null, billSources);

        // ---- Returns merge ----
        var retSources = [];
        if (Array.isArray(v2.returns) && v2.returns.length) retSources.push(_migrateReturnData(v2.returns));
        if (Array.isArray(v2.kvRet)) retSources.push(_migrateReturnData(v2.kvRet));
        if (Array.isArray(lsRet)) retSources.push(_migrateReturnData(lsRet));
        if (Array.isArray(legacy[LS_RETURNS])) retSources.push(_migrateReturnData(legacy[LS_RETURNS]));
        _returnHistory = _mergeReturnArrays.apply(null, retSources);

        // ---- Suggestion lists ----
        _doctorsList = _loadStringList(CONFIG.LS_KEYS.DOCTORS, v2.lists.doctors);
        _makeList = _loadStringList(CONFIG.LS_KEYS.MAKE_LIST, v2.lists.make);
        _wholesalerList = _loadStringList(CONFIG.LS_KEYS.WHOLESALER_LIST, v2.lists.whole);
        _patientWords = _loadStringList(CONFIG.LS_KEYS.PATIENT_WORDS, v2.lists.words);

        // ---- Counter: kabhi rewind nahi ----
        var maxBillNo = _billsHistory.reduce(function (mx, b) {
            return Math.max(mx, (b && b.billNo) || 0);
        }, 0);
        var lsCounter = parseInt(Database.Storage.getString(LS_COUNTER, '0'), 10) || 0;
        _billCounter = Math.max(lsCounter, parseInt(v2.counter, 10) || 0, maxBillNo);
        Database.Storage.setString(LS_COUNTER, String(_billCounter));

        // Migrated records ko timestamp do taaki future merges deterministic rahein.
        var now = Date.now();
        _stockData.forEach(function (s) { if (!s._savedAt) s._savedAt = now; });

        // ---- Persist merged data back (migration commit) ----
        _initialized = true;
        _setupCrossTab();
        _stockShadow = new Map(); // force all migrated stock records to IDB
        _deletedStock.clear();
        _dirtyBills = new Set(_billsHistory.map(function (b) { return b.id; }));
        _dirtyReturns = new Set(_returnHistory.map(function (r) { return r.id; }));
        await _persistAll('init');

        _emit('stockChanged', _stockData);
        _emit('historyChanged', _billsHistory);
        _emit('returnsChanged', _returnHistory);
        return { ok: !_lastSaveError, billCount: _billsHistory.length, storageMode: _storageMode, idbReady: _idbReady };
    }

    // ==================== RECONCILE (CROSS-TAB + FOCUS) ====================
    function reconcile() {
        if (!_initialized) return init();
        if (_reconciling) return _reconciling;
        _reconciling = (async function () {
            try {
                if (!_idbReady) return;
                var epoch = parseInt(await Database.idbGetKv('clearEpoch', _clearEpoch), 10) || 0;
                if (epoch > _clearEpoch) {
                    await _handleExternalClear(epoch);
                    return;
                }

                // ---- Bills ----
                var v2Bills = [];
                try { v2Bills = await Database.idbGetAllRecords('bills'); } catch (_) {}
                var kvHist = null;
                try { kvHist = await Database.idbGetKv(LS_HISTORY, null); } catch (_) {}
                var lsHist = _readLSArray(LS_HISTORY);
                var billSources = [
                    _billsHistory,
                    _migrateHistoryData(v2Bills),
                    _migrateHistoryData(kvHist || []),
                    _migrateHistoryData(lsHist || [])
                ];
                if (Date.now() - _lastLegacyReadAt > 30000) {
                    _lastLegacyReadAt = Date.now();
                    try {
                        var leg = await Database.idbLegacyGetMany([LS_HISTORY]);
                        if (Array.isArray(leg[LS_HISTORY])) billSources.push(_migrateHistoryData(leg[LS_HISTORY]));
                    } catch (_) {}
                }
                var beforeBills = new Map();
                _billsHistory.forEach(function (b) { if (b && b.id) beforeBills.set(b.id, _billSignature(b)); });
                var mergedBills = _mergeBillArrays.apply(null, billSources);
                var billsChanged = false, billsNeedPersist = false;
                mergedBills.forEach(function (b) {
                    if (!b || !b.id) return;
                    var old = beforeBills.get(b.id);
                    if (old === undefined) {
                        _dirtyBills.add(b.id);
                        billsNeedPersist = true;
                        billsChanged = true;
                    } else if (old !== _billSignature(b)) {
                        _dirtyBills.add(b.id);
                        billsNeedPersist = true;
                        billsChanged = true;
                    }
                });
                if (mergedBills.length !== _billsHistory.length) billsChanged = true;
                if (billsChanged) {
                    _replaceArray(_billsHistory, mergedBills);
                    _emit('historyChanged', _billsHistory);
                }

                // ---- Stock ----
                try {
                    var tomb = await Database.idbGetKv('stockTombstones', null);
                    if (tomb && typeof tomb === 'object') Object.assign(_stockTombstones, tomb);
                } catch (_) {}
                var v2Stock = [];
                try { v2Stock = await Database.idbGetAllRecords('stock'); } catch (_) {}
                var kvStock = null;
                try { kvStock = await Database.idbGetKv(LS_STOCK, null); } catch (_) {}
                var lsStock = _readLSArray(LS_STOCK);
                var now = Date.now();
                var dirtyStockIds = new Set();
                var currentStockIds = new Set();
                _stockData.forEach(function (s) {
                    if (!s || !s.id) return;
                    currentStockIds.add(s.id);
                    if (_stockShadow.get(s.id) !== _stockSignature(s)) {
                        s._savedAt = now;
                        dirtyStockIds.add(s.id);
                    }
                });
                _stockShadow.forEach(function (_sig, id) {
                    if (!currentStockIds.has(id)) _deletedStock.add(id);
                });
                _deletedStock.forEach(function (id) {
                    if (!_stockTombstones[id]) _stockTombstones[id] = now;
                });
                var stockSources = [{ list: _stockData, priority: 100 }];
                if (v2Stock.length) stockSources.push({ list: _migrateStockData(v2Stock), priority: 5 });
                if (Array.isArray(kvStock)) stockSources.push({ list: _migrateStockData(kvStock), priority: 4 });
                if (lsStock) stockSources.push({ list: _migrateStockData(lsStock), priority: 2 });
                if (Date.now() - _lastLegacyReadAt <= 30000) {
                    try {
                        var legStock = await Database.idbLegacyGetMany([LS_STOCK]);
                        if (Array.isArray(legStock[LS_STOCK])) stockSources.push({ list: _migrateStockData(legStock[LS_STOCK]), priority: 1 });
                    } catch (_) {}
                }
                var mergedStock = _mergeStockArrays(stockSources);
                var v2StockIds = new Set(v2Stock.map(function (s) { return s && s.id; }));
                var beforeStock = new Map();
                _stockData.forEach(function (s) { if (s && s.id) beforeStock.set(s.id, _stockSignature(s)); });
                var stockChanged = false, stockNeedPersist = false;
                mergedStock.forEach(function (s) {
                    if (!s || !s.id) return;
                    var old = beforeStock.get(s.id);
                    if (old === undefined || old !== _stockSignature(s)) stockChanged = true;
                    if (!v2StockIds.has(s.id)) {
                        stockNeedPersist = true;
                        dirtyStockIds.add(s.id);
                    }
                });
                if (mergedStock.length !== _stockData.length) stockChanged = true;
                if (stockChanged) {
                    _replaceArray(_stockData, mergedStock);
                    _emit('stockChanged', _stockData);
                }
                dirtyStockIds.forEach(function (id) { _dirtyStock.add(id); });

                // ---- Returns ----
                var v2Returns = [];
                try { v2Returns = await Database.idbGetAllRecords('returns'); } catch (_) {}
                var kvRet = null;
                try { kvRet = await Database.idbGetKv(LS_RETURNS, null); } catch (_) {}
                var lsRet = _readLSArray(LS_RETURNS);
                var beforeReturns = new Set(_returnHistory.map(function (r) { return r.id; }));
                var mergedReturns = _mergeReturnArrays(
                    _returnHistory,
                    _migrateReturnData(v2Returns),
                    _migrateReturnData(kvRet || []),
                    _migrateReturnData(lsRet || [])
                );
                var returnsChanged = false, returnsNeedPersist = false;
                mergedReturns.forEach(function (r) {
                    if (r && r.id && !beforeReturns.has(r.id)) {
                        _dirtyReturns.add(r.id);
                        returnsNeedPersist = true;
                        returnsChanged = true;
                    }
                });
                if (mergedReturns.length !== _returnHistory.length) returnsChanged = true;
                if (returnsChanged) {
                    _replaceArray(_returnHistory, mergedReturns);
                    _emit('returnsChanged', _returnHistory);
                }

                // ---- Counter ----
                var maxNo = _billsHistory.reduce(function (mx, b) { return Math.max(mx, (b && b.billNo) || 0); }, 0);
                var lsCounter = parseInt(Database.Storage.getString(LS_COUNTER, '0'), 10) || 0;
                var idbCounter = 0;
                try { idbCounter = parseInt(await Database.idbGetMeta('billCounter', 0), 10) || 0; } catch (_) {}
                var newCounter = Math.max(_billCounter, lsCounter, idbCounter, maxNo);
                if (newCounter !== _billCounter) {
                    _billCounter = newCounter;
                    Database.Storage.setString(LS_COUNTER, String(_billCounter));
                    _saveCounterToIdb();
                }

                if (billsNeedPersist) await _saveHistory('reconcile');
                if (stockNeedPersist) await _saveStock('reconcile');
                if (returnsNeedPersist) await _saveReturns('reconcile');
            } finally {
                _reconciling = null;
            }
        })();
        return _reconciling;
    }

    async function _handleExternalClear(epoch) {
        _clearEpoch = Math.max(_clearEpoch, parseInt(epoch, 10) || Date.now());
        Database.Storage.setString(LS_CLEAR_EPOCH, String(_clearEpoch));
        _replaceArray(_stockData, []);
        _replaceArray(_billsHistory, []);
        _replaceArray(_returnHistory, []);
        _doctorsList = [];
        _makeList = [];
        _wholesalerList = [];
        _patientWords = [];
        _stockShadow = new Map();
        _stockTombstones = {};
        _deletedStock.clear();
        _dirtyBills.clear();
        _dirtyReturns.clear();
        _dirtyStock.clear();
        _billCounter = 0;
        Database.Storage.setString(LS_COUNTER, '0');
        _emit('stockChanged', _stockData);
        _emit('historyChanged', _billsHistory);
        _emit('returnsChanged', _returnHistory);
        _emit('doctorsChanged', _doctorsList);
        try {
            if (typeof Inventory !== 'undefined' && Inventory.renderStockTable) Inventory.renderStockTable();
            if (typeof History !== 'undefined' && History.renderHistoryTable) History.renderHistoryTable();
            if (typeof Notifications !== 'undefined' && Notifications.renderPanel) Notifications.renderPanel();
        } catch (_) {}
        _toast('Doosre tab se data clear hua — yeh tab bhi sync ho gaya.', 'info', 5000);
    }

    function on(event, fn) {
        if (typeof fn !== 'function') return function () {};
        if (!_listeners[event]) _listeners[event] = [];
        _listeners[event].push(fn);
        return function () { off(event, fn); };
    }

    function off(event, fn) {
        if (!_listeners[event]) return;
        _listeners[event] = _listeners[event].filter(function (x) { return x !== fn; });
    }

    function getBillCounter() {
        return Math.max(_billCounter, parseInt(Database.Storage.getString(LS_COUNTER, '0'), 10) || 0);
    }

    // ==================== STOCK HELPERS ====================
    function findStockByIdOrIndex(stockId, stockIdx, nameHint) {
        if (stockId) {
            var found = _stockData.find(function (s) { return s.id === stockId; });
            if (found) return found;
        }
        if (typeof stockIdx === 'number' && stockIdx >= 0 && stockIdx < _stockData.length) {
            var fallback = _stockData[stockIdx];
            if (nameHint && fallback.name !== nameHint) {
                var byName = _stockData.find(function (s) { return s.name === nameHint; });
                if (byName) return byName;
            }
            return fallback;
        }
        if (nameHint) {
            return _stockData.find(function (s) { return s.name === nameHint; }) || null;
        }
        return null;
    }

    function _safeMerge(base, source) {
        var allowed = ['name', 'wholesaler', 'make', 'batches', 'h', 'h1', 'h2', 'narcotic', 'id'];
        for (var k in source) {
            if (Object.prototype.hasOwnProperty.call(source, k) && allowed.indexOf(k) >= 0) {
                base[k] = source[k];
            }
        }
        return base;
    }

    function _findMatch(name, wholesaler, excludeIdx) {
        var n = (name || '').toLowerCase().trim();
        var w = (wholesaler || '').toLowerCase().trim();
        return _stockData.findIndex(function (m, i) {
            if (typeof excludeIdx === 'number' && i === excludeIdx) return false;
            if ((m.name || '').toLowerCase().trim() !== n) return false;
            var mw = (m.wholesaler || '').toLowerCase().trim();
            return mw === w;
        });
    }

    function _mergeBatches(newBatches, existingBatches) {
        var batchMap = new Map();
        (existingBatches || []).forEach(function (b) {
            batchMap.set(((b.batch || '') + '|' + (b.expiry || '')).toLowerCase(), Object.assign({}, b));
        });
        (newBatches || []).forEach(function (b) {
            var key = ((b.batch || '') + '|' + (b.expiry || '')).toLowerCase();
            if (batchMap.has(key)) {
                var existing = batchMap.get(key);
                existing.qty = (existing.qty || 0) + (b.qty || 0);
                if (b.price !== null && b.price !== undefined) existing.price = b.price;
                if (b.stripSize !== null && b.stripSize !== undefined) existing.stripSize = b.stripSize;
                existing.id = b.id || existing.id || Utils.generateId('batch');
            } else {
                batchMap.set(key, Object.assign({}, b, { id: b.id || Utils.generateId('batch') }));
            }
        });
        return Array.from(batchMap.values());
    }

    function addOrUpdateMedicine(medObj, editIdx) {
        if (!medObj || typeof medObj !== 'object') return null;
        editIdx = (typeof editIdx === 'number' && isFinite(editIdx)) ? Math.floor(editIdx) : -1;
        if (editIdx < 0 || editIdx >= _stockData.length || !_stockData[editIdx]) editIdx = -1;
        if (editIdx > -1) {
            var existingId = _stockData[editIdx] ? _stockData[editIdx].id : null;
            var matchIdx = _findMatch(medObj.name, medObj.wholesaler, editIdx);
            if (matchIdx > -1) {
                var mergedBatches = _mergeBatches(medObj.batches, _stockData[matchIdx].batches);
                var mergedMedicine = {
                    id: existingId,
                    name: medObj.name,
                    wholesaler: medObj.wholesaler || _stockData[matchIdx].wholesaler,
                    make: medObj.make || _stockData[matchIdx].make,
                    h: medObj.h || _stockData[matchIdx].h,
                    h1: medObj.h1 || _stockData[matchIdx].h1,
                    h2: medObj.h2 || _stockData[matchIdx].h2,
                    narcotic: medObj.narcotic || _stockData[matchIdx].narcotic,
                    batches: mergedBatches
                };
                var removeA = matchIdx;
                var removeB = editIdx;
                if (removeA > removeB) { removeA = editIdx; removeB = matchIdx; }
                _stockData.splice(removeB, 1);
                _stockData.splice(removeA, 1);
                _stockData.push(mergedMedicine);
                _saveStock('medicine-merge');
                return { merged: true, name: medObj.name };
            }
            var updated = { id: existingId };
            _safeMerge(updated, medObj);
            _stockData[editIdx] = updated;
            _saveStock('medicine-update');
            return { updated: true, name: medObj.name };
        }
        var matchIdx2 = _findMatch(medObj.name, medObj.wholesaler);
        if (matchIdx2 > -1) {
            _stockData[matchIdx2].batches = _mergeBatches(medObj.batches, _stockData[matchIdx2].batches);
            if (medObj.h1) _stockData[matchIdx2].h1 = true;
            _saveStock('batch-add');
            return { batchAdded: true, name: medObj.name };
        }
        var newItem = { id: Utils.generateId('med') };
        _safeMerge(newItem, medObj);
        _stockData.push(newItem);
        _saveStock('medicine-add');
        return { saved: true, name: medObj.name };
    }

    function deleteMedicine(index) {
        if (index < 0 || index >= _stockData.length) return null;
        var med = _stockData[index];
        _stockData.splice(index, 1);
        _saveStock('medicine-delete');
        return med;
    }

    function saveStock() {
        if (!_initialized) {
            return init().then(function () { return _saveStock('manual'); });
        }
        return _saveStock('manual');
    }

    function saveHistory() {
        if (!_initialized) {
            return init().then(function () { return _saveHistory('manual'); });
        }
        return _saveHistory('manual');
    }

    // ==================== BILL COUNTER / BILLS ====================
    function getNextBillNumber() {
        var maxFromHistory = _billsHistory.reduce(function (max, b) {
            return Math.max(max, (b && b.billNo) || 0);
        }, 0);
        var storedCounter = parseInt(Database.Storage.getString(LS_COUNTER, '0'), 10) || 0;
        var counter = Math.max(storedCounter, _billCounter, maxFromHistory) + 1;
        var used = new Set();
        _billsHistory.forEach(function (b) { used.add(parseInt(b && b.billNo, 10) || 0); });
        while (used.has(counter)) counter++;
        _billCounter = counter;
        Database.Storage.setString(LS_COUNTER, String(counter));
        _saveCounterToIdb();
        return counter;
    }

    async function addBill(bill) {
        if (!_initialized) await init();
        if (!bill || typeof bill !== 'object') return { ok: false, message: 'Invalid bill' };
        if (!bill.id) bill.id = Utils.generateId('bill');
        var existing = _billsHistory.find(function (b) { return b.id === bill.id; });
        if (existing) Object.assign(existing, bill);
        else _billsHistory.push(bill);
        _dirtyBills.add(bill.id);
        _billCounter = Math.max(_billCounter, parseInt(bill.billNo, 10) || 0);
        // Turant synchronous mirror — IDB save se pehle hi bill disk par safe.
        _mirrorHistoryToLS();
        _emit('historyChanged', _billsHistory);
        var res = await _saveHistory('bill');
        if (!res || !res.ok) {
            // Dono stores fail — memory se naya bill hatao taaki retry par
            // duplicate bill na bane. Form data caller ke paas safe rehta hai.
            if (!existing) {
                _replaceArray(_billsHistory, _billsHistory.filter(function (b) { return b.id !== bill.id; }));
                _dirtyBills.delete(bill.id);
                _emit('historyChanged', _billsHistory);
            }
            return Object.assign({}, res, { ok: false, rolledBack: !existing });
        }
        return res;
    }

    async function updateBill(billId, updates) {
        if (!_initialized) await init();
        return Database.withLock('bill:' + billId, async function () {
            var bill = _billsHistory.find(function (b) { return b.id === billId; });
            if (!bill) return { ok: false, message: 'Bill nahi mila' };
            var idbBill = null;
            if (_idbReady) {
                try { idbBill = await Database.idbGetRecord('bills', billId); } catch (_) {}
            }
            if (idbBill) {
                var merged = Object.assign({}, idbBill, bill, updates || {});
                if (idbBill.cancelled) {
                    merged.cancelled = true;
                    merged.cancelReason = idbBill.cancelReason || merged.cancelReason || '';
                    merged.cancelledAt = idbBill.cancelledAt || merged.cancelledAt || '';
                }
                Object.assign(bill, merged);
            } else {
                Object.assign(bill, updates || {});
            }
            if (updates && updates.cancelled) bill.cancelled = true;
            _dirtyBills.add(billId);
            // Cancel/update bhi turant synchronous mirror par likho.
            _mirrorHistoryToLS();
            _emit('historyChanged', _billsHistory);
            var res = await _saveHistory('update');
            return res;
        });
    }

    // ==================== SUGGESTION LISTS ====================
    function _saveList(key, list) {
        Database.Storage.set(key, list);
        if (_idbReady) Database.idbSetKv(key, list).catch(function () {});
    }

    function addDoctor(name) {
        name = _sanitizeField(name, 200);
        if (!name) return false;
        if (!_doctorsList.includes(name)) {
            _doctorsList.push(name);
            _saveList(CONFIG.LS_KEYS.DOCTORS, _doctorsList);
            _emit('doctorsChanged', _doctorsList);
            return true;
        }
        return false;
    }

    function addMake(name) {
        name = _sanitizeField(name, 200);
        if (!name) return false;
        if (!_makeList.includes(name)) {
            _makeList.push(name);
            _saveList(CONFIG.LS_KEYS.MAKE_LIST, _makeList);
            return true;
        }
        return false;
    }

    function addWholesaler(name) {
        name = _sanitizeField(name, 200);
        if (!name) return false;
        if (!_wholesalerList.includes(name)) {
            _wholesalerList.push(name);
            _saveList(CONFIG.LS_KEYS.WHOLESALER_LIST, _wholesalerList);
            return true;
        }
        return false;
    }

    function updateWholesaler(oldName, newName) {
        var idx = _wholesalerList.indexOf(oldName);
        if (idx > -1) {
            _wholesalerList[idx] = _sanitizeField(newName, 200);
            _saveList(CONFIG.LS_KEYS.WHOLESALER_LIST, _wholesalerList);
            return true;
        }
        return false;
    }

    function removeWholesaler(name) {
        var idx = _wholesalerList.indexOf(name);
        if (idx > -1) {
            _wholesalerList.splice(idx, 1);
            _saveList(CONFIG.LS_KEYS.WHOLESALER_LIST, _wholesalerList);
            return true;
        }
        return false;
    }

    function getWholesalerList() { return _wholesalerList; }

    function removeDoctor(name) {
        var idx = _doctorsList.indexOf(name);
        if (idx > -1) {
            _doctorsList.splice(idx, 1);
            _saveList(CONFIG.LS_KEYS.DOCTORS, _doctorsList);
            _emit('doctorsChanged', _doctorsList);
            return true;
        }
        return false;
    }

    function updateDoctor(oldName, newName) {
        var idx = _doctorsList.indexOf(oldName);
        if (idx > -1) {
            _doctorsList[idx] = _sanitizeField(newName, 200);
            _saveList(CONFIG.LS_KEYS.DOCTORS, _doctorsList);
            _emit('doctorsChanged', _doctorsList);
            return true;
        }
        return false;
    }

    function removePatientWord(word) {
        var idx = _patientWords.indexOf(word);
        if (idx > -1) {
            _patientWords.splice(idx, 1);
            _saveList(CONFIG.LS_KEYS.PATIENT_WORDS, _patientWords);
            return true;
        }
        return false;
    }

    function updatePatientWord(oldWord, newWord) {
        var idx = _patientWords.indexOf(oldWord);
        if (idx > -1) {
            _patientWords[idx] = _sanitizeField(newWord, 200);
            _saveList(CONFIG.LS_KEYS.PATIENT_WORDS, _patientWords);
            return true;
        }
        return false;
    }

    function savePatientName(fullName) {
        var words = String(fullName || '').trim().split(/\s+/);
        var changed = false;
        words.forEach(function (w) {
            w = _sanitizeField(w, 100);
            if (w && !_patientWords.includes(w)) {
                _patientWords.push(w);
                changed = true;
            }
        });
        if (changed) _saveList(CONFIG.LS_KEYS.PATIENT_WORDS, _patientWords);
    }

    // ==================== EXPIRED MEDICINE RETURN (ATOMIC) ====================
    async function recordMedicineReturn(input) {
        function failure(message, extra) {
            return Object.assign({ ok: false, message: message }, extra || {});
        }
        if (!input || typeof input !== 'object') return failure('Return details missing hain.');
        var requestId = _sanitizeField(input.requestId, 100);
        if (!requestId) return failure('Return request ID missing hai — form dobara kholein.');
        var qty = parseInt(input.qty, 10);
        if (!qty || isNaN(qty) || qty <= 0) return failure('Return quantity 1 ya usse zyada honi chahiye.');
        var returnDate = _sanitizeField(input.returnDate, 20);
        var returnDateObj = Utils.parseDisplayDate(returnDate);
        if (!returnDateObj) return failure('Return date DD/MM/YYYY format mein valid daalein.');
        var today = new Date();
        today.setHours(0, 0, 0, 0);
        if (returnDateObj > today) return failure('Return date aaj se aage ki nahi ho sakti.');
        var remarks = _sanitizeField(input.remarks, 500);
        var stockId = _sanitizeField(input.stockId, 100);
        var batchId = _sanitizeField(input.batchId, 100);

        await flushSaves();

        var med = _stockData.find(function (s) { return s && s.id === stockId; });
        if (!med) return failure('Medicine stock record nahi mila. Inventory refresh karein.');
        var batch = null;
        if (batchId) {
            batch = (med.batches || []).find(function (b) { return b && b.id === batchId; });
        }
        if (!batch) {
            var batchIdx = parseInt(input.batchIndex, 10);
            if (!isNaN(batchIdx) && batchIdx >= 0 && med.batches && med.batches[batchIdx]) {
                batch = med.batches[batchIdx];
            }
        }
        if (!batch) return failure('Batch record nahi mila. Inventory refresh karein.');
        if (!Utils.isExpired(batch.expiry)) return failure('Sirf expired batch supplier ko return ki ja sakti hai.');

        if (_returnHistory.some(function (r) { return r && r.requestId === requestId; })) {
            return failure('Yeh return pehle hi save ho chuka hai (duplicate request).', { duplicate: true });
        }

        var oldBatchId = batch.id || '';
        if (!batch.id) batch.id = Utils.generateId('batch');
        var stockBefore = Math.max(0, parseInt(batch.qty, 10) || 0);
        if (stockBefore <= 0) return failure('Is batch mein ab return karne ke liye stock nahi bacha.');
        if (qty > stockBefore) {
            return failure('Over-return nahi ho sakta. Sirf ' + stockBefore + ' units returnable hain.');
        }

        function belongsToBatch(r) {
            if (!r || r.stockId !== med.id) return false;
            if (r.batchId && batch.id && r.batchId === batch.id) return true;
            return String(r.batch || '') === String(batch.batch || '') &&
                String(r.expiry || '') === String(batch.expiry || '');
        }
        var returnedBefore = _returnHistory.reduce(function (sum, r) {
            return sum + (belongsToBatch(r) ? (parseInt(r.qty, 10) || 0) : 0);
        }, 0);

        var now = Date.now();
        var recentDup = _returnHistory.find(function (r) {
            if (!belongsToBatch(r)) return false;
            if ((parseInt(r.timestamp, 10) || 0) > now - 10000 &&
                (parseInt(r.qty, 10) || 0) === qty &&
                (r.returnDate || '') === returnDate &&
                (r.remarks || '') === remarks) return true;
            return false;
        });
        if (recentDup) {
            return failure('Yeh same return abhi-abhi save hua hai. Duplicate entry block ki gayi.', { duplicate: true });
        }

        var remainingAfter = stockBefore - qty;
        var statusBefore = returnedBefore > 0 ? 'Partially Returned' : 'Pending Return';
        var statusAfter = remainingAfter > 0 ? 'Partially Returned' : 'Returned';
        var record = {
            id: Utils.generateId('ret'),
            requestId: requestId,
            stockId: med.id,
            batchId: batch.id,
            medicineName: med.name || '',
            make: med.make || '',
            supplier: med.wholesaler || '',
            batch: batch.batch || '',
            expiry: batch.expiry || '',
            qty: qty,
            returnDate: returnDate,
            remarks: remarks,
            statusBefore: statusBefore,
            statusAfter: statusAfter,
            remainingAfter: remainingAfter,
            stockBefore: stockBefore,
            stockAfter: remainingAfter,
            returnedBefore: returnedBefore,
            sourceType: 'inventory',
            createdAt: new Date(now).toLocaleString('en-IN'),
            timestamp: now
        };

        batch.qty = remainingAfter;
        _returnHistory.push(record);
        _dirtyReturns.add(record.id);

        var saveRes = await _saveStockAndReturns('return', [record.id]);
        if (saveRes && saveRes.ok) {
            if (saveRes.localStorage && !saveRes.idb) {
                _toast('⚠️ Return localStorage fallback mein save hua — turant Offline Backup download karein.', 'warn', 6000);
            }
            return { ok: true, record: record, remaining: remainingAfter, statusAfter: statusAfter, storage: saveRes.idb ? 'indexedDB' : 'localStorage' };
        }

        // Dono stores fail — memory rollback + purana state wapas persist.
        try { batch.qty = stockBefore; } catch (_) {}
        if (!oldBatchId) { try { batch.id = ''; } catch (_) {} }
        _replaceArray(_returnHistory, _returnHistory.filter(function (r) { return r.id !== record.id; }));
        _dirtyReturns.delete(record.id);
        await _saveStockAndReturns('rollback');
        return failure('Return save nahi ho paya — stock aur history rollback kar di gayi. Storage space check karein.');
    }

    // ==================== BULK EXPIRED MEDICINE RETURN (ATOMIC) ====================
    async function recordMedicineReturns(input) {
        function failure(message, extra) {
            return Object.assign({ ok: false, message: message }, extra || {});
        }
        if (!input || typeof input !== 'object') return failure('Bulk return details missing hain.');
        var requestId = _sanitizeField(input.requestId, 100);
        if (!requestId) return failure('Return request ID missing hai — form dobara kholein.');
        if (!Array.isArray(input.items) || !input.items.length) return failure('Kam se kam ek expired medicine select karein.');
        if (input.items.length > 200) return failure('Ek baar mein 200 se zyada items return nahi ho sakte.');
        var returnDate = _sanitizeField(input.returnDate, 20);
        var returnDateObj = Utils.parseDisplayDate(returnDate);
        if (!returnDateObj) return failure('Return date DD/MM/YYYY format mein valid daalein.');
        var today = new Date();
        today.setHours(0, 0, 0, 0);
        if (returnDateObj > today) return failure('Return date aaj se aage ki nahi ho sakti.');
        var remarks = _sanitizeField(input.remarks, 500);

        await flushSaves();

        function findBatch(med, rawBatchId, rawBatchIndex) {
            var batch = null;
            if (rawBatchId) {
                batch = (med.batches || []).find(function (b) { return b && b.id === rawBatchId; });
            }
            if (!batch) {
                var bi = parseInt(rawBatchIndex, 10);
                if (!isNaN(bi) && bi >= 0 && med.batches && med.batches[bi]) batch = med.batches[bi];
            }
            return batch;
        }

        var now = Date.now();
        var existingRequestIds = {};
        for (var ri = 0; ri < _returnHistory.length; ri++) {
            var existing = _returnHistory[ri];
            if (existing && existing.requestId) existingRequestIds[existing.requestId] = true;
        }

        var plan = [];
        var seenBatches = [];
        var totalQty = 0;

        for (var i = 0; i < input.items.length; i++) {
            var raw = input.items[i];
            var label = 'Item ' + (i + 1);
            if (!raw || typeof raw !== 'object') return failure(label + ': return details missing hain.');
            var stockId = _sanitizeField(raw.stockId, 100);
            var batchId = _sanitizeField(raw.batchId, 100);
            var qty = parseInt(raw.qty, 10);
            if (!qty || isNaN(qty) || qty <= 0) return failure(label + ': return quantity 1 ya usse zyada honi chahiye.');

            var med = _stockData.find(function (s) { return s && s.id === stockId; });
            if (!med) return failure(label + ': medicine stock record nahi mila. Inventory refresh karein.');
            var batch = findBatch(med, batchId, raw.batchIndex);
            if (!batch) return failure(label + ': batch record nahi mila. Inventory refresh karein.');
            label = med.name + ' • Batch ' + (batch.batch || '-');
            if (!Utils.isExpired(batch.expiry)) return failure(label + ': sirf expired batch supplier ko return ki ja sakti hai.');

            if (seenBatches.indexOf(batch) !== -1) {
                return failure(label + ': same batch ek hi return mein do baar select hui hai.');
            }
            seenBatches.push(batch);

            var stockBefore = Math.max(0, parseInt(batch.qty, 10) || 0);
            if (stockBefore <= 0) return failure(label + ': is batch mein ab return karne ke liye stock nahi bacha.');
            if (qty > stockBefore) {
                return failure(label + ': over-return nahi ho sakta. Sirf ' + stockBefore + ' units returnable hain.');
            }

            var itemRequestId = _sanitizeField(raw.requestId, 100) || (requestId + ':' + (i + 1));
            if (existingRequestIds[itemRequestId]) {
                return failure(label + ': yeh return pehle hi save ho chuka hai (duplicate request).', { duplicate: true });
            }
            existingRequestIds[itemRequestId] = true;

            var planBatchId = batch.id || '';
            var planBatch = batch;
            var belongsToBatch = function (r) {
                if (!r || r.stockId !== med.id) return false;
                if (r.batchId && planBatchId && r.batchId === planBatchId) return true;
                return String(r.batch || '') === String(planBatch.batch || '') &&
                    String(r.expiry || '') === String(planBatch.expiry || '');
            };
            var returnedBefore = _returnHistory.reduce(function (sum, r) {
                return sum + (belongsToBatch(r) ? (parseInt(r.qty, 10) || 0) : 0);
            }, 0);

            var recentDup = _returnHistory.find(function (r) {
                if (!belongsToBatch(r)) return false;
                if ((parseInt(r.timestamp, 10) || 0) > now - 10000 &&
                    (parseInt(r.qty, 10) || 0) === qty &&
                    (r.returnDate || '') === returnDate &&
                    (r.remarks || '') === remarks) return true;
                return false;
            });
            if (recentDup) {
                return failure(label + ': yeh same return abhi-abhi save hua hai. Duplicate entry block ki gayi.', { duplicate: true });
            }

            plan.push({
                requestId: itemRequestId,
                med: med,
                batch: batch,
                qty: qty,
                stockBefore: stockBefore,
                returnedBefore: returnedBefore
            });
            totalQty += qty;
        }

        var records = [];
        var stockSnap = plan.map(function (p) {
            return { batch: p.batch, qty: p.stockBefore, oldBatchId: p.batch.id || '' };
        });
        plan.forEach(function (p, idx) {
            if (!p.batch.id) p.batch.id = Utils.generateId('batch');
            var remainingAfter = p.stockBefore - p.qty;
            var statusBefore = p.returnedBefore > 0 ? 'Partially Returned' : 'Pending Return';
            var statusAfter = remainingAfter > 0 ? 'Partially Returned' : 'Returned';
            p.batch.qty = remainingAfter;
            var record = {
                id: Utils.generateId('ret'),
                requestId: p.requestId,
                stockId: p.med.id,
                batchId: p.batch.id,
                medicineName: p.med.name || '',
                make: p.med.make || '',
                supplier: p.med.wholesaler || '',
                batch: p.batch.batch || '',
                expiry: p.batch.expiry || '',
                qty: p.qty,
                returnDate: returnDate,
                remarks: remarks,
                statusBefore: statusBefore,
                statusAfter: statusAfter,
                remainingAfter: remainingAfter,
                stockBefore: p.stockBefore,
                stockAfter: remainingAfter,
                returnedBefore: p.returnedBefore,
                sourceType: 'inventory',
                createdAt: new Date(now).toLocaleString('en-IN'),
                timestamp: now + idx
            };
            records.push(record);
            _returnHistory.push(record);
            _dirtyReturns.add(record.id);
        });

        var saveRes = await _saveStockAndReturns('bulk-return', records.map(function (r) { return r.id; }));
        if (saveRes && saveRes.ok) {
            if (saveRes.localStorage && !saveRes.idb) {
                _toast('⚠️ Bulk return localStorage fallback mein save hua — turant Offline Backup download karein.', 'warn', 6000);
            }
            return { ok: true, records: records, count: records.length, totalQty: totalQty, storage: saveRes.idb ? 'indexedDB' : 'localStorage' };
        }

        // Dono stores fail — memory rollback + purana state wapas persist.
        stockSnap.forEach(function (s) {
            try {
                s.batch.qty = s.qty;
                if (!s.oldBatchId) s.batch.id = '';
            } catch (_) {}
        });
        var recordIds = new Set(records.map(function (r) { return r.id; }));
        _replaceArray(_returnHistory, _returnHistory.filter(function (r) { return !recordIds.has(r.id); }));
        recordIds.forEach(function (id) { _dirtyReturns.delete(id); });
        await _saveStockAndReturns('rollback');
        return failure('Bulk return save nahi ho paya — stock aur history rollback kar di gayi. Storage space check karein.');
    }

    // ==================== BACKUP VALIDATION ====================
    function _backupArray(data, names) {
        for (var i = 0; i < names.length; i++) {
            if (Array.isArray(data[names[i]])) return data[names[i]];
        }
        return null;
    }

    function _backupStringList(data, names) {
        var arr = _backupArray(data, names);
        if (!arr) return [];
        var out = [];
        arr.forEach(function (x) {
            var val = '';
            if (typeof x === 'string') val = x;
            else if (x && typeof x === 'object') val = x.name || x.word || '';
            val = _sanitizeField(val, 200);
            if (val && out.indexOf(val) === -1) out.push(val);
        });
        return out;
    }

    function _extractBackup(data) {
        return {
            stockRaw: _backupArray(data, ['stock', 'stockData']),
            historyRaw: _backupArray(data, ['history', 'bills', 'billsHistory']),
            returnsRaw: _backupArray(data, ['returnHistory', 'returns']),
            purchaseRaw: _backupArray(data, ['purchaseBills', 'purchases']),
            doctors: _backupStringList(data, ['doctors']),
            makeList: _backupStringList(data, ['makeList', 'make_list']),
            wholesalerList: _backupStringList(data, ['wholesalerList', 'wholesaler_list']),
            patientWords: _backupStringList(data, ['patientWords', 'patient_words']),
            billCounter: Math.max(0, parseInt(data && data.billCounter, 10) || 0)
        };
    }

    function validateBackup(data) {
        var fatal = [];
        var warnings = [];
        var counts = {
            stock: 0, history: 0, validBills: 0, invalidBills: 0,
            returns: 0, purchaseBills: 0, doctors: 0, makeList: 0,
            wholesalerList: 0, patientWords: 0, maxBillNo: 0, billCounter: 0
        };

        if (!data || typeof data !== 'object' || Array.isArray(data)) {
            return { ok: false, fatal: ['Backup file ka format galat hai (JSON object expected).'], warnings: warnings, counts: counts };
        }

        var knownKeys = ['stock', 'stockData', 'history', 'bills', 'billsHistory',
            'returnHistory', 'returns', 'purchaseBills', 'purchases', 'doctors',
            'makeList', 'make_list', 'wholesalerList', 'wholesaler_list',
            'patientWords', 'patient_words', 'billCounter', 'backupMeta'];
        var hasKnownKey = false;
        for (var k = 0; k < knownKeys.length; k++) {
            if (Object.prototype.hasOwnProperty.call(data, knownKeys[k])) { hasKnownKey = true; break; }
        }
        if (!hasKnownKey) {
            fatal.push('Yeh MediSoft backup file nahi lagti — koi known data field nahi mila.');
        }

        var stockRaw = _backupArray(data, ['stock', 'stockData']);
        var historyRaw = _backupArray(data, ['history', 'bills', 'billsHistory']);
        var returnsRaw = _backupArray(data, ['returnHistory', 'returns']);
        var purchaseRaw = _backupArray(data, ['purchaseBills', 'purchases']);

        if (stockRaw === null && historyRaw === null && returnsRaw === null && purchaseRaw === null) {
            fatal.push('Backup mein stock/history/returns data arrays nahi mile.');
        }
        if (data.stock !== undefined && !Array.isArray(data.stock) && !Array.isArray(data.stockData)) {
            fatal.push('Backup ka "stock" field array nahi hai.');
        }
        if (data.history !== undefined && !Array.isArray(data.history) && !Array.isArray(data.bills) && !Array.isArray(data.billsHistory)) {
            fatal.push('Backup ka "history" field array nahi hai.');
        }
        if (stockRaw && stockRaw.length > 50000) fatal.push('Backup mein 50,000 se zyada stock records hain — file corrupt ho sakti hai.');
        if (historyRaw && historyRaw.length > 50000) fatal.push('Backup mein 50,000 se zyada bills hain — file corrupt ho sakti hai.');

        counts.stock = stockRaw ? stockRaw.length : 0;
        counts.history = historyRaw ? historyRaw.length : 0;
        counts.returns = returnsRaw ? returnsRaw.length : 0;
        counts.purchaseBills = purchaseRaw ? purchaseRaw.length : 0;
        counts.doctors = _backupStringList(data, ['doctors']).length;
        counts.makeList = _backupStringList(data, ['makeList', 'make_list']).length;
        counts.wholesalerList = _backupStringList(data, ['wholesalerList', 'wholesaler_list']).length;
        counts.patientWords = _backupStringList(data, ['patientWords', 'patient_words']).length;
        counts.billCounter = Math.max(0, parseInt(data.billCounter, 10) || 0);

        var billsWithoutItems = 0;
        (historyRaw || []).forEach(function (h) {
            if (!h || typeof h !== 'object') { counts.invalidBills++; return; }
            var billNo = parseInt(h.billNo, 10) || 0;
            if (billNo <= 0) { counts.invalidBills++; return; }
            counts.validBills++;
            if (billNo > counts.maxBillNo) counts.maxBillNo = billNo;
            if (!Array.isArray(h.items) || !h.items.length) billsWithoutItems++;
        });

        if (counts.invalidBills > 0) {
            warnings.push(counts.invalidBills + ' bill record(s) invalid hain (bill number missing) — import mein skip honge.');
        }
        if (billsWithoutItems > 0) {
            warnings.push(billsWithoutItems + ' bill(s) mein items nahi hain — sirf bill header restore hoga.');
        }
        if (counts.billCounter > counts.maxBillNo) {
            warnings.push('Backup counter ' + counts.billCounter + ' hai lekin sabse bada bill ' + counts.maxBillNo +
                ' — ' + (counts.billCounter - counts.maxBillNo) + ' bill(s) is backup mein missing ho sakte hain.');
        }
        if (counts.history > 0 && counts.billCounter === 0) {
            warnings.push('Backup mein billCounter 0 hai — restore ke baad counter max bill number se set hoga.');
        }

        return {
            ok: fatal.length === 0,
            fatal: fatal,
            warnings: warnings,
            counts: counts
        };
    }

    // ==================== EXPORT ====================
    function exportData() {
        return _clonePlain({
            stock: _stockData,
            history: _billsHistory,
            returnHistory: _returnHistory,
            doctors: _doctorsList,
            makeList: _makeList,
            wholesalerList: _wholesalerList,
            patientWords: _patientWords,
            billCounter: getBillCounter()
        });
    }

    async function exportAllData() {
        if (!_initialized) await init();
        await flushSaves();
        try { await reconcile(); } catch (_) {}
        await flushSaves();
        var data = exportData();
        data.purchaseBills = [];
        if (typeof PurchaseModule !== 'undefined' && PurchaseModule.getAllBills) {
            try {
                var purchases = await PurchaseModule.getAllBills();
                if (Array.isArray(purchases)) data.purchaseBills = purchases;
            } catch (e) {
                console.warn('Purchase bills export skipped:', e.message || e);
            }
        }
        return data;
    }

    // ==================== IMPORT (SAFE MERGE) ====================
    function _billMergeKey(b) {
        var no = parseInt(b && b.billNo, 10) || 0;
        if (!no) return '';
        return no + '|' + (b.date || '') + '|' + (Number(b.total) || 0).toFixed(2);
    }

    function _stockMergeKey(s) {
        if (!s) return '';
        return String(s.name || '').toLowerCase().trim() + '|' + String(s.wholesaler || '').toLowerCase().trim();
    }

    function _mergeStockRecord(target, source) {
        var changed = false;
        ['wholesaler', 'make'].forEach(function (field) {
            if (source[field] && !target[field]) { target[field] = source[field]; changed = true; }
        });
        ['h', 'h1', 'h2', 'narcotic'].forEach(function (flag) {
            if (source[flag] && !target[flag]) { target[flag] = true; changed = true; }
        });
        if (!Array.isArray(target.batches)) { target.batches = []; changed = true; }
        (source.batches || []).forEach(function (sb) {
            if (!sb) return;
            var found = target.batches.find(function (b) {
                return b && String(b.batch || '') === String(sb.batch || '') &&
                    String(b.expiry || '') === String(sb.expiry || '');
            });
            if (!found) {
                target.batches.push(Object.assign({}, sb, {
                    id: sb.id || Utils.generateId('batch')
                }));
                changed = true;
                return;
            }
            var localQty = Math.max(0, parseInt(found.qty, 10) || 0);
            var backupQty = Math.max(0, parseInt(sb.qty, 10) || 0);
            if (localQty <= 0 && backupQty > 0) { found.qty = backupQty; changed = true; }
            if (!found.price && sb.price) { found.price = sb.price; changed = true; }
            if (!found.stripSize && sb.stripSize) { found.stripSize = sb.stripSize; changed = true; }
            if (!found.id) { found.id = sb.id || Utils.generateId('batch'); changed = true; }
        });
        return changed;
    }

    function _mergeStringList(target, incoming) {
        var added = 0;
        (incoming || []).forEach(function (raw) {
            var val = _sanitizeField(raw, 200);
            if (val && target.indexOf(val) === -1) { target.push(val); added++; }
        });
        return added;
    }

    async function importAllData(data) {
        if (!_initialized) await init();
        await flushSaves();

        var validation = validateBackup(data);
        if (!validation.ok) {
            return {
                ok: false,
                fatal: validation.fatal,
                warnings: validation.warnings,
                verified: false
            };
        }

        var extracted = _extractBackup(data);
        var report = {
            ok: true,
            addedBills: 0,
            dupBills: 0,
            invalidBills: 0,
            cancelsApplied: 0,
            addedStock: 0,
            mergedStock: 0,
            updatedStock: 0,
            addedReturns: 0,
            dupReturns: 0,
            purchaseAdded: 0,
            purchaseFailed: 0,
            addedDoctors: 0,
            addedMakeList: 0,
            addedWholesalerList: 0,
            addedPatientWords: 0,
            warnings: validation.warnings.slice(),
            fatal: [],
            verified: false,
            before: {
                bills: _billsHistory.length,
                stock: _stockData.length,
                returns: _returnHistory.length
            }
        };

        // ---- Bills: append-only union, cancel state monotonic ----
        var rawBills = extracted.historyRaw || [];
        var validRawBills = [];
        rawBills.forEach(function (h) {
            if (!h || typeof h !== 'object') { report.invalidBills++; return; }
            var no = parseInt(h.billNo, 10) || 0;
            if (no <= 0) { report.invalidBills++; return; }
            validRawBills.push(h);
        });
        var incomingBills = _migrateHistoryData(validRawBills);
        var billById = new Map();
        var billByKey = new Map();
        _billsHistory.forEach(function (b) {
            if (!b || !b.id) return;
            billById.set(b.id, b);
            var key = _billMergeKey(b);
            if (key && !billByKey.has(key)) billByKey.set(key, b);
        });
        var addedBillIds = [];

        function mergeCancelState(target, source) {
            if (!source || !source.cancelled || !target || target.cancelled) return false;
            target.cancelled = true;
            target.cancelReason = source.cancelReason || target.cancelReason || '';
            target.cancelledAt = source.cancelledAt || target.cancelledAt || '';
            return true;
        }

        incomingBills.forEach(function (b) {
            var existing = billById.get(b.id);
            if (!existing) {
                var key = _billMergeKey(b);
                var sameBill = key ? billByKey.get(key) : null;
                if (sameBill) {
                    report.dupBills++;
                    var cancelChanged = mergeCancelState(sameBill, b);
                    if (cancelChanged) { report.cancelsApplied++; _dirtyBills.add(sameBill.id); }
                    if (Array.isArray(b.items) && b.items.length > (Array.isArray(sameBill.items) ? sameBill.items.length : 0)) {
                        sameBill.items = b.items;
                        if (b.total) sameBill.total = b.total;
                        _dirtyBills.add(sameBill.id);
                    }
                    return;
                }
                _billsHistory.push(b);
                billById.set(b.id, b);
                if (key) billByKey.set(key, b);
                _dirtyBills.add(b.id);
                addedBillIds.push(b.id);
                report.addedBills++;
                return;
            }

            report.dupBills++;
            var changed = false;
            if (mergeCancelState(existing, b)) { report.cancelsApplied++; changed = true; }
            if (Array.isArray(b.items) && b.items.length > (Array.isArray(existing.items) ? existing.items.length : 0)) {
                existing.items = b.items;
                if (b.total) existing.total = b.total;
                changed = true;
            }
            if (changed) _dirtyBills.add(existing.id);
        });

        // ---- Stock: id / name+wholesaler match, batches merged without double-count ----
        var incomingStock = _migrateStockData(extracted.stockRaw || []);
        var stockById = new Map();
        var stockByKey = new Map();
        _stockData.forEach(function (s) {
            if (!s || !s.id) return;
            stockById.set(s.id, s);
            var key = _stockMergeKey(s);
            if (key && !stockByKey.has(key)) stockByKey.set(key, s);
        });
        var now = Date.now();
        var addedStockIds = [];

        incomingStock.forEach(function (med) {
            var existing = stockById.get(med.id);
            if (!existing) {
                var key = _stockMergeKey(med);
                existing = key ? stockByKey.get(key) : null;
                if (existing) report.mergedStock++;
            }
            if (existing) {
                if (_mergeStockRecord(existing, med)) {
                    existing._savedAt = now;
                    report.updatedStock++;
                }
                return;
            }
            med._savedAt = now;
            _stockData.push(med);
            stockById.set(med.id, med);
            var newKey = _stockMergeKey(med);
            if (newKey) stockByKey.set(newKey, med);
            addedStockIds.push(med.id);
            report.addedStock++;
        });

        // ---- Returns: id / requestId dedupe ----
        var incomingReturns = _migrateReturnData(extracted.returnsRaw || []);
        var returnIds = new Set(_returnHistory.map(function (r) { return r && r.id; }).filter(Boolean));
        var returnRequestIds = new Set(_returnHistory.map(function (r) { return r && r.requestId; }).filter(Boolean));
        var addedReturnIds = [];
        incomingReturns.forEach(function (r) {
            if (!r || !r.id) { return; }
            if (returnIds.has(r.id) || (r.requestId && returnRequestIds.has(r.requestId))) {
                report.dupReturns++;
                return;
            }
            _returnHistory.push(r);
            returnIds.add(r.id);
            if (r.requestId) returnRequestIds.add(r.requestId);
            _dirtyReturns.add(r.id);
            addedReturnIds.push(r.id);
            report.addedReturns++;
        });

        // ---- Suggestion lists ----
        report.addedDoctors = _mergeStringList(_doctorsList, extracted.doctors);
        report.addedMakeList = _mergeStringList(_makeList, extracted.makeList);
        report.addedWholesalerList = _mergeStringList(_wholesalerList, extracted.wholesalerList);
        report.addedPatientWords = _mergeStringList(_patientWords, extracted.patientWords);

        // ---- Purchase bills (separate IDB) ----
        if (Array.isArray(extracted.purchaseRaw) && extracted.purchaseRaw.length &&
            typeof PurchaseModule !== 'undefined' && PurchaseModule.saveBill) {
            var existingPurchaseIds = new Set();
            try {
                var existingPurchases = await PurchaseModule.getAllBills();
                (existingPurchases || []).forEach(function (p) {
                    if (p && p.id) existingPurchaseIds.add(p.id);
                });
            } catch (_) {}
            for (var pi = 0; pi < extracted.purchaseRaw.length; pi++) {
                var p = extracted.purchaseRaw[pi];
                if (!p || typeof p !== 'object' || !p.id || typeof p.fileData !== 'string' || !p.fileData) {
                    report.purchaseFailed++;
                    continue;
                }
                if (existingPurchaseIds.has(p.id)) continue;
                try {
                    await PurchaseModule.saveBill({
                        id: String(p.id).slice(0, 100),
                        pharmaName: _sanitizeField(p.pharmaName, 200),
                        fileName: _sanitizeField(p.fileName, 300),
                        fileType: _sanitizeField(p.fileType, 100),
                        fileData: p.fileData,
                        date: _sanitizeField(p.date, 40),
                        addedAt: parseInt(p.addedAt, 10) || Date.now()
                    });
                    existingPurchaseIds.add(p.id);
                    report.purchaseAdded++;
                } catch (e) {
                    report.purchaseFailed++;
                }
            }
        }

        // ---- Counter: kabhi rewind nahi ----
        var maxBillNo = _billsHistory.reduce(function (mx, b) {
            return Math.max(mx, (b && parseInt(b.billNo, 10)) || 0);
        }, 0);
        var newCounter = Math.max(_billCounter, extracted.billCounter, maxBillNo,
            parseInt(Database.Storage.getString(LS_COUNTER, '0'), 10) || 0);
        _billCounter = newCounter;
        Database.Storage.setString(LS_COUNTER, String(_billCounter));

        // ---- Persist merged data ----
        var saveResults = await _persistAll('import');
        var saveOk = saveResults.every(function (r) { return r && r.ok; });
        if (!saveOk) {
            report.warnings.push('Import save ke baad kuch data sirf memory mein hai — turant Offline Backup download karein.');
        }

        var finalBillIds = new Set(_billsHistory.map(function (b) { return b && b.id; }).filter(Boolean));
        var missingAddedBills = addedBillIds.filter(function (id) { return !finalBillIds.has(id); }).length;
        var finalStockIds = new Set(_stockData.map(function (s) { return s && s.id; }).filter(Boolean));
        var missingAddedStock = addedStockIds.filter(function (id) { return !finalStockIds.has(id); }).length;
        report.verified = saveOk && missingAddedBills === 0 && missingAddedStock === 0 &&
            _billsHistory.length >= report.before.bills &&
            _stockData.length >= report.before.stock &&
            _returnHistory.length >= report.before.returns;
        if (!report.verified) {
            report.warnings.push('Import verification warning — console (F12) mein details check karein.');
            console.warn('IMPORT VERIFY WARNING:', {
                saveResults: saveResults,
                missingAddedBills: missingAddedBills,
                missingAddedStock: missingAddedStock,
                before: report.before,
                after: {
                    bills: _billsHistory.length,
                    stock: _stockData.length,
                    returns: _returnHistory.length
                }
            });
        }

        report.totalBills = _billsHistory.length;
        report.totalStock = _stockData.length;
        report.totalReturns = _returnHistory.length;
        report.billCounter = _billCounter;

        _emit('stockChanged', _stockData);
        _emit('historyChanged', _billsHistory);
        _emit('returnsChanged', _returnHistory);
        _emit('doctorsChanged', _doctorsList);

        return report;
    }

    // Purane callers ke liye alias — ab detailed report return hota hai.
    function importData(data) {
        return importAllData(data);
    }

    // Safe restore wrapper: validation + import ko ek hi structured result me
    // wrap karta hai. Koi bhi unexpected error ab thrown nahi hota — UI ko
    // hamesha {ok, fatal, stage} milta hai, taaki "Restore fail" ka asli
    // reason clear dikhe.
    async function restoreBackup(data) {
        try {
            var pre = validateBackup(data);
            if (!pre.ok) {
                return {
                    ok: false,
                    stage: 'validate',
                    fatal: (pre.fatal || []).slice(),
                    warnings: (pre.warnings || []).slice(),
                    counts: pre.counts || null
                };
            }
            var report = await importAllData(data);
            report.stage = 'import';
            report.counts = pre.counts || null;
            return report;
        } catch (e) {
            return {
                ok: false,
                stage: 'exception',
                fatal: ['Restore error: ' + ((e && e.message) || String(e))],
                warnings: [],
                counts: null
            };
        }
    }

    // ==================== CLEAR ALL ====================
    async function clearAllData() {
        if (!_initialized) await init();
        if (_reconciling) { try { await _reconciling; } catch (_) {} }
        await flushSaves().catch(function () {});

        var epoch = Math.max(Date.now(), _clearEpoch + 1);
        _clearEpoch = epoch;
        // Crash-safe clear: request flag pehle likho, taaki agar beech mein
        // app band ho jaye to next init purana IDB data wapas load na kare.
        Database.Storage.setString('rb_clear_requested', String(epoch));
        Database.Storage.setString(LS_CLEAR_EPOCH, String(epoch));

        // localStorage pehle clear — phir IDB/legacy.
        [
            LS_STOCK, LS_HISTORY, LS_RETURNS, LS_COUNTER, LS_TOMBSTONES,
            LS_SYNC_PING, LS_STOCK + '_idb', LS_HISTORY + '_idb', LS_RETURNS + '_idb',
            CONFIG.LS_KEYS.DOCTORS, CONFIG.LS_KEYS.MAKE_LIST,
            CONFIG.LS_KEYS.WHOLESALER_LIST, CONFIG.LS_KEYS.PATIENT_WORDS
        ].forEach(function (key) {
            try { Database.Storage.remove(key); } catch (_) {}
        });

        if (_idbReady) {
            try { await Database.idbClearAll(); } catch (e) { console.error('IDB clear failed:', e.message || e); }
            try { await Database.idbSetKv('clearEpoch', epoch); } catch (_) {}
            try { await Database.idbSetMeta('billCounter', 0); } catch (_) {}
        }
        try { await Database.idbClearLegacy(); } catch (_) {}
        try {
            if (typeof PurchaseModule !== 'undefined' && PurchaseModule.clearAllBills) {
                await PurchaseModule.clearAllBills();
            }
        } catch (e) { console.warn('Purchase bills clear skipped:', e.message || e); }

        _replaceArray(_stockData, []);
        _replaceArray(_billsHistory, []);
        _replaceArray(_returnHistory, []);
        _doctorsList = [];
        _makeList = [];
        _wholesalerList = [];
        _patientWords = [];
        _stockShadow = new Map();
        _stockTombstones = {};
        _deletedStock.clear();
        _dirtyBills.clear();
        _dirtyReturns.clear();
        _dirtyStock.clear();
        _billCounter = 0;
        _lastSaveError = '';
        _lastSaveAt = Date.now();
        Database.Storage.setString(LS_COUNTER, '0');
        _saveMiscLists();
        Database.Storage.remove('rb_clear_requested');

        _broadcastClear(epoch);
        _emit('stockChanged', _stockData);
        _emit('historyChanged', _billsHistory);
        _emit('returnsChanged', _returnHistory);
        _emit('doctorsChanged', _doctorsList);
        try {
            if (typeof Inventory !== 'undefined' && Inventory.renderStockTable) Inventory.renderStockTable();
            if (typeof History !== 'undefined' && History.renderHistoryTable) History.renderHistoryTable();
            if (typeof Notifications !== 'undefined' && Notifications.renderPanel) Notifications.renderPanel();
        } catch (_) {}
        return true;
    }

    // Pending saves ko complete hone do (backup/import se pehle).
    async function flushSaves() {
        for (var i = 0; i < 3; i++) {
            await _saveChain.catch(function () {});
            if (!_hasDirty()) break;
            await Promise.all([
                _saveStock('flush'),
                _saveHistory('flush'),
                _saveReturns('flush')
            ]);
        }
        return {
            ok: !_hasDirty(),
            dirtyBills: _dirtyBills.size,
            dirtyReturns: _dirtyReturns.size,
            dirtyStock: _stockDirtyCount()
        };
    }

    // ==================== PUBLIC API ====================
    return {
        init: init,
        reconcile: reconcile,
        flushSaves: flushSaves,
        validateBackup: validateBackup,
        exportData: exportData,
        exportAllData: exportAllData,
        importData: importData,
        importAllData: importAllData,
        restoreBackup: restoreBackup,
        clearAllData: clearAllData,

        saveStock: saveStock,
        saveHistory: saveHistory,
        getNextBillNumber: getNextBillNumber,
        getBillCounter: getBillCounter,
        addBill: addBill,
        updateBill: updateBill,

        addOrUpdateMedicine: addOrUpdateMedicine,
        deleteMedicine: deleteMedicine,
        findStockByIdOrIndex: findStockByIdOrIndex,

        addDoctor: addDoctor,
        removeDoctor: removeDoctor,
        updateDoctor: updateDoctor,
        addMake: addMake,
        addWholesaler: addWholesaler,
        updateWholesaler: updateWholesaler,
        removeWholesaler: removeWholesaler,
        getWholesalerList: getWholesalerList,
        removePatientWord: removePatientWord,
        updatePatientWord: updatePatientWord,
        savePatientName: savePatientName,

        recordMedicineReturn: recordMedicineReturn,
        recordMedicineReturns: recordMedicineReturns,

        on: on,
        off: off,

        get initialized() { return _initialized; },
        get storageMode() { return _storageMode; },
        get idbReady() { return _idbReady; },
        get stockData() { return _stockData; },
        get billsHistory() { return _billsHistory; },
        get returnHistory() { return _returnHistory; },
        get doctorsList() { return _doctorsList; },
        get makeList() { return _makeList; },
        get wholesalerList() { return _wholesalerList; },
        get patientWords() { return _patientWords; }
    };
})();
