const History = (() => {
    let _pendingCancelBillId = null;
    let _cancelSaving = false;
    let _historyPage = 1;
    let _lastTotalPages = 1;
    const HISTORY_PAGE_SIZE = 100;
    // MULTI-PRINT state — selected bill ids (pages/tabs ke across persist rehti hai)
    let _multiMode = false;
    const _selectedIds = new Set();
    const _debouncedRender = Utils.debounce(() => renderHistoryTable(), 300);

    function _sortBillsNewestFirst(a, b) {
        var cmp = Utils.compareDates(b.date, a.date);
        if (cmp !== 0 && !isNaN(cmp)) return cmp;
        return (b.billNo || 0) - (a.billNo || 0);
    }

    function renderHistoryTable() {
        const tbody = document.getElementById('historyTableBody');
        Utils.clearElement(tbody);

        const allFiltered = _getFilteredBillsData();
        _renderSalesSummary(allFiltered);

        allFiltered.sort(function(a, b) {
            var cmp = Utils.compareDates(b.date, a.date);
            if (!isNaN(cmp) && cmp !== 0) return cmp;
            return (b.billNo || 0) - (a.billNo || 0);
        });

        const totalPages = Math.ceil(allFiltered.length / HISTORY_PAGE_SIZE) || 1;
        _lastTotalPages = totalPages;
        if (_historyPage > totalPages) _historyPage = totalPages;
        const start = (_historyPage - 1) * HISTORY_PAGE_SIZE;
        const pageData = allFiltered.slice(start, start + HISTORY_PAGE_SIZE);
        _updateFloatingNav(totalPages);

        if (!allFiltered.length) {
            tbody.innerHTML = '<tr><td colspan="' + (_multiMode ? 7 : 6) + '" style="text-align:center;color:#9ca3af;padding:30px;">Koi bill nahi mila</td></tr>';
            _refreshMultiUI();
            return;
        }

        pageData.forEach(bill => {
            const tr = document.createElement('tr');
            tr.dataset.billId = bill.id || '';
            tr.innerHTML = [
                (_multiMode ? '<td style="text-align:center;" class="check-cell"><input type="checkbox" data-id="' + Utils.escapeAttr(bill.id) + '"' + (_selectedIds.has(bill.id) ? ' checked' : '') + ' onchange="History.onRowCheck(this)"></td>' : ''),
                '<td class="billno-cell" style="font-weight:700;">' + (bill.billNo || '-') + '</td>',
                '<td>' + Utils.escapeHtml(bill.date) + '</td>',
                '<td><strong>' + Utils.escapeHtml(bill.patient) + '</strong></td>',
                '<td>' + Utils.escapeHtml(bill.doctor) + '</td>',
                '<td style="text-align:right;font-weight:700;color:#1a56db;">₹' + bill.total.toFixed(2) + '</td>',
                '<td style="text-align:center;" class="action-cell"></td>'
            ].join('');
            var actionCell = tr.querySelector('.action-cell');
            var cancelBtn = document.createElement('button');
            cancelBtn.className = 'btn-danger';
            cancelBtn.style.cssText = 'padding:4px 10px;font-size:12px;';
            cancelBtn.textContent = '✕ Cancel';
            cancelBtn.addEventListener('click', function (id) { return function () { History.showCancelModal(id); }; }(bill.id));
            actionCell.appendChild(cancelBtn);
            tbody.appendChild(tr);
        });

        _addReprintButtons();
        _renderHistoryPagination(allFiltered.length, totalPages);
        _refreshMultiUI();
    }

    function _renderHistoryPagination(totalItems, totalPages) {
        const container = document.getElementById('histBillsContent');
        if (!container) return;
        let pagEl = document.getElementById('historyPagination');
        if (!pagEl) {
            pagEl = document.createElement('div');
            pagEl.id = 'historyPagination';
            pagEl.style.cssText = 'display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-top:12px;';
            container.appendChild(pagEl);
        }
        Utils.clearElement(pagEl);

        const info = document.createElement('span');
        info.style.cssText = 'font-size:12px;color:#9ca3af;margin-right:8px;';
        info.textContent = 'Page ' + _historyPage + ' of ' + totalPages + ' (' + totalItems + ' bills)';
        pagEl.appendChild(info);

        const prevBtn = document.createElement('button');
        prevBtn.className = 'btn-secondary';
        prevBtn.style.cssText = 'padding:4px 10px;font-size:12px;';
        prevBtn.textContent = '◀ Prev';
        prevBtn.disabled = _historyPage <= 1;
        prevBtn.addEventListener('click', () => { if (_historyPage > 1) { _historyPage--; renderHistoryTable(); } });
        pagEl.appendChild(prevBtn);

        const pageInput = document.createElement('input');
        pageInput.type = 'number';
        pageInput.value = String(_historyPage);
        pageInput.min = '1';
        pageInput.max = String(totalPages);
        pageInput.style.cssText = 'width:50px;padding:4px 6px;border:1.5px solid #d1d9e0;border-radius:5px;font-size:13px;text-align:center;';
        pageInput.addEventListener('change', () => {
            const p = parseInt(pageInput.value, 10);
            if (p >= 1 && p <= totalPages) { _historyPage = p; renderHistoryTable(); }
            else pageInput.value = String(_historyPage);
        });
        pagEl.appendChild(pageInput);

        const nextBtn = document.createElement('button');
        nextBtn.className = 'btn-secondary';
        nextBtn.style.cssText = 'padding:4px 10px;font-size:12px;';
        nextBtn.textContent = 'Next ▶';
        nextBtn.disabled = _historyPage >= totalPages;
        nextBtn.addEventListener('click', () => { if (_historyPage < totalPages) { _historyPage++; renderHistoryTable(); } });
        pagEl.appendChild(nextBtn);
    }

    // ==================== FLOATING PAGE NAV (middle-left / middle-right) ====================
    // 100-bill page ke beech me hi Prev/Next buttons — neeche scroll karne ki
    // zaroorat nahi. Sirf Bills tab + 1 se zyada pages hone par dikhte hain.
    function _updateFloatingNav(totalPages) {
        const prev = document.getElementById('histNavPrev');
        const next = document.getElementById('histNavNext');
        if (!prev || !next) return;
        const pages = Math.max(1, totalPages || _lastTotalPages || 1);
        const section = document.getElementById('historySection');
        const billsContent = document.getElementById('histBillsContent');
        const sectionVisible = !!(section && section.style.display !== 'none');
        const billsVisible = !!(billsContent && billsContent.style.display !== 'none');
        const show = sectionVisible && billsVisible && pages > 1;
        prev.style.display = show ? 'flex' : 'none';
        next.style.display = show ? 'flex' : 'none';
        prev.disabled = _historyPage <= 1;
        next.disabled = _historyPage >= pages;
        prev.title = 'Pehle ke ' + HISTORY_PAGE_SIZE + ' bills (Page ' + Math.max(1, _historyPage - 1) + ')';
        next.title = 'Agle ' + HISTORY_PAGE_SIZE + ' bills (Page ' + Math.min(pages, _historyPage + 1) + ')';
    }

    function _scrollHistoryTop() {
        const section = document.getElementById('historySection');
        if (section && typeof section.scrollIntoView === 'function') {
            try { section.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; } catch (_) {}
        }
        window.scrollTo(0, 0);
    }

    function prevPage() {
        if (_historyPage <= 1) return;
        _historyPage--;
        renderHistoryTable();
        _scrollHistoryTop();
    }

    function nextPage() {
        if (_historyPage >= _lastTotalPages) return;
        _historyPage++;
        renderHistoryTable();
        _scrollHistoryTop();
    }

    function _renderSalesSummary(filtered) {
        const today = Utils.getTodayStr();
        const weekStart = Utils.getWeekStartStr();
        const monthStart = Utils.getMonthStartStr();

        const todayTotal = filtered.filter(b => b.date === today).reduce((s, b) => s + b.total, 0);
        const weekTotal = filtered.filter(b => b.date && Utils.compareDates(b.date, weekStart) >= 0 && Utils.compareDates(b.date, today) <= 0).reduce((s, b) => s + b.total, 0);
        const monthTotal = filtered.filter(b => b.date && Utils.compareDates(b.date, monthStart) >= 0 && Utils.compareDates(b.date, today) <= 0).reduce((s, b) => s + b.total, 0);
        const grand = filtered.reduce((s, b) => s + b.total, 0);

        document.getElementById('salesSummaryRow').innerHTML = [
            '<div class="summary-box" style="flex:1;min-width:110px;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;">',
            '  <div style="font-size:18px;font-weight:bold;color:#0891b2;">₹' + todayTotal.toFixed(2) + '</div>',
            '  <div style="font-size:10px;color:#888;">Today</div>',
            '</div>',
            '<div class="summary-box" style="flex:1;min-width:110px;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;">',
            '  <div style="font-size:18px;font-weight:bold;color:#7c3aed;">₹' + weekTotal.toFixed(2) + '</div>',
            '  <div style="font-size:10px;color:#888;">This Week</div>',
            '</div>',
            '<div class="summary-box" style="flex:1;min-width:110px;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;">',
            '  <div style="font-size:18px;font-weight:bold;color:#1a56db;">₹' + monthTotal.toFixed(2) + '</div>',
            '  <div style="font-size:10px;color:#888;">This Month</div>',
            '</div>',
            '<div class="summary-box" style="flex:1;min-width:110px;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;">',
            '  <div style="font-size:18px;font-weight:bold;color:#059669;">' + filtered.length + '</div>',
            '  <div style="font-size:10px;color:#888;">Bills</div>',
            '</div>',
            '<div class="summary-box" style="flex:1;min-width:110px;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;">',
            '  <div style="font-size:18px;font-weight:bold;color:#c62828;">₹' + grand.toFixed(2) + '</div>',
            '  <div style="font-size:10px;color:#888;">Grand Total</div>',
            '</div>'
        ].join('');
    }

    function _getFilteredBillsData(includeCancelled) {
        const searchQ = (document.getElementById('historySearchInput').value || '').toLowerCase().trim();
        const dateFrom = document.getElementById('historyDateFrom').value.trim();
        const dateTo = document.getElementById('historyDateTo').value.trim();
        let filtered = [...AppState.billsHistory];
        if (!includeCancelled) filtered = filtered.filter(b => !b.cancelled);
        if (searchQ) {
            filtered = filtered.filter(b =>
                (b.billNo && b.billNo.toString().includes(searchQ)) ||
                (b.patient && b.patient.toLowerCase().includes(searchQ)) ||
                (b.doctor && b.doctor.toLowerCase().includes(searchQ))
            );
        }
        if (dateFrom) filtered = filtered.filter(b => b.date && Utils.compareDates(b.date, dateFrom) >= 0);
        if (dateTo) filtered = filtered.filter(b => b.date && Utils.compareDates(b.date, dateTo) <= 0);
        return filtered;
    }

    function showCancelModal(billId) {
        var bill = AppState.billsHistory.find(function (b) { return b.id === billId; });
        if (!bill) { UI.showToast('Bill nahi mila!', 'error'); return; }
        if (bill.cancelled) { UI.showToast('Yeh bill pehle se cancel hai.', 'warn'); return; }
        _pendingCancelBillId = billId;
        document.getElementById('cancelModal').classList.add('show');
        const radios = document.querySelectorAll('input[name="cancelReason"]');
        if (radios.length) radios[0].checked = true;
        document.getElementById('cancelReasonCustom').value = '';
    }

    function closeCancelModal() {
        _pendingCancelBillId = null;
        document.getElementById('cancelModal').classList.remove('show');
    }

    async function confirmCancelBill() {
        if (_cancelSaving) {
            UI.showToast('⏳ Bill cancel ho raha hai — ek second rukein.', 'warn', 3000);
            return;
        }
        const billId = _pendingCancelBillId;
        if (!billId) return;
        const bill = AppState.billsHistory.find(b => b.id === billId);
        if (!bill) { closeCancelModal(); return; }
        if (bill.cancelled) {
            closeCancelModal();
            UI.showToast('Yeh bill pehle se cancel hai.', 'warn');
            return;
        }

        const reason = document.querySelector('input[name="cancelReason"]:checked')?.value || 'Other';
        const custom = document.getElementById('cancelReasonCustom').value.trim();
        const cancelReason = custom ? reason + ' — ' + custom : reason;

        _cancelSaving = true;
        try {
            // Pehle bill ka cancel-state save karo. Agar yeh fail ho to stock
            // restore bilkul nahi karte — warna stock aur bill mismatch ho jata.
            const cancelRes = await AppState.updateBill(billId, {
                cancelled: true,
                cancelReason: cancelReason,
                cancelledAt: new Date().toLocaleString()
            });
            if (!cancelRes || !cancelRes.ok) {
                UI.showToast('❌ Bill cancel save NAHI hua! Koi stock change nahi hua — dobara try karein.', 'error', 9000);
                return;
            }

            var restoredItems = [];
            var missingItems = [];
            for (var ci = 0; ci < bill.items.length; ci++) {
                var item = bill.items[ci];
                // Manual (free-entry) items inventory ka hissa nahi hain — cancel par
                // inka stock kabhi restore nahi karna, warna same naam wali medicine
                // ka stock galat badh jata hai.
                if (item.manual === true) continue;
                if (item.stockIdx < 0 && !item.stockId) continue;
                var stockItem = AppState.findStockByIdOrIndex(item.stockId, item.stockIdx, item.particulars);
                if (!stockItem) {
                    stockItem = AppState.stockData.find(function(s) { return s.name === item.particulars; });
                }
                if (!stockItem) {
                    missingItems.push(item.particulars);
                    continue;
                }
                var batch = stockItem.batches.find(function (b) { return b.batch === item.batch && b.expiry === item.expiry; });
                if (!batch) {
                    batch = {
                        id: Utils.generateId('batch'),
                        batch: String(item.batch || '').replace(/[<>"']/g, '').slice(0, 100),
                        expiry: String(item.expiry || '').replace(/[<>"']/g, '').slice(0, 20),
                        qty: 0,
                        price: item.qty > 0 ? item.amount / item.qty : 0,
                        stripSize: 0
                    };
                    stockItem.batches.push(batch);
                }
                batch.qty += item.qty;
                restoredItems.push(item.particulars);
            }

            const stockRes = await AppState.saveStock();
            if (!stockRes || !stockRes.ok) {
                UI.showToast('⚠️ Bill cancel ho gaya, lekin stock restore save fail hua. Turant Offline Backup download karein.', 'warn', 10000);
            }
            if (missingItems.length) {
                UI.showToast('⚠ ' + missingItems.length + ' item(s) inventory mein nahi mile, stock restore skip: ' + missingItems.join(', '), 'warn', 5000);
            }

            closeCancelModal();
            renderHistoryTable();
            if (typeof Notifications !== 'undefined') Notifications.renderPanel();
            if (restoredItems.length) {
                UI.showToast('Bill cancel ho gaya! ' + restoredItems.length + ' item(s) ka stock wapas add ho gaya.', 'info');
            } else {
                UI.showToast('Bill cancel ho gaya! (Koi inventory stock restore nahi hua — manual items.)', 'info');
            }
        } catch (e) {
            console.error('BILL CANCEL ERROR:', e);
            UI.showToast('❌ Bill cancel error: ' + (e.message || e) + ' — dobara try karein.', 'error', 9000);
        } finally {
            _cancelSaving = false;
        }
    }

    function _isOtcBill(bill) {
        const doc = (bill.doctor || '').trim().toLowerCase();
        return !doc || doc === 'self' || doc === 'cash customer' || doc === 'dr. self';
    }

    function switchHistTab(tab) {
        document.getElementById('histBillsContent').style.display = tab === 'bills' ? 'block' : 'none';
        document.getElementById('histCancelledContent').style.display = tab === 'cancelled' ? 'block' : 'none';
        document.getElementById('histOtcContent').style.display = tab === 'otc' ? 'block' : 'none';
        document.getElementById('histTabBills').className = tab === 'bills' ? 'btn-primary' : 'btn-secondary';
        document.getElementById('histTabCancelled').className = tab === 'cancelled' ? 'btn-primary' : 'btn-secondary';
        document.getElementById('histTabOtc').className = tab === 'otc' ? 'btn-primary' : 'btn-secondary';
        if (tab === 'bills') renderHistoryTable();
        if (tab === 'cancelled') renderCancelledTable();
        if (tab === 'otc') renderOtcTable();
        _updateFloatingNav(_lastTotalPages);
    }

    function _getFilteredOtcData() {
        let filtered = AppState.billsHistory.filter(b => !b.cancelled && _isOtcBill(b));
        const searchQ = (document.getElementById('historySearchInput').value || '').toLowerCase().trim();
        const dateFrom = document.getElementById('historyDateFrom').value.trim();
        const dateTo = document.getElementById('historyDateTo').value.trim();
        if (searchQ) {
            filtered = filtered.filter(b =>
                (b.billNo && b.billNo.toString().includes(searchQ)) ||
                (b.patient && b.patient.toLowerCase().includes(searchQ)) ||
                (b.doctor && b.doctor.toLowerCase().includes(searchQ))
            );
        }
        if (dateFrom) filtered = filtered.filter(b => b.date && Utils.compareDates(b.date, dateFrom) >= 0);
        if (dateTo) filtered = filtered.filter(b => b.date && Utils.compareDates(b.date, dateTo) <= 0);
        return filtered;
    }

    function renderOtcTable() {
        const tbody = document.getElementById('otcTableBody');
        Utils.clearElement(tbody);
        const filtered = _getFilteredOtcData();
        if (!filtered.length) {
            tbody.innerHTML = '<tr><td colspan="' + (_multiMode ? 7 : 6) + '" style="text-align:center;color:#9ca3af;padding:30px;">Koi OTC bill nahi mila</td></tr>';
            _refreshMultiUI();
            return;
        }
        [...filtered].sort(_sortBillsNewestFirst).forEach(bill => {
            const tr = document.createElement('tr');
            tr.dataset.billId = bill.id || '';
            tr.innerHTML = [
                (_multiMode ? '<td style="text-align:center;" class="check-cell"><input type="checkbox" data-id="' + Utils.escapeAttr(bill.id) + '"' + (_selectedIds.has(bill.id) ? ' checked' : '') + ' onchange="History.onRowCheck(this)"></td>' : ''),
                '<td class="billno-cell" style="font-weight:700;">' + (bill.billNo || '-') + '</td>',
                '<td>' + Utils.escapeHtml(bill.date) + '</td>',
                '<td><strong>' + Utils.escapeHtml(bill.patient) + '</strong></td>',
                '<td>' + Utils.escapeHtml(bill.doctor) + '</td>',
                '<td style="text-align:right;font-weight:700;color:#1a56db;">₹' + bill.total.toFixed(2) + '</td>',
                '<td style="text-align:center;" class="action-cell"></td>'
            ].join('');
            var actionCell = tr.querySelector('.action-cell');
            var cancelBtn = document.createElement('button');
            cancelBtn.className = 'btn-danger';
            cancelBtn.style.cssText = 'padding:4px 10px;font-size:12px;';
            cancelBtn.textContent = '✕ Cancel';
            cancelBtn.addEventListener('click', function (id) { return function () { History.showCancelModal(id); }; }(bill.id));
            actionCell.appendChild(cancelBtn);
            tbody.appendChild(tr);
        });
        _addReprintButtons();
        _refreshMultiUI();
    }

    function renderCancelledTable() {
        const tbody = document.getElementById('cancelledTableBody');
        Utils.clearElement(tbody);
        const cancelled = AppState.billsHistory.filter(b => b.cancelled);
        if (!cancelled.length) {
            tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#9ca3af;padding:30px;">Koi cancelled bill nahi hai</td></tr>';
            return;
        }
        [...cancelled].sort(_sortBillsNewestFirst).forEach(bill => {
            const tr = document.createElement('tr');
            tr.dataset.billId = bill.id || '';
            tr.innerHTML = [
                '<td class="billno-cell" style="font-weight:700;">' + (bill.billNo || '-') + '</td>',
                '<td>' + Utils.escapeHtml(bill.date) + '</td>',
                '<td><strong>' + Utils.escapeHtml(bill.patient) + '</strong></td>',
                '<td>' + Utils.escapeHtml(bill.doctor) + '</td>',
                '<td style="text-align:right;font-weight:700;color:#dc2626;">₹' + bill.total.toFixed(2) + '</td>',
                '<td><span style="background:#fee2e2;color:#991b1b;font-size:11px;font-weight:700;padding:2px 8px;border-radius:6px;">' + Utils.escapeHtml(bill.cancelReason || 'N/A') + '</span></td>',
                '<td style="text-align:center;" class="action-cell"></td>'
            ].join('');
            var actionCell = tr.querySelector('.action-cell');
            tbody.appendChild(tr);
        });
        _addReprintButtons();
    }

    function _addReprintButtons() {
        const rows = document.querySelectorAll('#historyTableBody tr, #cancelledTableBody tr, #otcTableBody tr');
        rows.forEach(function (tr) {
            const billNoCell = tr.querySelector('.billno-cell');
            if (!billNoCell) return;
            const billNo = parseInt((billNoCell.textContent || '').trim(), 10);
            if (isNaN(billNo)) return;
            // Pehle bill id se dhoondo (same billNo duplicate ho sakta hai),
            // phir purane records ke liye billNo fallback.
            let oldBill = tr.dataset.billId ? AppState.billsHistory.find(function (b) { return b.id === tr.dataset.billId; }) : null;
            if (!oldBill) oldBill = _findOldBill(billNo);
            if (!oldBill) return;
            let actionCell = tr.querySelector('.action-cell');
            if (!actionCell) return;

            // NEW: Preview button — shows bill without creating duplicate or printing
            const previewBtn = document.createElement('button');
            previewBtn.className = 'btn-secondary';
            previewBtn.style.cssText = 'padding:4px 10px;font-size:12px;margin-right:6px;background:#059669;';
            previewBtn.textContent = '👁 Preview';
            previewBtn.addEventListener('click', function () { previewOldBill(oldBill); });
            actionCell.appendChild(previewBtn);

            // Existing Print — keep exactly as is (RAW ESC/P LX-310)
            const printBtn = document.createElement('button');
            printBtn.className = 'btn-primary';
            printBtn.style.cssText = 'padding:4px 10px;font-size:12px;margin-right:6px;';
            printBtn.textContent = '🖨️ Print';
            printBtn.addEventListener('click', function () { reprintOldBillRaw(oldBill); });
            actionCell.appendChild(printBtn);

            // Existing Reprint — keep exactly as is (RAW ESC/P LX-310)
            const reprintBtn = document.createElement('button');
            reprintBtn.className = 'btn-secondary';
            reprintBtn.style.cssText = 'padding:4px 10px;font-size:12px;';
            reprintBtn.textContent = '↻ Reprint';
            reprintBtn.addEventListener('click', function () { reprintOldBillRaw(oldBill); });
            actionCell.appendChild(reprintBtn);
        });
    }

    function previewOldBill(bill) {
        if (!bill) { UI.showToast('Bill nahi mila!', 'error'); return; }
        // Reuse same bill template/layout as print — NO duplicate, NO auto print, NO data modify
        if (typeof Billing !== 'undefined' && Billing.showBillPreview) {
            Billing.showBillPreview(bill);
        } else {
            UI.showToast('Preview available nahi hai!', 'error');
        }
    }

    function _findOldBill(billNo) {
        return AppState.billsHistory.find(function (b) { return b.billNo === billNo; });
    }

    function reprintOldBill(bill) {
        if (!bill) { UI.showToast('Bill nahi mila!', 'error'); return; }
        // Single mode — direct RAW ESC/P LX-310 reprint (prompt removed)
        reprintOldBillRaw(bill);
    }

    function reprintOldBillNotepad(bill) {
        const text = Utils.buildBillTextCompact(bill);
        Database.printTextToNotepad(text).then(function () {
            UI.showToast('Notepad reprint file taiyaar!', 'info');
        });
    }

    function reprintOldBillRaw(bill) {
        const bytes = Utils.buildBillEscP(bill);
        Database.printRawEscP(bytes).then(function (ok) {
            if (ok) UI.showToast('Raw ESC/P reprint bhej diya!', 'success');
            else UI.showToast('Raw reprint fail — check printer / server.', 'error');
        });
    }

    function downloadOldBillText(bill) {
        const text = Utils.buildBillText(bill);
        const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'Bill_' + (bill.billNo || '0') + '.txt';
        a.click();
        setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    }

    // ==================== MULTI-PRINT (bulk bills, ek hi print job) ====================
    // Har bill ke bytes khud self-contained hain (ESC @ se start, CR FF se end),
    // isliye sabko ek buffer me jodne par har bill apne form par print hota hai —
    // overlap impossible. Bill-No ascending order me (purana bill pehle).

    function _visibleMultiTbody() {
        const billsVisible = document.getElementById('histBillsContent').style.display !== 'none';
        return document.getElementById(billsVisible ? 'historyTableBody' : 'otcTableBody');
    }

    function toggleMultiMode() {
        _multiMode = !_multiMode;
        if (!_multiMode) _selectedIds.clear();
        const bar = document.getElementById('multiPrintBar');
        if (bar) bar.style.display = _multiMode ? 'flex' : 'none';
        const hc = document.getElementById('histCheckHead');
        if (hc) hc.style.display = _multiMode ? '' : 'none';
        const oc = document.getElementById('otcCheckHead');
        if (oc) oc.style.display = _multiMode ? '' : 'none';
        const btn = document.getElementById('histMultiBtn');
        if (btn) btn.className = _multiMode ? 'btn-primary' : 'btn-secondary';
        renderHistoryTable();
        renderOtcTable();
        if (_multiMode) UI.showToast('Tick-box se bills select karo, phir Print Selected dabao.', 'info');
    }

    function onRowCheck(cb) {
        const id = cb.getAttribute('data-id');
        if (!id) return;
        if (cb.checked) _selectedIds.add(id);
        else _selectedIds.delete(id);
        _refreshMultiUI();
    }

    function togglePageSelection(checked) {
        const tbody = _visibleMultiTbody();
        if (!tbody) return;
        tbody.querySelectorAll('input[data-id]').forEach(function (cb) {
            const id = cb.getAttribute('data-id');
            cb.checked = !!checked;
            if (checked) _selectedIds.add(id);
            else _selectedIds.delete(id);
        });
        _refreshMultiUI();
    }

    function selectAllFiltered() {
        const billsVisible = document.getElementById('histBillsContent').style.display !== 'none';
        const list = billsVisible ? _getFilteredBillsData() : _getFilteredOtcData();
        list.forEach(function (b) { _selectedIds.add(b.id); });
        renderHistoryTable();
        renderOtcTable();
        UI.showToast(list.length + ' bills select ho gaye!', 'success');
    }

    function clearSelection() {
        _selectedIds.clear();
        renderHistoryTable();
        renderOtcTable();
    }

    function _refreshMultiUI() {
        const countEl = document.getElementById('multiCount');
        if (countEl) countEl.textContent = _selectedIds.size + ' selected';
        // header checkbox: page ki sabhi rows ticked hain to checked dikhao
        [['historyTableBody', 'histCheckAll'], ['otcTableBody', 'otcCheckAll']].forEach(function (pair) {
            const tbody = document.getElementById(pair[0]);
            const head = document.getElementById(pair[1]);
            if (!tbody || !head) return;
            const boxes = tbody.querySelectorAll('input[data-id]');
            head.checked = boxes.length > 0 && Array.prototype.every.call(boxes, function (cb) { return cb.checked; });
        });
    }

    async function printSelectedBills() {
        const bills = AppState.billsHistory.filter(function (b) { return _selectedIds.has(b.id) && !b.cancelled; });
        if (!bills.length) { UI.showToast('Pehle koi bill tick karo!', 'error'); return; }
        bills.sort(function (a, b) { return (a.billNo || 0) - (b.billNo || 0); });
        if (bills.length > 100 && !confirm(bills.length + ' bills ek saath print honge. Continue?')) return;
        const btn = document.getElementById('multiPrintBtn');
        if (btn) { btn.disabled = true; btn.textContent = '⏳ Printing...'; }
        UI.showToast(bills.length + ' bills printer ko bheje ja rahe hain...', 'info');
        try {
            const parts = bills.map(function (b) { return Utils.buildBillEscP(b); });
            let total = 0;
            parts.forEach(function (p) { total += p.length; });
            const all = new Uint8Array(total);
            let off = 0;
            parts.forEach(function (p) { all.set(p, off); off += p.length; });
            const ok = await Database.printRawEscP(all);
            if (ok) UI.showToast('✅ ' + bills.length + ' bills print queue me bhej diye! (har bill apne page par)', 'success', 4000);
            else UI.showToast('Print fail — check printer / server.', 'error');
        } catch (e) {
            UI.showToast('Print error: ' + (e.message || e), 'error');
        }
        if (btn) { btn.disabled = false; btn.textContent = '🖨️ Print Selected'; }
    }

    function renderH1Register() { renderRegister('h1'); }

    function _getFilteredH1Data() {
        const searchQ = (document.getElementById('h1SearchInput').value || '').toLowerCase().trim();
        const dateFrom = document.getElementById('h1DateFrom').value.trim();
        const dateTo = document.getElementById('h1DateTo').value.trim();
        const results = [];
        AppState.billsHistory.forEach(bill => {
            if (bill.cancelled) return;
            if (dateFrom && Utils.compareDates(bill.date, dateFrom) < 0) return;
            if (dateTo && Utils.compareDates(bill.date, dateTo) > 0) return;
            (bill.items || []).forEach(item => {
                if (!item.h1) return;
                if (searchQ && !item.particulars.toLowerCase().includes(searchQ) && !bill.patient.toLowerCase().includes(searchQ) && !bill.doctor.toLowerCase().includes(searchQ)) return;
                results.push({ date: bill.date, time: bill.time || '', billNo: bill.billNo, patient: bill.patient, doctor: bill.doctor, medicine: item.particulars, batch: item.batch, qty: item.qty });
            });
        });
        results.sort(function(a, b) {
            var c = Utils.compareDates(b.date, a.date);
            if (c !== 0 && !isNaN(c)) return c;
            return b.time.localeCompare(a.time);
        });
        return results;
    }

    function _getFilteredRegisterData(type) {
        const sfx = type === 'narcotic' ? 'ndps' : type;
        const searchQ = (document.getElementById(sfx + 'SearchInput').value || '').toLowerCase().trim();
        const dateFrom = document.getElementById(sfx + 'DateFrom').value.trim();
        const dateTo = document.getElementById(sfx + 'DateTo').value.trim();
        const flagMap = { h: 'h', h1: 'h1', h2: 'h2', narcotic: 'narcotic' };
        const flag = flagMap[type] || type;
        const results = [];
        AppState.billsHistory.forEach(bill => {
            if (bill.cancelled) return;
            if (dateFrom && Utils.compareDates(bill.date, dateFrom) < 0) return;
            if (dateTo && Utils.compareDates(bill.date, dateTo) > 0) return;
            (bill.items || []).forEach(item => {
                if (!item[flag]) return;
                if (searchQ && !item.particulars.toLowerCase().includes(searchQ) && !bill.patient.toLowerCase().includes(searchQ) && !bill.doctor.toLowerCase().includes(searchQ)) return;
                results.push({ date: bill.date, time: bill.time || '', billNo: bill.billNo, patient: bill.patient, doctor: bill.doctor, medicine: item.particulars, batch: item.batch, qty: item.qty });
            });
        });
        results.sort(function(a, b) {
            var c = Utils.compareDates(b.date, a.date);
            if (!isNaN(c) && c !== 0) return c;
            return b.time.localeCompare(a.time);
        });
        return results;
    }

    function renderRegister(type) {
        const sfx = type === 'narcotic' ? 'ndps' : type;
        const tbody = document.getElementById(sfx + 'RegisterBody');
        Utils.clearElement(tbody);
        const rows = _getFilteredRegisterData(type);
        const labels = { h: 'Schedule H', h1: 'Schedule H1', h2: 'Schedule H2', narcotic: 'Narcotics/NDPS' };
        if (!rows.length) {
            tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#9ca3af;padding:30px;">Koi ' + labels[type] + ' sale nahi mili</td></tr>';
            return;
        }
        rows.forEach(r => {
            const tr = document.createElement('tr');
            tr.innerHTML = [
                '<td>' + Utils.escapeHtml(r.date) + '</td>',
                '<td>' + (r.billNo || '-') + '</td>',
                '<td>' + Utils.escapeHtml(r.patient) + '</td>',
                '<td>' + Utils.escapeHtml(r.doctor) + '</td>',
                '<td>' + Utils.escapeHtml(r.medicine) + '</td>',
                '<td>' + Utils.escapeHtml(r.batch) + '</td>',
                '<td style="text-align:right;">' + r.qty + '</td>'
            ].join('');
            tbody.appendChild(tr);
        });
    }

    function renderHRegister() { renderRegister('h'); }
    function renderH2Register() { renderRegister('h2'); }
    function renderNDPSRegister() { renderRegister('narcotic'); }

    function resetHistoryFilter() {
        _historyPage = 1;
        const searchInput = document.getElementById('historySearchInput');
        if (searchInput) searchInput.value = '';
        const dateFrom = document.getElementById('historyDateFrom');
        if (dateFrom) dateFrom.value = '';
        const dateTo = document.getElementById('historyDateTo');
        if (dateTo) dateTo.value = '';
    }

    return {
        renderHistoryTable,
        renderCancelledTable,
        renderOtcTable,
        renderH1Register,
        renderHRegister,
        renderH2Register,
        renderNDPSRegister,
        showCancelModal,
        closeCancelModal,
        confirmCancelBill,
        switchHistTab,
        getFilteredBillsData: _getFilteredBillsData,
        getFilteredH1Data: _getFilteredH1Data,
        getFilteredRegisterData: _getFilteredRegisterData,
        _debouncedRender,
        resetHistoryFilter,
        prevPage,
        nextPage,
        previewOldBill,
        toggleMultiMode,
        onRowCheck,
        togglePageSelection,
        selectAllFiltered,
        clearSelection,
        printSelectedBills
    };
})();
