const PurchaseModule = (() => {
    const STORE_NAME = 'purchase_files';
    let _db = null;

    function _openDB() {
        return new Promise((resolve, reject) => {
            if (_db) return resolve(_db);
            const req = indexedDB.open('rb_purchase_db', 1);
            req.onupgradeneeded = (e) => {
                var db = e.target.result;
                // Guard: object store pehle se ho to create dobara mat karo.
                if (!db.objectStoreNames.contains(STORE_NAME)) {
                    db.createObjectStore(STORE_NAME, { keyPath: 'id' });
                }
            };
            req.onsuccess = (e) => {
                _db = e.target.result;
                resolve(_db);
            };
            req.onerror = (e) => reject(e.target.error);
        });
    }

    // FileReader data URL -> Blob URL. Pehle `iframe src` mein raw data URL
    // HTML ke andar daala jata tha; ab browser blob use karta hai (safe + fast).
    function _dataUrlToBlobUrl(dataUrl) {
        if (!dataUrl || typeof dataUrl !== 'string') return null;
        var m = /^data:([^;,]*)(;base64)?,([\s\S]*)$/.exec(dataUrl);
        if (!m) return null;
        try {
            var mime = m[1] || 'application/octet-stream';
            var blob;
            if (m[2]) {
                var bin = atob(m[3]);
                var arr = new Uint8Array(bin.length);
                for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
                blob = new Blob([arr], { type: mime });
            } else {
                blob = new Blob([decodeURIComponent(m[3])], { type: mime });
            }
            return URL.createObjectURL(blob);
        } catch (e) {
            console.error('Data URL -> Blob failed:', e);
            return null;
        }
    }

    async function _getAll() {
        const db = await _openDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readonly');
            const req = tx.objectStore(STORE_NAME).getAll();
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
        });
    }

    async function _get(id) {
        const db = await _openDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readonly');
            const req = tx.objectStore(STORE_NAME).get(id);
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
        });
    }

    async function _save(record) {
        const db = await _openDB();
        return new Promise((resolve, reject) => {
            let tx;
            try { tx = db.transaction(STORE_NAME, 'readwrite'); } catch (e) { reject(e); return; }
            try { tx.objectStore(STORE_NAME).put(record); } catch (e) { try { tx.abort(); } catch (_) {} reject(e); return; }
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error || new Error('Purchase bill save failed'));
            tx.onabort = () => reject(tx.error || new Error('Purchase bill save aborted'));
        });
    }

    function init() {}

    async function renderTable() {
        const tbody = document.getElementById('purchaseTableBody');
        if (!tbody) return;
        Utils.clearElement(tbody);

        let data;
        try {
            data = await _getAll();
        } catch (err) {
            console.error(err);
            return;
        }

        if (!data || !data.length) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#9ca3af;padding:30px;">Koi purchase bill nahi hai</td></tr>';
            return;
        }

        data.sort((a, b) => b.addedAt - a.addedAt);

        data.forEach(rec => {
            const tr = document.createElement('tr');
            const tdName = document.createElement('td');
            tdName.innerHTML = '<strong>' + Utils.escapeHtml(rec.pharmaName) + '</strong>';
            tr.appendChild(tdName);

            const tdDate = document.createElement('td');
            tdDate.textContent = rec.date;
            tr.appendChild(tdDate);

            const tdFile = document.createElement('td');
            var ext = rec.fileType ? String(rec.fileType) : '';
            if (!ext && rec.fileName && rec.fileName.indexOf('.') >= 0) ext = rec.fileName.split('.').pop();
            ext = ext.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8) || 'FILE';
            tdFile.innerHTML = Utils.escapeHtml(rec.fileName) + ' <span style="font-size:10px;background:#e0e7ff;color:#3730a3;padding:1px 6px;border-radius:6px;font-weight:700;">' + Utils.escapeHtml(ext) + '</span>';
            tr.appendChild(tdFile);

            const tdAction = document.createElement('td');
            tdAction.style.cssText = 'text-align:center;white-space:nowrap;';
            const openBtn = document.createElement('button');
            openBtn.className = 'btn-primary';
            openBtn.style.cssText = 'padding:5px 14px;font-size:12px;margin-right:10px;';
            openBtn.textContent = '👁 Open';
            openBtn.addEventListener('click', () => openBill(rec.id));
            tdAction.appendChild(openBtn);

            const dlBtn = document.createElement('button');
            dlBtn.className = 'btn-secondary';
            dlBtn.style.cssText = 'padding:5px 14px;font-size:12px;';
            dlBtn.textContent = '📥 Download';
            dlBtn.addEventListener('click', () => downloadBill(rec.id));
            tdAction.appendChild(dlBtn);

            tr.appendChild(tdAction);
            tbody.appendChild(tr);
        });
    }

    async function openBill(id) {
        try {
            const rec = await _get(id);
            if (!rec) return;
            const url = _dataUrlToBlobUrl(rec.fileData);
            if (!url) { UI.showToast('File data kharab hai, open nahi ho sakti.', 'error'); return; }
            const win = window.open(url, '_blank');
            if (!win) { UI.showToast('Popup blocker! Allow karo.', 'error'); URL.revokeObjectURL(url); return; }
            setTimeout(function () { try { URL.revokeObjectURL(url); } catch (e) {} }, 60000);
        } catch (err) {
            console.error('openBill error:', err);
            UI.showToast('Error opening file!', 'error');
        }
    }

    async function downloadBill(id) {
        try {
            const rec = await _get(id);
            if (!rec) return;
            const url = _dataUrlToBlobUrl(rec.fileData);
            if (!url) { UI.showToast('File data kharab hai, download nahi ho sakti.', 'error'); return; }
            const a = document.createElement('a');
            a.href = url;
            a.download = rec.fileName || ('purchase_bill_' + Date.now());
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(function () { try { URL.revokeObjectURL(url); } catch (e) {} }, 5000);
            UI.showToast('Download ho raha hai!', 'info');
        } catch (err) {
            console.error('downloadBill error:', err);
            UI.showToast('Error downloading!', 'error');
        }
    }

    async function _clearAll() {
        const db = await _openDB();
        return new Promise(function (resolve, reject) {
            let tx;
            try { tx = db.transaction(STORE_NAME, 'readwrite'); } catch (e) { reject(e); return; }
            tx.objectStore(STORE_NAME).clear();
            tx.oncomplete = function () { resolve(); };
            tx.onerror = function () { reject(tx.error || new Error('Purchase bills clear failed')); };
            tx.onabort = function () { reject(tx.error || new Error('Purchase bills clear aborted')); };
        });
    }

    return {
        init,
        renderTable,
        openBill,
        downloadBill,
        getAllBills: _getAll,
        saveBill: _save,
        clearAllBills: _clearAll
    };
})();
