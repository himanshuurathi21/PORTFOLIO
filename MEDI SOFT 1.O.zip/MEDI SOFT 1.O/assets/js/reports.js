const Reports = (() => {

    function _getSaleReportData() {
        const monthStr = document.getElementById('reportMonth').value.trim();
        const sales = {};
        const bills = monthStr
            ? AppState.billsHistory.filter(b => !b.cancelled && b.date && b.date.split('/').slice(1).join('/') === monthStr)
            : AppState.billsHistory.filter(b => !b.cancelled);

        bills.forEach(bill => {
            bill.items.forEach(item => {
                const key = item.particulars.toLowerCase();
                if (!sales[key]) sales[key] = { name: item.particulars, qty: 0, amount: 0, count: 0 };
                sales[key].qty += item.qty;
                sales[key].amount += item.amount;
                sales[key].count++;
            });
        });

        const sorted = Object.values(sales).sort((a, b) => b.amount - a.amount);
        const totalQty = sorted.reduce((s, m) => s + m.qty, 0);
        const totalAmount = sorted.reduce((s, m) => s + m.amount, 0);
        return { data: sorted, totalQty, totalAmount, billCount: bills.length, monthStr };
    }

    function renderSaleReport() {
        const { data, totalQty, totalAmount, billCount, monthStr } = _getSaleReportData();
        const tbody = document.getElementById('saleReportBody');
        Utils.clearElement(tbody);
        const summaryDiv = document.getElementById('saleReportSummary');

        if (!data.length) {
            tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#9ca3af;padding:30px;">Koi sale data nahi mila</td></tr>';
            summaryDiv.innerHTML = '';
            document.getElementById('saleReportFooter').textContent = '';
            return;
        }

        summaryDiv.innerHTML = [
            '<div class="summary-box" style="flex:1;min-width:110px;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;">',
            '  <div style="font-size:18px;font-weight:bold;color:#1a56db;">' + data.length + '</div>',
            '  <div style="font-size:10px;color:#888;">Medicines Sold</div>',
            '</div>',
            '<div class="summary-box" style="flex:1;min-width:110px;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;">',
            '  <div style="font-size:18px;font-weight:bold;color:#059669;">' + totalQty + '</div>',
            '  <div style="font-size:10px;color:#888;">Total Units</div>',
            '</div>',
            '<div class="summary-box" style="flex:1;min-width:110px;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;">',
            '  <div style="font-size:18px;font-weight:bold;color:#7c3aed;">₹' + totalAmount.toFixed(2) + '</div>',
            '  <div style="font-size:10px;color:#888;">Total Revenue</div>',
            '</div>',
            '<div class="summary-box" style="flex:1;min-width:110px;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;">',
            '  <div style="font-size:18px;font-weight:bold;color:#0891b2;">' + billCount + '</div>',
            '  <div style="font-size:10px;color:#888;">Bills</div>',
            '</div>'
        ].join('');

        let sr = 1;
        data.forEach(m => {
            const tr = document.createElement('tr');
            tr.innerHTML = [
                '<td>' + (sr++) + '</td>',
                '<td><strong>' + Utils.escapeHtml(m.name) + '</strong></td>',
                '<td style="text-align:right;">' + m.count + 'x</td>',
                '<td style="text-align:right;font-weight:700;">' + m.qty + '</td>',
                '<td style="text-align:right;font-weight:700;color:#1a56db;">₹' + m.amount.toFixed(2) + '</td>'
            ].join('');
            tbody.appendChild(tr);
        });
        document.getElementById('saleReportFooter').textContent = monthStr ? 'Report for ' + monthStr : 'All-time report (no month filter)';
    }

    function _openPrintWindow(html) {
        const printWindow = window.open('', '_blank');
        if (!printWindow) {
            UI.showToast('Popup blocker! Allow popups for PDF.', 'error');
            return;
        }
        printWindow.document.write(html);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => { try { printWindow.print(); } catch (e) { UI.showToast('Print error!', 'error'); } }, 500);
    }

    function _downloadCSV(csv, filename, label) {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
        a.download = filename;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
        UI.showToast(label + ' download ho raha hai!', 'info');
    }

    function _downloadExcel(htmlTable, filename, label) {
        const fullHtml = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' + label + '</title></head><body>' + htmlTable + '</body></html>';
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([fullHtml], { type: 'application/vnd.ms-excel;charset=utf-8' }));
        a.download = filename;
        a.click();
        URL.revokeObjectURL(a.href);
        UI.showToast(label + ' download ho raha hai!', 'info');
    }

    function _buildCommonStyles() {
        return 'body{font-family:Arial,sans-serif;padding:20px;color:#222;font-size:13px;}' +
            'table{width:100%;border-collapse:collapse;}' +
            'th{background:#1a237e;color:white;padding:8px 10px;text-align:left;font-size:11px;text-transform:uppercase;}' +
            'td{border:1px solid #e0e0e0;padding:7px 10px;}' +
            'tr:nth-child(even) td{background:#f5f5f5;}' +
            '.footer{margin-top:18px;text-align:right;font-size:10px;color:#aaa;border-top:1px solid #eee;padding-top:8px;}';
    }

    function _buildStoreHeader() {
        const info = CONFIG.STORE_INFO;
        return '<div class="header" style="text-align:center;border-bottom:2px solid #1a237e;padding-bottom:10px;margin-bottom:16px;">' +
            '<h1 style="margin:0;font-size:17px;color:#1a237e;">' + Utils.escapeHtml(info.name) + '</h1>' +
            '<p style="margin:3px 0;font-size:11px;color:#555;">' + Utils.escapeHtml(info.address) + ' | Mob: ' + info.mob + '</p>' +
            '</div>';
    }

    function exportBillsCSV() {
        const filtered = History.getFilteredBillsData();
        if (!filtered.length) { UI.showToast('Koi bill nahi mila filter ke hisaab se!', 'warn'); return; }
        let csv = '\uFEFFInvoice No,Date,Patient,Doctor,Total\n';
        filtered.forEach(b => {
            csv += [
                Utils.escapeCSV(b.billNo || ''),
                Utils.escapeCSV(b.date),
                Utils.escapeCSV(b.patient),
                Utils.escapeCSV(b.doctor),
                Utils.escapeCSV((Number(b.total) || 0).toFixed(2))
            ].join(',') + '\n';
        });
        _downloadCSV(csv, 'ramdevbaba_bills.csv', 'CSV');
    }

    function exportBillsExcel() {
        const filtered = History.getFilteredBillsData();
        if (!filtered.length) { UI.showToast('Koi bill nahi mila filter ke hisaab se!', 'warn'); return; }
        let rows = '';
        filtered.forEach(b => {
            rows += '<tr><td>' + (b.billNo || '-') + '</td><td>' + Utils.escapeHtml(b.date) + '</td><td>' + Utils.escapeHtml(b.patient) + '</td><td>' + Utils.escapeHtml(b.doctor) + '</td><td style="text-align:right;">₹' + b.total.toFixed(2) + '</td></tr>';
        });
        const grand = filtered.reduce((s, b) => s + b.total, 0);
        const table = '<table border="1" cellpadding="5" cellspacing="0" style="font-family:Arial;font-size:12px;border-collapse:collapse;width:100%;">' +
            '<tr style="background:#1a237e;color:white;font-weight:bold;"><th>Invoice No</th><th>Date</th><th>Patient</th><th>Doctor</th><th>Total</th></tr>' +
            rows +
            '<tr style="font-weight:bold;background:#f0f0f0;"><td colspan="4" style="text-align:right;">Grand Total</td><td style="text-align:right;">₹' + grand.toFixed(2) + '</td></tr>' +
            '</table>';
        _downloadExcel(table, 'ramdevbaba_bills.xls', 'Excel');
    }

    function exportBillsPDF() {
        const filtered = History.getFilteredBillsData();
        if (!filtered.length) { UI.showToast('Koi bill nahi mila filter ke hisaab se!', 'warn'); return; }
        let rows = '';
        let grand = 0;
        filtered.forEach(b => {
            rows += '<tr><td>' + (b.billNo || '-') + '</td><td>' + Utils.escapeHtml(b.date) + '</td><td>' + Utils.escapeHtml(b.patient) + '</td><td>' + Utils.escapeHtml(b.doctor) + '</td><td style="text-align:right;">₹' + b.total.toFixed(2) + '</td></tr>';
            grand += b.total;
        });
        const ds = Utils.getTodayStr();
        const html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>' +
            _buildCommonStyles() +
            '.report-title{text-align:center;font-size:14px;font-weight:bold;margin:10px 0 2px 0;}' +
            '.total-row{font-weight:bold;font-size:15px;text-align:right;margin-top:12px;}' +
            '</style></head><body>' +
            _buildStoreHeader() +
            '<div class="report-title">BILLS HISTORY REPORT</div>' +
            '<p style="text-align:center;font-size:11px;color:#777;">Total Bills: ' + filtered.length + ' | Generated: ' + ds + '</p>' +
            '<table><thead><tr><th>Invoice No</th><th>Date</th><th>Patient</th><th>Doctor</th><th style="text-align:right;">Amount</th></tr></thead><tbody>' + rows + '</tbody></table>' +
            '<div class="total-row">Grand Total: ₹' + grand.toFixed(2) + '</div>' +
            '<div class="footer">Report by Ramdevbaba Medical Store | ' + ds + '</div>' +
            '</body></html>';
        _openPrintWindow(html);
    }

    function exportH1PDF() {
        const data = History.getFilteredH1Data();
        if (!data.length) { UI.showToast('Koi H1 data nahi hai PDF ke liye!', 'warn'); return; }
        let rows = '';
        let sr = 1;
        data.forEach(r => {
            rows += '<tr><td>' + (sr++) + '</td><td>' + Utils.escapeHtml(r.date) + '</td><td>' + (r.billNo || '-') + '</td><td>' + Utils.escapeHtml(r.patient) + '</td><td>' + Utils.escapeHtml(r.doctor) + '</td><td>' + Utils.escapeHtml(r.medicine) + '</td><td>' + Utils.escapeHtml(r.batch) + '</td><td style="text-align:right;">' + r.qty + '</td></tr>';
        });
        const ds = Utils.getTodayStr();
        const html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>' +
            'body{font-family:Arial,sans-serif;padding:20px;color:#222;font-size:13px;}' +
            '.header{text-align:center;border-bottom:2px solid #92400e;padding-bottom:10px;margin-bottom:16px;}' +
            '.header h1{margin:0;font-size:17px;color:#92400e;}' +
            '.header p{margin:3px 0;font-size:11px;color:#555;}' +
            '.report-title{text-align:center;font-size:14px;font-weight:bold;margin:10px 0 2px 0;}' +
            'table{width:100%;border-collapse:collapse;}' +
            'th{background:#92400e;color:white;padding:8px 10px;text-align:left;font-size:11px;}' +
            'td{border:1px solid #e0e0e0;padding:7px 10px;}' +
            'tr:nth-child(even) td{background:#f5f5f5;}' +
            '.footer{margin-top:18px;text-align:right;font-size:10px;color:#aaa;border-top:1px solid #eee;padding-top:8px;}' +
            '</style></head><body>' +
            _buildStoreHeader() +
            '<div class="report-title">SCHEDULE H1 REGISTER</div>' +
            '<p style="text-align:center;font-size:11px;color:#777;">Total Entries: ' + (sr - 1) + ' | Generated: ' + ds + '</p>' +
            '<table><thead><tr><th>#</th><th>Date</th><th>Invoice No</th><th>Patient Name</th><th>Prescribed By</th><th>Medicine</th><th>Batch</th><th style="text-align:right;">Qty</th></tr></thead><tbody>' + rows + '</tbody></table>' +
            '<div class="footer">Report by Ramdevbaba Medical Store | ' + ds + '</div>' +
            '</body></html>';
        _openPrintWindow(html);
    }

    function exportH1CSV() {
        const data = History.getFilteredH1Data();
        if (!data.length) { UI.showToast('Koi H1 data nahi mila export karne ke liye!', 'warn'); return; }
        let csv = '\uFEFFDate,Invoice No,Patient Name,Prescribed By,Medicine,Batch,Qty\n';
        data.forEach(r => {
            csv += [
                Utils.escapeCSV(r.date),
                Utils.escapeCSV(r.billNo || ''),
                Utils.escapeCSV(r.patient),
                Utils.escapeCSV(r.doctor),
                Utils.escapeCSV(r.medicine),
                Utils.escapeCSV(r.batch),
                Utils.escapeCSV(r.qty)
            ].join(',') + '\n';
        });
        _downloadCSV(csv, 'ramdevbaba_h1_register.csv', 'H1 CSV');
    }

    function exportH1Excel() {
        const data = History.getFilteredH1Data();
        if (!data.length) { UI.showToast('Koi H1 data nahi mila export karne ke liye!', 'warn'); return; }
        let rows = '';
        data.forEach(r => {
            rows += '<tr><td>' + Utils.escapeHtml(r.date) + '</td><td>' + (r.billNo || '-') + '</td><td>' + Utils.escapeHtml(r.patient) + '</td><td>' + Utils.escapeHtml(r.doctor) + '</td><td>' + Utils.escapeHtml(r.medicine) + '</td><td>' + Utils.escapeHtml(r.batch) + '</td><td style="text-align:right;">' + r.qty + '</td></tr>';
        });
        const table = '<table border="1" cellpadding="5" cellspacing="0" style="font-family:Arial;font-size:12px;border-collapse:collapse;width:100%;">' +
            '<tr style="background:#92400e;color:white;font-weight:bold;"><th>Date</th><th>Invoice No</th><th>Patient</th><th>Doctor</th><th>Medicine</th><th>Batch</th><th>Qty</th></tr>' +
            rows +
            '</table>';
        _downloadExcel(table, 'ramdevbaba_h1_register.xls', 'H1 Excel');
    }

    function exportSaleReportPDF() {
        const { data, totalQty, totalAmount, billCount, monthStr } = _getSaleReportData();
        if (!data.length) { UI.showToast('Koi sale data nahi hai PDF ke liye!', 'warn'); return; }
        const title = monthStr ? 'Sale Report - ' + monthStr : 'Sale Report - All Time';
        const ds = Utils.getTodayStr();
        let rows = '';
        let sr = 1;
        data.forEach(m => {
            rows += '<tr><td>' + (sr++) + '</td><td>' + Utils.escapeHtml(m.name) + '</td><td style="text-align:right;">' + m.count + '</td><td style="text-align:right;">' + m.qty + '</td><td style="text-align:right;">₹' + m.amount.toFixed(2) + '</td></tr>';
        });
        const html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>' +
            'body{font-family:Arial,sans-serif;padding:20px;color:#222;font-size:13px;}' +
            '.header{text-align:center;border-bottom:2px solid #7c3aed;padding-bottom:10px;margin-bottom:16px;}' +
            '.header h1{margin:0;font-size:17px;color:#7c3aed;}' +
            '.header p{margin:3px 0;font-size:11px;color:#555;}' +
            '.report-title{text-align:center;font-size:14px;font-weight:bold;margin:10px 0 2px 0;}' +
            '.summary{display:flex;gap:14px;margin-bottom:16px;}' +
            '.summary-box{flex:1;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;}' +
            '.summary-box .val{font-size:18px;font-weight:bold;color:#7c3aed;}' +
            '.summary-box .lbl{font-size:10px;color:#888;}' +
            'table{width:100%;border-collapse:collapse;}' +
            'th{background:#7c3aed;color:white;padding:8px 10px;text-align:left;font-size:11px;}' +
            'td{border:1px solid #e0e0e0;padding:7px 10px;}' +
            'tr:nth-child(even) td{background:#f5f5f5;}' +
            '.total-row{font-weight:bold;font-size:14px;text-align:right;margin-top:12px;}' +
            '.footer{margin-top:18px;text-align:right;font-size:10px;color:#aaa;border-top:1px solid #eee;padding-top:8px;}' +
            '</style></head><body>' +
            _buildStoreHeader() +
            '<div class="report-title">' + title + '</div>' +
            '<p style="text-align:center;font-size:11px;color:#777;">Generated: ' + ds + ' | Bills: ' + billCount + ' | Medicines: ' + data.length + '</p>' +
            '<div class="summary">' +
            '<div class="summary-box"><div class="val">' + data.length + '</div><div class="lbl">Medicines</div></div>' +
            '<div class="summary-box"><div class="val">' + totalQty + '</div><div class="lbl">Total Units</div></div>' +
            '<div class="summary-box"><div class="val">₹' + totalAmount.toFixed(2) + '</div><div class="lbl">Revenue</div></div>' +
            '<div class="summary-box"><div class="val">' + billCount + '</div><div class="lbl">Bills</div></div>' +
            '</div>' +
            '<table><thead><tr><th>#</th><th>Medicine Name</th><th style="text-align:right;">Times Sold</th><th style="text-align:right;">Qty</th><th style="text-align:right;">Amount (₹)</th></tr></thead><tbody>' + rows + '</tbody></table>' +
            '<div class="total-row">Grand Total: ₹' + totalAmount.toFixed(2) + ' (' + totalQty + ' units)</div>' +
            '<div class="footer">Report by Ramdevbaba Medical Store | ' + ds + '</div>' +
            '</body></html>';
        _openPrintWindow(html);
    }

    function downloadExpiredStockPDF() {
        const today = new Date();
        today.setHours(0, 0, 0, 0); // date-only compare — expiry month ke aakhri din tak valid
        let rows = '';
        let grand = 0;
        let count = 0;
        AppState.stockData.forEach(item => {
            (item.batches || []).forEach(b => {
                const exp = Utils.parseExpiry(b.expiry);
                if (exp && exp < today && (parseInt(b.qty, 10) || 0) > 0) {
                    count++;
                    rows += '<tr><td>' + count + '.</td><td>' + Utils.escapeHtml(item.name) + '</td><td>' + Utils.escapeHtml(item.wholesaler || '-') + '</td><td>' + Utils.escapeHtml(item.make || '-') + '</td><td>' + Utils.escapeHtml(b.batch) + '</td><td>' + Utils.escapeHtml(b.expiry) + '</td><td style="text-align:right;">' + b.qty + '</td><td style="text-align:right;">₹' + Number(b.price || 0).toFixed(2) + '</td></tr>';
                    grand += (Number(b.qty) || 0) * (Number(b.price) || 0);
                }
            });
        });
        const ds = Utils.getTodayStr();
        const html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>' +
            'body{font-family:Arial,sans-serif;padding:20px;color:#222;font-size:13px;}' +
            '.header{text-align:center;border-bottom:2px solid #c62828;padding-bottom:10px;margin-bottom:16px;}' +
            '.header h1{margin:0;font-size:17px;color:#c62828;}' +
            '.header p{margin:3px 0;font-size:11px;color:#555;}' +
            '.report-title{text-align:center;font-size:14px;font-weight:bold;margin:10px 0 2px 0;}' +
            'table{width:100%;border-collapse:collapse;}' +
            'th{background:#c62828;color:white;padding:8px 10px;text-align:left;font-size:11px;}' +
            'td{border:1px solid #e0e0e0;padding:7px 10px;}' +
            'tr:nth-child(even) td{background:#f5f5f5;}' +
            '.total-row{font-weight:bold;font-size:14px;text-align:right;margin-top:12px;}' +
            '.footer{margin-top:18px;text-align:right;font-size:10px;color:#aaa;border-top:1px solid #eee;padding-top:8px;}' +
            '</style></head><body>' +
            _buildStoreHeader() +
            '<div class="report-title">EXPIRED STOCK REPORT</div>' +
            '<p style="text-align:center;font-size:11px;color:#777;">Total Expired Batches: ' + count + ' | Generated: ' + ds + '</p>' +
            '<table><thead><tr><th>#</th><th>Medicine Name</th><th>Wholesaler</th><th>MAKE</th><th>Batch No</th><th>Expiry</th><th style="text-align:right;">Qty</th><th style="text-align:right;">Value (₹)</th></tr></thead><tbody>' + rows + '</tbody></table>' +
            '<div class="total-row">Total Value: ₹' + grand.toFixed(2) + '</div>' +
            '<div class="footer">Report by Ramdevbaba Medical Store | ' + ds + '</div>' +
            '</body></html>';
        Inventory.openPrintWindow(html);
    }

    function exportHRegisterPDF(type) {
        const data = History.getFilteredRegisterData(type);
        if (!data.length) { UI.showToast('Koi data nahi hai PDF ke liye!', 'warn'); return; }
        const labels = { h: 'Schedule H', h1: 'Schedule H1', h2: 'Schedule H2', narcotic: 'Narcotics/NDPS' };
        const label = labels[type] || type.toUpperCase();
        let rows = '';
        let sr = 1;
        data.forEach(r => {
            rows += '<tr><td>' + (sr++) + '</td><td>' + Utils.escapeHtml(r.date) + '</td><td>' + (r.billNo || '-') + '</td><td>' + Utils.escapeHtml(r.patient) + '</td><td>' + Utils.escapeHtml(r.doctor) + '</td><td>' + Utils.escapeHtml(r.medicine) + '</td><td>' + Utils.escapeHtml(r.batch) + '</td><td style="text-align:right;">' + r.qty + '</td></tr>';
        });
        const ds = Utils.getTodayStr();
        const themeColor = type === 'narcotic' ? '#991b1b' : type === 'h2' ? '#9d174d' : type === 'h1' ? '#92400e' : '#3730a3';
        const html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>' +
            'body{font-family:Arial,sans-serif;padding:20px;color:#222;font-size:13px;}' +
            '.header{text-align:center;border-bottom:2px solid ' + themeColor + ';padding-bottom:10px;margin-bottom:16px;}' +
            '.header h1{margin:0;font-size:17px;color:' + themeColor + ';}' +
            '.header p{margin:3px 0;font-size:11px;color:#555;}' +
            '.report-title{text-align:center;font-size:14px;font-weight:bold;margin:10px 0 2px 0;}' +
            'table{width:100%;border-collapse:collapse;}' +
            'th{background:' + themeColor + ';color:white;padding:8px 10px;text-align:left;font-size:11px;}' +
            'td{border:1px solid #e0e0e0;padding:7px 10px;}' +
            'tr:nth-child(even) td{background:#f5f5f5;}' +
            '.footer{margin-top:18px;text-align:right;font-size:10px;color:#aaa;border-top:1px solid #eee;padding-top:8px;}' +
            '</style></head><body>' +
            _buildStoreHeader() +
            '<div class="report-title">' + label + ' REGISTER</div>' +
            '<p style="text-align:center;font-size:11px;color:#777;">Total Entries: ' + (sr - 1) + ' | Generated: ' + ds + '</p>' +
            '<table><thead><tr><th>#</th><th>Date</th><th>Invoice No</th><th>Patient Name</th><th>Prescribed By</th><th>Medicine</th><th>Batch</th><th style="text-align:right;">Qty</th></tr></thead><tbody>' + rows + '</tbody></table>' +
            '<div class="footer">Report by Ramdevbaba Medical Store | ' + ds + '</div>' +
            '</body></html>';
        _openPrintWindow(html);
    }

    function exportHRegisterCSV(type) {
        const data = History.getFilteredRegisterData(type);
        if (!data.length) { UI.showToast('Koi data nahi mila!', 'warn'); return; }
        const sfx = type === 'narcotic' ? 'ndps' : type;
        let csv = '\uFEFFDate,Invoice No,Patient Name,Prescribed By,Medicine,Batch,Qty\n';
        data.forEach(r => {
            csv += [
                Utils.escapeCSV(r.date),
                Utils.escapeCSV(r.billNo || ''),
                Utils.escapeCSV(r.patient),
                Utils.escapeCSV(r.doctor),
                Utils.escapeCSV(r.medicine),
                Utils.escapeCSV(r.batch),
                Utils.escapeCSV(r.qty)
            ].join(',') + '\n';
        });
        _downloadCSV(csv, 'ramdevbaba_' + sfx + '_register.csv', sfx.toUpperCase() + ' CSV');
    }

    function exportHRegisterExcel(type) {
        const data = History.getFilteredRegisterData(type);
        if (!data.length) { UI.showToast('Koi data nahi mila!', 'warn'); return; }
        const sfx = type === 'narcotic' ? 'ndps' : type;
        let rows = '';
        data.forEach(r => {
            rows += '<tr><td>' + Utils.escapeHtml(r.date) + '</td><td>' + (r.billNo || '-') + '</td><td>' + Utils.escapeHtml(r.patient) + '</td><td>' + Utils.escapeHtml(r.doctor) + '</td><td>' + Utils.escapeHtml(r.medicine) + '</td><td>' + Utils.escapeHtml(r.batch) + '</td><td style="text-align:right;">' + r.qty + '</td></tr>';
        });
        const table = '<table border="1" cellpadding="5" cellspacing="0" style="font-family:Arial;font-size:12px;border-collapse:collapse;width:100%;">' +
            '<tr style="background:#1a237e;color:white;font-weight:bold;"><th>Date</th><th>Invoice No</th><th>Patient</th><th>Doctor</th><th>Medicine</th><th>Batch</th><th>Qty</th></tr>' +
            rows +
            '</table>';
        _downloadExcel(table, 'ramdevbaba_' + sfx + '_register.xls', sfx.toUpperCase() + ' Excel');
    }

    return {
        renderSaleReport,
        exportBillsCSV,
        exportBillsExcel,
        exportBillsPDF,
        exportH1PDF,
        exportH1CSV,
        exportH1Excel,
        exportSaleReportPDF,
        downloadExpiredStockPDF,
        exportHRegisterPDF,
        exportHRegisterCSV,
        exportHRegisterExcel
    };
})();
