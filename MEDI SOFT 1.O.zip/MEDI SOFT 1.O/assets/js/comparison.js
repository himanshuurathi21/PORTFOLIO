const Comparison = (() => {
    const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    function _getDayBills(dateStr) {
        return AppState.billsHistory.filter(b => !b.cancelled && b.date === dateStr);
    }

    function _getMonthBills(monthStr) {
        return AppState.billsHistory.filter(b => !b.cancelled && b.date && b.date.split('/').slice(1).join('/') === monthStr);
    }

    function _getYearBills(yearStr) {
        return AppState.billsHistory.filter(b => !b.cancelled && b.date && b.date.split('/')[2] === yearStr);
    }

    function _calcStats(bills) {
        let revenue = 0, billCount = bills.length, items = 0;
        bills.forEach(b => { revenue += b.total; items += (b.items || []).length; });
        return { revenue, billCount, items };
    }

    function _daysInMonth(month, year) {
        return new Date(year, month, 0).getDate();
    }

    function _pad2(n) { return String(n).padStart(2, '0'); }

    // ==================== DAILY COMPARISON ====================

    function renderDailyComparison() {
        const input = document.getElementById('compDailyMonth');
        if (!input.value) {
            const t = new Date();
            input.value = _pad2(t.getMonth() + 1) + '/' + t.getFullYear();
        }

        const parts = input.value.split('/');
        if (parts.length !== 2) return;
        const month = parseInt(parts[0], 10);
        const year = parseInt(parts[1], 10);
        if (isNaN(month) || isNaN(year) || month < 1 || month > 12) return;

        const monthStr = _pad2(month) + '/' + year;
        const daysInMonth = _daysInMonth(month, year);
        const monthBills = _getMonthBills(monthStr);
        const monthStats = _calcStats(monthBills);

        const dayData = [];
        for (let d = 1; d <= daysInMonth; d++) {
            const dateStr = _pad2(d) + '/' + _pad2(month) + '/' + year;
            const bills = _getDayBills(dateStr);
            const rev = bills.reduce((s, b) => s + b.total, 0);
            dayData.push({ day: d, dateStr, revenue: rev });
        }

        _renderSummary('compDailySummary', monthStats, 'Mahine ka total');

        const maxRev = Math.max(...dayData.map(d => d.revenue), 1);
        const container = document.getElementById('compDailyChart');
        Utils.clearElement(container);

        const wrapper = document.createElement('div');
        wrapper.style.cssText = 'background:#f8fafb;border-radius:10px;padding:16px;border:1px solid #e2e8f0;';

        const title = document.createElement('div');
        title.style.cssText = 'font-size:13px;font-weight:800;color:#1e2a3a;margin-bottom:12px;text-transform:uppercase;letter-spacing:0.5px;';
        title.textContent = '📅 ' + MONTH_NAMES[month - 1] + ' ' + year + ' — Har Din Ka Revenue';
        wrapper.appendChild(title);

        dayData.forEach(d => {
            const barW = Math.max((d.revenue / maxRev) * 100, 0);
            const isToday = d.day === new Date().getDate() && month === (new Date().getMonth() + 1) && year === new Date().getFullYear();
            const row = document.createElement('div');
            row.style.cssText = 'display:flex;align-items:center;gap:8px;margin-bottom:4px;padding:3px 4px;border-radius:4px;' + (isToday ? 'background:#eff6ff;' : '');

            const dayLabel = document.createElement('div');
            dayLabel.style.cssText = 'flex:0 0 36px;font-size:12px;font-weight:' + (isToday ? '800' : '600') + ';color:' + (isToday ? '#1a56db' : '#4b5563') + ';text-align:right;';
            dayLabel.textContent = String(d.day);
            row.appendChild(dayLabel);

            const barWrap = document.createElement('div');
            barWrap.style.cssText = 'flex:1;display:flex;align-items:center;gap:8px;';

            const bar = document.createElement('div');
            bar.style.cssText = 'height:18px;background:linear-gradient(90deg,#3b82f6,#1a56db);border-radius:4px;transition:width 0.2s;min-width:2px;';
            bar.style.width = barW + '%';
            barWrap.appendChild(bar);

            const valSpan = document.createElement('span');
            valSpan.style.cssText = 'font-size:12px;font-weight:700;color:#1a56db;white-space:nowrap;min-width:70px;';
            valSpan.textContent = '₹' + d.revenue.toFixed(2);
            barWrap.appendChild(valSpan);

            if (d.revenue === 0) {
                const noSale = document.createElement('span');
                noSale.style.cssText = 'font-size:10px;color:#9ca3af;font-style:italic;';
                noSale.textContent = '— koi bill nahi';
                barWrap.appendChild(noSale);
            }

            row.appendChild(barWrap);
            wrapper.appendChild(row);
        });

        container.appendChild(wrapper);
    }

    // ==================== MONTHLY COMPARISON ====================

    function renderMonthlyComparison() {
        const input = document.getElementById('compYearInput');
        if (!input.value) {
            input.value = String(new Date().getFullYear());
        }

        const year = parseInt(input.value, 10);
        if (isNaN(year)) return;

        const yearStr = String(year);
        const yearBills = _getYearBills(yearStr);
        const yearStats = _calcStats(yearBills);

        const monthData = [];
        for (let m = 1; m <= 12; m++) {
            const monthStr = _pad2(m) + '/' + yearStr;
            const bills = _getMonthBills(monthStr);
            const rev = bills.reduce((s, b) => s + b.total, 0);
            monthData.push({ month: m, label: MONTH_NAMES[m - 1], revenue: rev });
        }

        _renderSummary('compMonthlySummary', yearStats, 'Saal ka total');

        const maxRev = Math.max(...monthData.map(d => d.revenue), 1);
        const container = document.getElementById('compMonthlyChart');
        Utils.clearElement(container);

        const wrapper = document.createElement('div');
        wrapper.style.cssText = 'background:#f8fafb;border-radius:10px;padding:16px;border:1px solid #e2e8f0;';

        const title = document.createElement('div');
        title.style.cssText = 'font-size:13px;font-weight:800;color:#1e2a3a;margin-bottom:12px;text-transform:uppercase;letter-spacing:0.5px;';
        title.textContent = '📆 ' + year + ' — Har Mahine Ka Total Sale';
        wrapper.appendChild(title);

        const isCurrentYear = year === new Date().getFullYear();
        const currentMonth = new Date().getMonth() + 1;

        monthData.forEach(d => {
            const barW = Math.max((d.revenue / maxRev) * 100, 0);
            const isCurr = isCurrentYear && d.month === currentMonth;
            const isFuture = isCurrentYear && d.month > currentMonth;

            const row = document.createElement('div');
            row.style.cssText = 'display:flex;align-items:center;gap:8px;margin-bottom:5px;padding:4px 4px;border-radius:4px;' + (isCurr ? 'background:#eff6ff;' : '') + (isFuture ? 'opacity:0.4;' : '');

            const monthLabel = document.createElement('div');
            monthLabel.style.cssText = 'flex:0 0 50px;font-size:13px;font-weight:' + (isCurr ? '800' : '600') + ';color:' + (isCurr ? '#1a56db' : '#4b5563') + ';';
            monthLabel.textContent = d.label;
            row.appendChild(monthLabel);

            const barWrap = document.createElement('div');
            barWrap.style.cssText = 'flex:1;display:flex;align-items:center;gap:8px;';

            const bar = document.createElement('div');
            const barColor = d.revenue > 0 ? 'linear-gradient(90deg,#7c3aed,#6d28d9)' : 'linear-gradient(90deg,#e5e7eb,#d1d5db)';
            bar.style.cssText = 'height:22px;background:' + barColor + ';border-radius:4px;transition:width 0.2s;min-width:2px;';
            bar.style.width = barW + '%';
            barWrap.appendChild(bar);

            const valSpan = document.createElement('span');
            valSpan.style.cssText = 'font-size:12px;font-weight:700;color:' + (d.revenue > 0 ? '#7c3aed' : '#9ca3af') + ';white-space:nowrap;min-width:80px;';
            valSpan.textContent = '₹' + d.revenue.toFixed(2);
            barWrap.appendChild(valSpan);

            if (d.revenue === 0) {
                const noSale = document.createElement('span');
                noSale.style.cssText = 'font-size:10px;color:#9ca3af;font-style:italic;';
                noSale.textContent = '— koi sale nahi';
                barWrap.appendChild(noSale);
            }

            row.appendChild(barWrap);
            wrapper.appendChild(row);
        });

        container.appendChild(wrapper);
    }

    // ==================== COMMON ====================

    function _renderSummary(containerId, stats, label) {
        const container = document.getElementById(containerId);
        container.innerHTML = [
            '<div style="flex:1;min-width:120px;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;background:#f8fbff;">',
            '  <div style="font-size:18px;font-weight:bold;color:#1a56db;">₹' + stats.revenue.toFixed(2) + '</div>',
            '  <div style="font-size:10px;color:#888;">' + label + ' Revenue</div>',
            '</div>',
            '<div style="flex:1;min-width:100px;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;background:#f0fdf4;">',
            '  <div style="font-size:18px;font-weight:bold;color:#059669;">' + stats.billCount + '</div>',
            '  <div style="font-size:10px;color:#888;">' + label + ' Bills</div>',
            '</div>',
            '<div style="flex:1;min-width:100px;border:1px solid #e0e0e0;border-radius:8px;padding:10px;text-align:center;background:#fefce8;">',
            '  <div style="font-size:18px;font-weight:bold;color:#b45309;">' + stats.items + '</div>',
            '  <div style="font-size:10px;color:#888;">' + label + ' Items</div>',
            '</div>'
        ].join('');
    }

    function switchTab(tab) {
        document.getElementById('compTabDaily').className = tab === 'daily' ? 'btn-primary' : 'btn-secondary';
        document.getElementById('compTabMonthly').className = tab === 'monthly' ? 'btn-primary' : 'btn-secondary';
        document.getElementById('compDailyContent').style.display = tab === 'daily' ? 'block' : 'none';
        document.getElementById('compMonthlyContent').style.display = tab === 'monthly' ? 'block' : 'none';
        if (tab === 'daily') renderDailyComparison();
        else renderMonthlyComparison();
    }

    return {
        switchTab,
        renderDailyComparison,
        renderMonthlyComparison
    };
})();
