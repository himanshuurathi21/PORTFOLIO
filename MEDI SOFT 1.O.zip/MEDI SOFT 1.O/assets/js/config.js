const CONFIG = {
    // Cloud credentials sirf assets/neon-config.json mein hain (server-side).
    // Browser ke paas Neon connection string kabhi nahi aati — online backup
    // local server ke /api/* proxy se hota hai.

    LOW_STOCK_THRESHOLD: 20,
    EXPIRY_WARNING_DAYS: 30,
    CLOUD_PAGE_SIZE: 1000,
    PAGE_SIZE: 100,
    SESSION_TIMEOUT_MS: 3600000,

    PRINTER_NAME: 'EPSON LX-310 ESC/P', // Raw ESC/P print ke liye Windows printer ka exact naam — laptop se attached LX-310. Naam badle to yahi update karo.
    USE_CONDENSED_PITCH: true,  // LQ par condensed pitch (~17cpi) ON — paper narrow hai, 80-column layout paper se bahar na jaaye
    FORM_LINES: 32, // Continuous form ki lambai (lines me) — 100mm form + thoda extra eject. Job start me ESC C se set hota hai taaki aakhri FF sirf 1 form eject kare (extra blank pages nahi).

    LS_KEYS: {
        STOCK: 'rb_stock',
        HISTORY: 'rb_history',
        RETURNS: 'rb_return_history',
        DOCTORS: 'rb_doctors',
        MAKE_LIST: 'rb_makeList',
        WHOLESALER_LIST: 'rb_wholesalerList',
        PATIENT_WORDS: 'rb_patientWords',
        BILL_COUNTER: 'rb_bill_counter',
        LOGGED_IN: 'rb_logged_in',
        LOGIN_AT: 'rb_login_at'
    },

    get STORE_INFO() {
        return {
            name: 'SHRI RAMDEVBABA MEDICAL AND GENERAL STORE',
            address: 'NEAR BUS STAND, SANGRAMPUR, BULDHANA, MAHARASHTRA, 444202',
            mob: '9689792839 / 9970249982',
            fssai: '21521257000773',
            dlNo: '20-B.L.D-356019  21-B.L.D-356021  20-C-356020'
        };
    }
};
