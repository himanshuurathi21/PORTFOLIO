const AppModules = {
    goToMainMenu() {
        document.querySelectorAll('.app-section').forEach(s => s.style.display = 'none');
        document.getElementById('homeMenu').style.display = 'flex';
        Inventory.resetEditState();
        History.resetHistoryFilter();
    },

    openSection(id) {
        document.getElementById('homeMenu').style.display = 'none';
        document.querySelectorAll('.app-section').forEach(s => s.style.display = 'none');
        document.getElementById(id).style.display = 'block';
        if (id !== 'stockSection') Inventory.resetEditState();
    },

    openRegister(type) {
        const sectionMap = { h: 'hRegisterSection', h1: 'h1Section', h2: 'h2RegisterSection', narcotic: 'ndpsRegisterSection' };
        const renderMap = { h: 'renderHRegister', h1: 'renderH1Register', h2: 'renderH2Register', narcotic: 'renderNDPSRegister' };
        const sectionId = sectionMap[type] || 'h1Section';
        this.openSection(sectionId);
        const fn = History[renderMap[type]];
        if (fn) fn();
    },

    toggleDownloadDD(id) {
        const all = document.querySelectorAll('.download-dd-menu');
        all.forEach(m => { if (m.id !== id) m.classList.remove('show'); });
        document.getElementById(id).classList.toggle('show');
    },

    closeDownloadDD() {
        document.querySelectorAll('.download-dd-menu').forEach(m => m.classList.remove('show'));
    },

    setTheme(mode) {
        var html = document.documentElement;
        html.classList.remove('dark-mode', 'reading-mode');
        if (mode === 'dark') {
            html.classList.add('dark-mode');
            localStorage.setItem('theme', 'dark');
        } else if (mode === 'reading') {
            html.classList.add('reading-mode');
            localStorage.setItem('theme', 'reading');
        } else if (mode === 'light') {
            localStorage.setItem('theme', 'light');
        } else {
            localStorage.removeItem('theme');
            if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
                html.classList.add('dark-mode');
            }
        }
    },

    openLowStockView() {
        this.openSection('lowStockViewSection');
        this.renderLowStockView();
    },

    renderLowStockView() {
        const threshold = parseInt(document.getElementById('lowStockThreshold').value, 10) || CONFIG.LOW_STOCK_THRESHOLD;
        const tbody = document.getElementById('lowStockViewBody');
        Utils.clearElement(tbody);
        const items = [];
        AppState.stockData.forEach(item => {
            var batches = Array.isArray(item.batches) ? item.batches : [];
            if (!batches.length) {
                // Zero-batch medicine bhi low stock hai (qty 0) — pehle yeh
                // list se poori tarah gayab reh jati thi.
                if (threshold > 0) items.push({ name: item.name, qty: 0 });
                return;
            }
            batches.forEach(b => {
                if ((Number(b.qty) || 0) < threshold) items.push({ name: item.name, qty: Number(b.qty) || 0 });
            });
        });
        if (!items.length) {
            tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:#9ca3af;padding:30px;">Koi item nahi mila (qty < ' + threshold + ')</td></tr>';
            return;
        }
        let sr = 1;
        items.forEach(it => {
            const tr = document.createElement('tr');
            tr.innerHTML = '<td>' + (sr++) + '.</td><td>' + Utils.escapeHtml(it.name) + '</td><td style="text-align:right;color:#dc2626;font-weight:700;">' + it.qty + '</td>';
            tbody.appendChild(tr);
        });
    },

    renderStockValue() {
        var totalValue = 0, totalQty = 0, medCount = 0;
        var tbody = document.getElementById('stockValueBody');
        var summary = document.getElementById('stockValueSummary');
        Utils.clearElement(tbody);
        var rows = [];

        AppState.stockData.forEach(function(item) {
            var batches = Array.isArray(item.batches) ? item.batches : [];
            var medQty = batches.reduce(function(s, b) { return s + (Number(b.qty) || 0); }, 0);
            var medValue = batches.reduce(function(s, b) { return s + (Number(b.qty) || 0) * (Number(b.price) || 0); }, 0);
            if (medQty <= 0) return;
            medCount++;
            totalQty += medQty;
            totalValue += medValue;
            rows.push({ name: item.name, qty: medQty, value: medValue });
        });

        rows.sort(function(a, b) { return a.name.toLowerCase().localeCompare(b.name.toLowerCase()); });
        rows.forEach(function(r, i) {
            var tr = document.createElement('tr');
            tr.innerHTML = '<td>' + (i + 1) + '</td><td><strong>' + Utils.escapeHtml(r.name) + '</strong></td><td style="text-align:right;font-weight:700;">' + r.qty + '</td><td style="text-align:right;font-weight:700;color:#1a56db;">₹' + r.value.toFixed(2) + '</td>';
            tbody.appendChild(tr);
        });

        if (!rows.length) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#9ca3af;padding:30px;">Stock mein koi medicine nahi hai</td></tr>';
        }

        summary.innerHTML = [
            '<div style="flex:1;min-width:120px;border:1px solid #e0e0e0;border-radius:8px;padding:12px;text-align:center;background:#f8fbff;">',
            '  <div style="font-size:20px;font-weight:bold;color:#1a56db;">' + medCount + '</div>',
            '  <div style="font-size:10px;color:#888;">Medicines</div>',
            '</div>',
            '<div style="flex:1;min-width:120px;border:1px solid #e0e0e0;border-radius:8px;padding:12px;text-align:center;background:#f0fdf4;">',
            '  <div style="font-size:20px;font-weight:bold;color:#059669;">' + totalQty + '</div>',
            '  <div style="font-size:10px;color:#888;">Total Units</div>',
            '</div>',
            '<div style="flex:1;min-width:120px;border:1px solid #e0e0e0;border-radius:8px;padding:12px;text-align:center;background:#fefce8;">',
            '  <div style="font-size:20px;font-weight:bold;color:#b45309;">₹' + totalValue.toFixed(2) + '</div>',
            '  <div style="font-size:10px;color:#888;">Total Value</div>',
            '</div>'
        ].join('');
    },

    async clearAllData() {
        const confirmed = await UI.showConfirmDialog(
            '⚠️ Clear All Data?',
            'Is computer ka saara local data delete ho jayega — inventory stock, bills history, H1 register, doctors, sab kuch. Online backup (cloud) ko chhua nahi jayega. Yeh action wapas nahi ho sakta!',
            'Haan, Delete Karo',
            'Cancel'
        );
        if (!confirmed) return;
        const passwordOk = await UI.showPasswordPrompt();
        if (!passwordOk) return;
        await AppState.clearAllData();
        this.goToMainMenu();
        if (typeof Notifications !== 'undefined') Notifications.renderPanel();
        UI.showToast('Local data delete ho gaya. Online backup (cloud) safe hai.', 'info', 5000);
    },

    async clearCloudData() {
        var confirmed = await UI.showConfirmDialog(
            '🗑️ Clear Online Backup?',
            'Online backup (Neon) se saara data delete hoga. Is computer ka local data safe rahega. Aage badhein?',
            'Haan, Cloud Delete Karo',
            'Cancel'
        );
        if (!confirmed) return;
        var passwordOk = await UI.showPasswordPrompt();
        if (!passwordOk) return;
        UI.showProgressToast('🗑️ Online backup delete ho raha hai...');
        try {
            var ok = await Sync.deleteAllFromCloud();
            UI.hideProgressToast();
            if (ok) {
                UI.showToast('✅ Online backup saara delete ho gaya!', 'success');
            } else {
                UI.showToast('❌ Delete fail hua! Internet aur console (F12) check karein.', 'error', 5000);
            }
        } catch (e) {
            UI.hideProgressToast();
            UI.showToast('❌ Delete error! ' + (e.message || ''), 'error', 5000);
        }
    },

    async _genBackupFile() {
        // Backup se pehle pending saves flush karo aur doosre tab ka data merge
        // karo — warna naye bills file mein miss ho sakte hain.
        await AppState.flushSaves();
        try { await AppState.reconcile(); } catch (_) {}
        await AppState.flushSaves();

        const data = await AppState.exportAllData();
        const maxBillNo = (data.history || []).reduce(function (mx, b) {
            return Math.max(mx, parseInt(b && b.billNo, 10) || 0);
        }, 0);
        const billCount = (data.history || []).length;
        const stockCount = (data.stock || []).length;
        const billCounter = parseInt(data.billCounter, 10) || 0;

        data.backupMeta = {
            app: 'RATHI MEDISOFT',
            formatVersion: 2,
            createdAt: new Date().toISOString(),
            billCount: billCount,
            stockCount: stockCount,
            returnCount: (data.returnHistory || []).length,
            purchaseBillCount: (data.purchaseBills || []).length,
            maxBillNo: maxBillNo,
            billCounter: billCounter
        };

        const json = JSON.stringify(data);
        if (json.length > 100 * 1024 * 1024) {
            UI.showToast('File bahut bada hai (' + (json.length / 1024 / 1024).toFixed(1) + 'MB)! Purchase bills zip karke rakho.', 'warn', 6000);
        }

        // Round-trip verify — file mein wahi bills/stock hain jo memory mein hain.
        var parsed;
        try {
            parsed = JSON.parse(json);
        } catch (e) {
            throw new Error('Backup JSON verify fail: ' + (e.message || e));
        }
        var parsedBills = Array.isArray(parsed.history) ? parsed.history.length : -1;
        var parsedStock = Array.isArray(parsed.stock) ? parsed.stock.length : -1;
        var parsedMax = (parsed.history || []).reduce(function (mx, b) {
            return Math.max(mx, parseInt(b && b.billNo, 10) || 0);
        }, 0);
        if (parsedBills !== (data.history || []).length || parsedStock !== (data.stock || []).length || parsedMax !== maxBillNo) {
            throw new Error('Backup verify fail — file counts match nahi kar rahe. Dobara try karein.');
        }
        if ((parseInt(parsed.billCounter, 10) || 0) < parsedMax) {
            throw new Error('Backup verify fail — bill counter max bill number se chhota hai.');
        }

        // Extra safety: memory ke har bill ka id file mein hona chahiye.
        var memIds = new Set((data.history || []).map(function (b) { return b && b.id; }).filter(Boolean));
        var parsedIds = new Set((parsed.history || []).map(function (b) { return b && b.id; }).filter(Boolean));
        if (memIds.size !== parsedIds.size) {
            throw new Error('Backup verify fail — kuch bills file mein nahi aa paye. Dobara try karein.');
        }
        var missingBill = false;
        memIds.forEach(function (id) { if (!parsedIds.has(id)) missingBill = true; });
        if (missingBill) {
            throw new Error('Backup verify fail — bill ids match nahi kar rahe. Dobara try karein.');
        }

        var warnings = [];
        const now = new Date();
        const ts = now.toISOString().slice(0, 19).replace(/[:-]/g, '');
        // File ka naam: MEDISOFT BACKUP DD MMM YYYY.json (local date)
        const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
            'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
        const dd = String(now.getDate()).padStart(2, '0');
        const name = 'MEDISOFT BACKUP ' + dd + ' ' + MONTHS[now.getMonth()] + ' ' + now.getFullYear() + '.json';
        return {
            blob: new Blob([json], { type: 'application/json' }),
            name, json, ts, warnings,
            billCount: billCount,
            maxBillNo: maxBillNo,
            stockCount: stockCount
        };
    },

    async downloadBackup() {
        try {
            var file = await this._genBackupFile();
            const a = document.createElement('a');
            a.href = URL.createObjectURL(file.blob);
            a.download = file.name;
            a.click();
            setTimeout(() => URL.revokeObjectURL(a.href), 1000);
            Notifications.markBackupDone();
            if (file.warnings.length) {
                UI.showToast('⚠️ Backup download hui, lekin: ' + file.warnings.join(' '), 'warn', 10000);
            } else {
                UI.showToast('Backup download ho rahi hai! (' + file.billCount + ' bills, max #' + file.maxBillNo + ')', 'success', 5000);
            }
        } catch (e) {
            console.error('Backup error:', e);
            UI.showToast('Backup fail! ' + (e.message || ''), 'error', 7000);
        }
    },

    async sendBackup() {
        // Gmail window user click ke turant baad kholo — warna await ke baad
        // browser popup block kar deta hai (aur backup bina mail ke reh jata hai).
        const isMobile = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(navigator.userAgent);
        var gmailWin = null;
        if (!isMobile) {
            try { gmailWin = window.open('about:blank', '_blank'); } catch (_) { gmailWin = null; }
        }

        try {
            await AppState.flushSaves();
            try { await AppState.reconcile(); } catch (_) {}
            await AppState.flushSaves();

            var file = await this._genBackupFile();
            if (isMobile && navigator.canShare && navigator.canShare({ files: [new File([file.blob], file.name, { type: 'application/json' })] })) {
                try {
                    await navigator.share({
                        title: 'RATHI MEDISOFT Backup',
                        files: [new File([file.blob], file.name, { type: 'application/json' })]
                    });
                    Notifications.markBackupDone();
                    UI.showToast('Backup share ho gaya!', 'success');
                    return;
                } catch (_) {}
            }

            const a = document.createElement('a');
            a.href = URL.createObjectURL(file.blob);
            a.download = file.name;
            a.click();
            setTimeout(() => URL.revokeObjectURL(a.href), 1000);
            Notifications.markBackupDone();

            var gmailUrl = 'https://mail.google.com/mail/?view=cm&fs=1&to=rathihimanshuu@gmail.com' +
                '&su=RATHI+MEDISOFT+Backup+' + file.ts +
                '&body=Attached+backup+file+for+RATHI+MEDISOFT.%0A%0ABills:+' + file.billCount +
                '%0AMax+Bill+No:+' + file.maxBillNo +
                '%0AStock+Items:+' + file.stockCount;

            if (gmailWin && !gmailWin.closed) {
                try { gmailWin.location.href = gmailUrl; } catch (_) { gmailWin = null; }
            }
            if (!gmailWin || gmailWin.closed) {
                var opened = window.open(gmailUrl, '_blank');
                if (!opened) {
                    UI.showToast('File download hui! Gmail popup block hua — manually Gmail khol ke file attach karein.', 'warn', 9000);
                } else {
                    UI.showToast('File download hui! Gmail khol ke file drag-drop karein.', 'info', 6000);
                }
            } else {
                UI.showToast('File download hui! Gmail tab mein file drag-drop karein.', 'info', 6000);
            }

            if (file.warnings.length) {
                UI.showToast('⚠️ Backup warning: ' + file.warnings.join(' '), 'warn', 11000);
            }
        } catch (e) {
            if (gmailWin && !gmailWin.closed) { try { gmailWin.close(); } catch (_) {} }
            console.error('Send backup error:', e);
            UI.showToast('Send backup fail! ' + (e.message || ''), 'error', 7000);
        }
    },

    async syncToCloud() {
        if (!AppState.stockData.length && !AppState.billsHistory.length) {
            UI.showToast('⚠️ Local data khali hai — pehle kuch stock/bills add karein.', 'warn', 5000);
            return;
        }
        UI.showProgressToast('☁️ Online backup chal raha hai... (internet chahiye)');
        try {
            var result = await Sync.syncAllToCloud();
            UI.hideProgressToast();
            if (result) {
                Notifications.markBackupDone();
                UI.showToast('✅ Online backup complete! ' + AppState.stockData.length + ' stock items, ' + AppState.billsHistory.length + ' bills.', 'success', 4500);
            } else {
                UI.showToast('❌ Backup fail! Internet connection aur console (F12) check karein.', 'error', 6000);
            }
        } catch (e) {
            UI.hideProgressToast();
            UI.showToast('❌ Backup error! Internet connection check karein. ' + (e.message || ''), 'error', 6000);
            console.error('SYNC ERROR:', e);
        }
    },

    async restoreFromCloud() {
        var confirmed = await UI.showConfirmDialog(
            'Online Backup Restore?',
            'Online backup se data laake local data ke saath MERGE hoga. Purane local bills/stock delete nahi honge. Continue karein?',
            'Haan, Merge Karo',
            'Cancel'
        );
        if (!confirmed) return;
        UI.showProgressToast('☁️ Online backup restore ho raha hai... (internet chahiye)');
        try {
            var res = await Sync.fetchAllFromCloud();
            UI.hideProgressToast();
            if (res && res.ok) {
                var r = res.report || {};
                var parts = [];
                if (r.addedBills) parts.push(r.addedBills + ' naye bills');
                if (r.dupBills) parts.push(r.dupBills + ' pehle se maujood');
                if (r.addedStock) parts.push(r.addedStock + ' naye stock items');
                if (r.purchaseAdded) parts.push(r.purchaseAdded + ' purchase bills');
                var detail = parts.length ? ' (' + parts.join(', ') + ')' : '';
                if (typeof Notifications !== 'undefined') Notifications.renderPanel();
                if (typeof Inventory !== 'undefined') Inventory.renderStockTable();
                if (typeof History !== 'undefined') History.renderHistoryTable();
                UI.showToast('✅ Restore complete!' + detail + ' Total: ' + AppState.stockData.length + ' items, ' + AppState.billsHistory.length + ' bills.', 'success', 6000);
            } else {
                UI.showToast('❌ ' + ((res && res.message) || 'Restore fail! Console (F12) dekhein.'), 'error', 7000);
            }
        } catch (e) {
            UI.hideProgressToast();
            UI.showToast('❌ Restore error! Internet connection check karein. ' + (e.message || ''), 'error', 6000);
            console.error('RESTORE ERROR:', e);
        }
    },

    openEditor() {
        this.openSection('editorSection');
    },

    switchEditorTab(tab) {
        var tabMap = { pharma: 'editorTabPharma', patient: 'editorTabPatient', doctor: 'editorTabDoctor' };
        var contentMap = { pharma: 'editorPharmaContent', patient: 'editorPatientContent', doctor: 'editorDoctorContent' };
        var renderMap = { pharma: 'renderPharmaEditor', patient: 'renderPatientEditor', doctor: 'renderDoctorEditor' };

        Object.values(tabMap).forEach(function(id) {
            document.getElementById(id).className = 'btn-secondary';
        });
        document.getElementById(tabMap[tab]).className = 'btn-primary';

        Object.values(contentMap).forEach(function(id) {
            document.getElementById(id).style.display = 'none';
        });
        document.getElementById(contentMap[tab]).style.display = 'block';

        var fn = this[renderMap[tab]];
        if (fn) fn.call(this);
    },

    renderPharmaEditor() {
        this.renderPharmaManager();
    },

    renderPatientEditor() {
        var container = document.getElementById('patientManagerList');
        if (!container) return;
        Utils.clearElement(container);
        var list = AppState.patientWords;
        if (!list || !list.length) {
            container.innerHTML = '<div style="text-align:center;padding:40px;color:#9ca3af;">ℹ️ Koi patient name suggestion nahi hai</div>';
            return;
        }
        var heading = document.createElement('div');
        heading.style.cssText = 'font-size:14px;font-weight:700;color:#374151;margin-bottom:12px;';
        heading.textContent = 'Total ' + list.length + ' patient words:';
        container.appendChild(heading);
        list.forEach(function(word) {
            container.appendChild(AppModules._createEditorRow(word, function(oldVal, newVal) {
                return AppState.updatePatientWord(oldVal, newVal);
            }, function(val) {
                AppState.removePatientWord(val);
                UI.showToast('"' + val + '" patient suggestions se hata diya!', 'info');
                AppModules.renderPatientEditor();
            }));
        });
    },

    renderDoctorEditor() {
        var container = document.getElementById('doctorManagerList');
        if (!container) return;
        Utils.clearElement(container);
        var list = AppState.doctorsList;
        if (!list || !list.length) {
            container.innerHTML = '<div style="text-align:center;padding:40px;color:#9ca3af;">ℹ️ Koi doctor name suggestion nahi hai</div>';
            return;
        }
        var heading = document.createElement('div');
        heading.style.cssText = 'font-size:14px;font-weight:700;color:#374151;margin-bottom:12px;';
        heading.textContent = 'Total ' + list.length + ' doctor names:';
        container.appendChild(heading);
        list.forEach(function(name) {
            container.appendChild(AppModules._createEditorRow(name, function(oldVal, newVal) {
                return AppState.updateDoctor(oldVal, newVal);
            }, function(val) {
                AppState.removeDoctor(val);
                UI.showToast('"' + val + '" doctor suggestions se hata diya!', 'info');
                AppModules.renderDoctorEditor();
            }));
        });
    },

    _createEditorRow(value, updateFn, deleteFn) {
        var row = document.createElement('div');
        row.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border:1px solid #e5e7eb;border-radius:8px;margin-bottom:6px;background:white;';

        var nameSpan = document.createElement('span');
        nameSpan.style.cssText = 'font-weight:600;color:#374151;font-size:14px;flex:1;';
        nameSpan.textContent = value;

        var editInput = document.createElement('input');
        editInput.type = 'text';
        editInput.value = value;
        editInput.style.cssText = 'display:none;flex:1;padding:7px 10px;border:1.5px solid #1a56db;border-radius:6px;font-size:14px;outline:none;';

        var btnGroup = document.createElement('div');
        btnGroup.style.cssText = 'display:flex;gap:6px;flex-shrink:0;';

        var editBtn = document.createElement('button');
        editBtn.className = 'btn-primary';
        editBtn.style.cssText = 'padding:5px 14px;font-size:12px;';
        editBtn.textContent = '✏ Edit';

        var saveBtn = document.createElement('button');
        saveBtn.className = 'btn-success';
        saveBtn.style.cssText = 'display:none;padding:5px 14px;font-size:12px;';
        saveBtn.textContent = '💾 Save';

        var cancelBtn = document.createElement('button');
        cancelBtn.className = 'btn-secondary';
        cancelBtn.style.cssText = 'display:none;padding:5px 14px;font-size:12px;background:#9ca3af;';
        cancelBtn.textContent = 'Cancel';

        var delBtn = document.createElement('button');
        delBtn.className = 'btn-danger';
        delBtn.style.cssText = 'padding:5px 14px;font-size:12px;';
        delBtn.textContent = '✕ Hatao';

        editBtn.addEventListener('click', function() {
            nameSpan.style.display = 'none';
            editInput.style.display = 'block';
            editInput.value = nameSpan.textContent;
            editBtn.style.display = 'none';
            saveBtn.style.display = 'inline-block';
            cancelBtn.style.display = 'inline-block';
            delBtn.style.display = 'none';
            setTimeout(function() { editInput.focus(); editInput.select(); }, 50);
        });

        saveBtn.addEventListener('click', function() {
            var newVal = editInput.value.trim();
            if (!newVal) { UI.showToast('Naam khali nahi ho sakta!', 'error'); return; }
            var oldVal = nameSpan.textContent;
            if (newVal === oldVal) {
                cancelBtn.click();
                return;
            }
            var ok = updateFn(oldVal, newVal);
            if (ok) {
                nameSpan.textContent = newVal;
                UI.showToast('Update ho gaya!', 'success');
            } else {
                UI.showToast('Update fail!', 'error');
            }
            cancelBtn.click();
        });

        cancelBtn.addEventListener('click', function() {
            nameSpan.style.display = 'block';
            editInput.style.display = 'none';
            editBtn.style.display = 'inline-block';
            saveBtn.style.display = 'none';
            cancelBtn.style.display = 'none';
            delBtn.style.display = 'inline-block';
        });

        editInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') saveBtn.click();
            if (e.key === 'Escape') cancelBtn.click();
        });

        delBtn.addEventListener('click', function() {
            deleteFn(nameSpan.textContent);
        });

        btnGroup.appendChild(editBtn);
        btnGroup.appendChild(saveBtn);
        btnGroup.appendChild(cancelBtn);
        btnGroup.appendChild(delBtn);
        row.appendChild(nameSpan);
        row.appendChild(editInput);
        row.appendChild(btnGroup);
        return row;
    },

    renderPharmaManager() {
        var container = document.getElementById('pharmaManagerList');
        if (!container) return;
        Utils.clearElement(container);
        var list = AppState.getWholesalerList();
        if (!list || !list.length) {
            container.innerHTML = '<div style="text-align:center;padding:40px;color:#9ca3af;">ℹ️ Koi pharma name suggestion list mein nahi hai</div>';
            return;
        }
        var heading = document.createElement('div');
        heading.style.cssText = 'font-size:14px;font-weight:700;color:#374151;margin-bottom:12px;';
        heading.textContent = 'Total ' + list.length + ' pharma names:';
        container.appendChild(heading);
        list.forEach(function(name) {
            container.appendChild(AppModules._createEditorRow(name, function(oldVal, newVal) {
                return AppState.updateWholesaler(oldVal, newVal);
            }, function(val) {
                AppState.removeWholesaler(val);
                UI.showToast('"' + val + '" suggestion list se hata diya!', 'info');
                AppModules.renderPharmaManager();
            }));
        });
    },

    async testDbConnection() {
        UI.showProgressToast('🔍 Connection check ho raha hai...');
        try {
            var test = await Database.cloudFetch('stock');
            UI.hideProgressToast();
            if (Array.isArray(test)) {
                UI.showToast('✅ Online backup (Neon) connected! Remote stock: ' + test.length + ' items.', 'success', 4500);
            } else if (test && test.error) {
                UI.showToast('❌ Online backup error: ' + test.error + '\nInternet connection check karein.', 'error', 6000);
            } else {
                UI.showToast('⚠️ Unexpected response.', 'warn', 4000);
            }
        } catch (e) {
            UI.hideProgressToast();
            UI.showToast('❌ Connection fail! ' + (e.message || ''), 'error', 5000);
            console.error(e);
        }
    },

    openExpiryView() {
        this.openSection('expirySection');
        if (typeof Returns !== 'undefined') Returns.renderExpiryList();
    },

    openReturnsView() {
        this.openSection('returnHistorySection');
        if (typeof Returns !== 'undefined') Returns.refresh();
    },

    openComparisonView() {
        this.openSection('comparisonSection');
        Comparison.switchTab('daily');
    },

    // Bulk return ke baad expiry screen khuli ho to fresh stock se list
    // dobara render karo (returned items list se hat jaate hain).
    refreshExpiryIfVisible() {
        var section = document.getElementById('expirySection');
        if (!section || section.style.display === 'none') return;
        if (typeof Returns !== 'undefined') Returns.renderExpiryList();
    },

    // Purane callers ke liye alias — expiry list ka rendering ab Returns
    // module handle karta hai (selection state ke saath).
    renderExpiryTable() {
        if (typeof Returns !== 'undefined') Returns.renderExpiryList();
    }
};

document.addEventListener('DOMContentLoaded', async function () {
    await AppState.init();
    UI.setupClickOutside();
    Auth.setup();
    Notifications.init();


    document.getElementById('billDate').value = Utils.formatDateForInput();
    Billing.resetBillingForm();
    Inventory.initBatchRows();

    PurchaseModule.init();
    PurchaseOrder.init();
    if (typeof Returns !== 'undefined') Returns.init();

    const t = new Date();
    document.getElementById('reportMonth').value = String(t.getMonth() + 1).padStart(2, '0') + '/' + t.getFullYear();

    // NOTE: Koi automatic cloud sync nahi. App poora offline chalta hai.
    // Online backup sirf Backup & Restore section ke button se hota hai.

    if (!Auth.isLoggedIn()) {
        Auth.showLogin();
    } else {
        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('homeMenu').style.display = 'flex';
        if (typeof Inventory !== 'undefined' && Inventory.renderStockTable) Inventory.renderStockTable();
        if (typeof History !== 'undefined' && History.renderHistoryTable) History.renderHistoryTable();
        if (typeof Notifications !== 'undefined' && Notifications.renderPanel) Notifications.renderPanel();
    }

    var savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.documentElement.classList.add('dark-mode');
    } else if (savedTheme === 'reading') {
        document.documentElement.classList.add('reading-mode');
    } else if (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        document.documentElement.classList.add('dark-mode');
    }
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function(e) {
        if (!localStorage.getItem('theme')) {
            document.documentElement.classList.toggle('dark-mode', e.matches);
        }
    });

    // Escape sirf temporary UI band karta hai (dropdown/modal/suggestions).
    // Kabhi bhi bill form reset ya main menu par navigate NAHI karta — isse
    // pehle in-progress bill ka poora data silently delete ho jata tha.
    document.addEventListener('keydown', function(e) {
        if (e.key !== 'Escape') return;
        var login = document.getElementById('loginScreen');
        if (login && login.style.display !== 'none') return;

        // Bill preview modal
        var preview = document.getElementById('billPreviewModal');
        if (preview && preview.style.display !== 'none' && preview.style.display !== '') {
            if (typeof Billing !== 'undefined' && Billing.closePreview) Billing.closePreview();
            return;
        }

        // Return / return-details / bulk-return modals
        var returnModal = document.getElementById('returnModal');
        var returnDetailsModal = document.getElementById('returnDetailsModal');
        var bulkReturnModal = document.getElementById('bulkReturnModal');
        if (returnModal && returnModal.classList.contains('show')) {
            if (typeof Returns !== 'undefined' && Returns.closeReturnModal) Returns.closeReturnModal();
            return;
        }
        if (bulkReturnModal && bulkReturnModal.classList.contains('show')) {
            if (typeof Returns !== 'undefined' && Returns.closeBulkReturnModal) Returns.closeBulkReturnModal();
            return;
        }
        if (returnDetailsModal && returnDetailsModal.classList.contains('show')) {
            if (typeof Returns !== 'undefined' && Returns.closeDetailsModal) Returns.closeDetailsModal();
            return;
        }

        // Bill cancel modal
        var cancelModal = document.getElementById('cancelModal');
        if (cancelModal && cancelModal.classList.contains('show')) {
            if (typeof History !== 'undefined' && History.closeCancelModal) History.closeCancelModal();
            cancelModal.classList.remove('show');
            return;
        }

        // Notifications panel
        var notifPanel = document.getElementById('notifPanel');
        if (notifPanel && notifPanel.classList.contains('open')) {
            notifPanel.classList.remove('open');
            var notifOverlay = document.getElementById('notifOverlay');
            if (notifOverlay) notifOverlay.classList.remove('show');
            return;
        }

        // Download dropdowns
        var hadDownloadDD = false;
        document.querySelectorAll('.download-dd-menu.show').forEach(function(el) {
            el.classList.remove('show');
            hadDownloadDD = true;
        });
        if (hadDownloadDD) return;

        // Suggestion / autocomplete boxes
        document.querySelectorAll('.suggestion-box.show, .autocomplete-list.show, .suggestions.show').forEach(function(el) {
            el.classList.remove('show');
        });
        // Focus ko input se hatao (suggestion band), form data waisa hi rahega.
        if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    });
});
