const Utils = {
    escapeHtml(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    },

    sanitizeAndSet(element, value) {
        if (!element) return;
        element.textContent = value;
    },

    _idCounter: 0,
    generateId(prefix) {
        prefix = prefix || 'id';
        var c = ++this._idCounter;
        var micro = typeof performance !== 'undefined' && performance.now ? Math.round(performance.now() * 1000) : 0;
        return prefix + '_' + Date.now() + '_' + micro + '_' + c + '_' + Math.random().toString(36).slice(2, 8);
    },

    debounce(fn, delay) {
        let timer;
        return function (...args) {
            clearTimeout(timer);
            timer = setTimeout(() => fn.apply(this, args), delay);
        };
    },

    formatDateForInput(date) {
        const d = date || new Date();
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
    },

    parseExpiry(expiryStr) {
        if (!expiryStr || expiryStr.length < 7) return null;
        const parts = String(expiryStr).split('/');
        if (parts.length !== 2) return null;
        const month = parseInt(parts[0], 10);
        const year = parseInt(parts[1], 10);
        if (isNaN(month) || isNaN(year) || month < 1 || month > 12) return null;
        // Expiry MM/YYYY ka matlab mahine ka AAKHRI din hota hai — pehle
        // month ke 1st din se compare hota tha, jisse valid medicine bhi
        // mahine ke shuru mein "expired" dikh jati thi.
        return new Date(year, month, 0, 23, 59, 59, 999);
    },

    // Expiry month poora beet chuka hai? Today ko midnight se compare karte
    // hain, taaki expiry month ke aakhri din tak dawa valid rahe.
    isExpired(expiryStr) {
        const exp = this.parseExpiry(expiryStr);
        if (!exp) return false;
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return exp < today;
    },

    // DD/MM/YYYY ko real Date (midnight) mein convert karta hai. Invalid
    // dates (31/02/2026 etc.) ke liye null return hota hai.
    parseDisplayDate(dateStr) {
        if (!dateStr || typeof dateStr !== 'string') return null;
        const parts = dateStr.trim().split('/');
        if (parts.length !== 3) return null;
        const day = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10);
        const year = parseInt(parts[2], 10);
        if (!day || !month || !year || day < 1 || day > 31 || month < 1 || month > 12 || year < 1900 || year > 2200) return null;
        const d = new Date(year, month - 1, day);
        if (d.getFullYear() !== year || d.getMonth() !== month - 1 || d.getDate() !== day) return null;
        d.setHours(0, 0, 0, 0);
        return d;
    },

    isValidDisplayDate(dateStr) {
        return this.parseDisplayDate(dateStr) !== null;
    },

    escapeAttr(str) {
        if (str === undefined || str === null) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    },

    // CSV cell — Excel/Sheets ke liye safe quoting (comma, quote, newline).
    escapeCSV(value) {
        var s = (value === undefined || value === null) ? '' : String(value);
        // Formula injection se bachao (Excel =, +, -, @ ko formula samajhta hai).
        if (/^[=+\-@]/.test(s)) s = "'" + s;
        if (/[",\r\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
        return s;
    },

    compareDates(a, b) {
        if (!a || !b) return NaN;
        const da = a.split('/');
        const db = b.split('/');
        if (da.length !== 3 || db.length !== 3) return NaN;
        const daNum = parseInt(da[0], 10), dbNum = parseInt(db[0], 10);
        const maNum = parseInt(da[1], 10), mbNum = parseInt(db[1], 10);
        const yaNum = parseInt(da[2], 10), ybNum = parseInt(db[2], 10);
        if (isNaN(daNum) || isNaN(dbNum) || isNaN(maNum) || isNaN(mbNum) || isNaN(yaNum) || isNaN(ybNum)) return NaN;
        const dateA = new Date(yaNum, maNum - 1, daNum);
        const dateB = new Date(ybNum, mbNum - 1, dbNum);
        if (isNaN(dateA.getTime()) || isNaN(dateB.getTime())) return NaN;
        return dateA - dateB;
    },

    formatAndValidateDate(input) {
        let v = input.value.replace(/\D/g, '');
        let f = '';
        for (let i = 0; i < v.length && i < 8; i++) {
            if (i === 2 || i === 4) f += '/';
            f += v[i];
        }
        const parts = f.split('/');
        if (parts[0] && parts[0].length === 2) {
            const day = parseInt(parts[0], 10);
            if (day > 31) parts[0] = parts[0][0];
        }
        if (parts[1] && parts[1].length === 2) {
            const month = parseInt(parts[1], 10);
            if (month > 12) parts[1] = parts[1][0];
        }
        input.value = parts.join('/');
    },

    _clampMonth(f) {
        if (f.length >= 2) {
            const month = parseInt(f.substring(0, 2), 10);
            if (month > 12) {
                return f[0] + f.substring(2);
            }
            if (month === 0) {
                return '0' + f.substring(1);
            }
        }
        return f;
    },

    _autoPadMonth(f) {
        const slashIdx = f.indexOf('/');
        const monthPart = slashIdx === -1 ? f : f.substring(0, slashIdx);
        if (monthPart.length === 1) {
            const m = parseInt(monthPart, 10);
            if (m >= 2 && m <= 9) {
                f = '0' + f;
            }
        }
        return f;
    },

    formatAndValidateMonth(input) {
        let v = input.value.replace(/\D/g, '');
        let f = '';
        for (let i = 0; i < v.length && i < 6; i++) {
            if (i === 2) f += '/';
            f += v[i];
        }
        f = Utils._clampMonth(f);
        f = Utils._autoPadMonth(f);
        input.value = f;
    },

    formatAndValidateExpiry(input) {
        if (/^\d{2}\/\d{4}$/.test(input.value)) {
            const month = parseInt(input.value.substring(0, 2), 10);
            if (month > 12) {
                input.value = '0' + input.value.substring(1);
            }
            return;
        }
        let v = input.value.replace(/\D/g, '');
        let f = '';
        for (let i = 0; i < v.length && i < 6; i++) {
            if (i === 2) f += '/';
            f += v[i];
        }
        f = Utils._clampMonth(f);
        f = Utils._autoPadMonth(f);
        input.value = f;
    },

    getTodayStr() {
        const t = new Date();
        return `${String(t.getDate()).padStart(2, '0')}/${String(t.getMonth() + 1).padStart(2, '0')}/${t.getFullYear()}`;
    },

    getWeekStartStr() {
        const t = new Date();
        const ws = new Date(t);
        // Monday ko week ka pehla din maano. Purana formula Sunday par
        // agla Monday (aane wala din) de deta tha, jisse "This Week" total
        // galat (sirf Sunday) dikhta tha.
        const daysSinceMonday = (ws.getDay() + 6) % 7;
        ws.setDate(ws.getDate() - daysSinceMonday);
        return `${String(ws.getDate()).padStart(2, '0')}/${String(ws.getMonth() + 1).padStart(2, '0')}/${ws.getFullYear()}`;
    },

    getMonthStartStr() {
        const t = new Date();
        return `01/${String(t.getMonth() + 1).padStart(2, '0')}/${t.getFullYear()}`;
    },

    getTimeStr() {
        const now = new Date();
        return String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
    },

    sha256(str) {
        if (typeof crypto !== 'undefined' && crypto.subtle && crypto.subtle.digest) {
            const encoder = new TextEncoder();
            const data = encoder.encode(str);
            return crypto.subtle.digest('SHA-256', data).then(buffer => {
                const hex = Array.from(new Uint8Array(buffer))
                    .map(b => b.toString(16).padStart(2, '0'))
                    .join('');
                return hex;
            });
        }
        return Promise.resolve(this._sha256Fallback(str));
    },

    _sha256Fallback(str) {
        function rightRotate(value, amount) { return (value >>> amount) | (value << (32 - amount)); }
        const K = [
            0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
            0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
            0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
            0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
            0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
            0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
            0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
            0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
            0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
            0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
            0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
            0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
            0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
            0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
            0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
            0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
        ];
        const encoder = new TextEncoder();
        const bytes = encoder.encode(str);
        const bitLen = bytes.length * 8;
        const padded = new Uint8Array((bytes.length + 9 + 63) & ~63);
        padded.set(bytes);
        padded[bytes.length] = 0x80;
        const dv = new DataView(padded.buffer);
        dv.setUint32(padded.length - 8, 0, false);
        dv.setUint32(padded.length - 4, bitLen >>> 0, false);
        let H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
        for (let i = 0; i < padded.length; i += 64) {
            const W = new Uint32Array(64);
            const view = new DataView(padded.buffer, i, 64);
            for (let t = 0; t < 16; t++) W[t] = view.getUint32(t * 4, false);
            for (let t = 16; t < 64; t++) {
                const s0 = rightRotate(W[t - 15], 7) ^ rightRotate(W[t - 15], 18) ^ (W[t - 15] >>> 3);
                const s1 = rightRotate(W[t - 2], 17) ^ rightRotate(W[t - 2], 19) ^ (W[t - 2] >>> 10);
                W[t] = (W[t - 16] + s0 + W[t - 7] + s1) >>> 0;
            }
            let a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
            for (let t = 0; t < 64; t++) {
                const S1 = rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25);
                const ch = (e & f) ^ ((~e) & g);
                const temp1 = (h + S1 + ch + K[t] + W[t]) >>> 0;
                const S0 = rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22);
                const maj = (a & b) ^ (a & c) ^ (b & c);
                const temp2 = (S0 + maj) >>> 0;
                h = g; g = f; f = e; e = (d + temp1) >>> 0; d = c; c = b; b = a; a = (temp1 + temp2) >>> 0;
            }
            H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + b) >>> 0; H[2] = (H[2] + c) >>> 0;
            H[3] = (H[3] + d) >>> 0; H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0;
            H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
        }
        return H.map(v => v.toString(16).padStart(8, '0')).join('');
    },

    createElement(tag, attrs, children) {
        const el = document.createElement(tag);
        if (attrs) {
            Object.entries(attrs).forEach(([key, val]) => {
                if (key === 'className') el.className = val;
                else if (key === 'innerText') el.textContent = val;
                else if (key === 'htmlContent') el.innerHTML = val;
                else if (key.startsWith('on')) el.addEventListener(key.slice(2).toLowerCase(), val);
                else el.setAttribute(key, val);
            });
        }
        if (children) {
            if (typeof children === 'string') el.textContent = children;
            else if (Array.isArray(children)) children.forEach(c => { if (c) el.appendChild(c); });
            else if (children instanceof HTMLElement) el.appendChild(children);
        }
        return el;
    },

    clearElement(element) {
        if (!element) return;
        while (element.firstChild) element.removeChild(element.firstChild);
    },

    createOption(value, text, isSelected) {
        const opt = document.createElement('option');
        opt.value = value;
        opt.textContent = text;
        if (isSelected) opt.selected = true;
        return opt;
    },

    padRight(str, width) {
        str = String(str == null ? '' : str);
        return str.length >= width ? str : str + ' '.repeat(width - str.length);
    },

    padLeft(str, width) {
        str = String(str == null ? '' : str);
        return str.length >= width ? str : ' '.repeat(width - str.length) + str;
    },

    padCenter(str, width) {
        str = String(str == null ? '' : str);
        if (str.length >= width) return str;
        const left = Math.floor((width - str.length) / 2);
        return ' '.repeat(left) + str + ' '.repeat(width - str.length - left);
    },

    truncate(str, width) {
        str = String(str == null ? '' : str);
        return str.length <= width ? str : str.slice(0, width);
    },

    buildBillText(bill) {
        const info = CONFIG.STORE_INFO;
        const W = 80;
        const eq = '='.repeat(W);
        const dash = '-'.repeat(W);
        const items = bill.items || [];
        const qtyTotal = items.reduce((s, it) => s + (it.qty || 0), 0);

        let t = '';
        t += Utils.padCenter('CASH MEMO', W) + '\n';
        t += Utils.padCenter(info.name, W) + '\n';
        t += Utils.padCenter(info.address, W) + '\n';
        t += Utils.padCenter('Mob: ' + info.mob, W) + '\n';
        t += 'FSSAI: ' + info.fssai + '  DL: ' + info.dlNo + '\n';
        t += dash + '\n';
        t += 'Invoice No: ' + Utils.padRight(String(bill.billNo), 6) + '  Date: ' + bill.date + '\n';
        const _nameCap = Math.floor((W - 21) / 2);
        t += 'Patient: ' + Utils.truncate(bill.patient || 'Cash Customer', _nameCap) + '   Doctor:  ' + Utils.truncate(bill.doctor || 'Self', _nameCap) + '\n';
        t += dash + '\n';
        t += Utils.padRight('#', 3) + Utils.padRight('ITEM', 30) + Utils.padRight('MAKE', 12) + Utils.padRight('BATCH', 11) + Utils.padRight('EXP', 8) + Utils.padLeft('QTY', 6) + Utils.padLeft('AMOUNT', 10) + '\n';
        t += dash + '\n';
        items.forEach(function (it, i) {
            t += Utils.padRight(String(i + 1), 3)
                + Utils.padRight(Utils.truncate(it.particulars || '', 30), 30)
                + Utils.padRight(Utils.truncate(it.make || '', 12), 12)
                + Utils.padRight(Utils.truncate(it.batch || '', 11), 11)
                + Utils.padRight(it.expiry || '', 8)
                + Utils.padLeft(String(it.qty || 0), 6)
                + Utils.padLeft('Rs.' + (it.amount || 0).toFixed(2), 10) + '\n';
        });
        t += dash + '\n';
        t += 'Items: ' + items.length + '    Qty: ' + qtyTotal + '    Payment Mode: ' + (bill.paymentMode || 'Cash') + '\n';
        t += Utils.padLeft('GRAND TOTAL: Rs.' + (bill.total || 0).toFixed(2), W) + '\n';
        t += dash + '\n';
        t += '* Thank you! Medicine once sold will not be taken back. * Show to doctor *';
        return t;
    },

    // Notepad print ke liye compact version — 65-column, ~16 base lines.
    // LX-310 150x100mm form par ek page = ek form fit karne ke liye
    // (80-col text 10cpi par wrap hota hai → lines double → 2 pages)
    // NOTE: W 57→65 kiya (page ke right side jo blank jagah bach rahi thi wo
    // ab Pat/Doc/Item/Make/Batch/Amt columns ko de di — naam kam truncate honge).
    // Bottom border 'eq' aur total-ke-baad wali extra 'dash' hata di (2 lines kam)
    // taaki 100mm ke ek hi form par poora bill + footer fit ho, agla form par na jaye.
    buildBillTextCompact(bill) {
        const info = CONFIG.STORE_INFO;
        const W = 65;
        const dash = '-'.repeat(W);
        const items = bill.items || [];
        const qtyTotal = items.reduce((s, it) => s + (it.qty || 0), 0);

        let t = '';
        t += Utils.padCenter('CASH MEMO', W) + '\n';
        t += Utils.padCenter(info.name, W) + '\n';
        t += Utils.padCenter(info.address, W) + '\n';
        t += Utils.padCenter('Mob: ' + info.mob + '   FSSAI: ' + info.fssai, W) + '\n';
        t += Utils.padCenter('DL: ' + info.dlNo, W) + '\n';
        t += dash + '\n';
        t += 'Inv: ' + Utils.padRight(String(bill.billNo), 5) + '  Date: ' + bill.date + '\n';
        const _nameCapC = Math.floor((W - 21) / 2);
        t += 'Patient: ' + Utils.truncate(bill.patient || 'Cash Customer', _nameCapC) + '   Doctor:  ' + Utils.truncate(bill.doctor || 'Self', _nameCapC) + '\n';
        t += dash + '\n';
        t += Utils.padRight('#', 3) + Utils.padRight('ITEM', 24) + Utils.padRight('MAKE', 8) + Utils.padRight('BATCH', 10) + Utils.padRight('EXP', 7) + Utils.padLeft('QTY', 4) + Utils.padLeft('AMT', 9) + '\n';
        t += dash + '\n';
        items.forEach(function (it, i) {
            t += Utils.padRight(String(i + 1), 3)
                + Utils.padRight(Utils.truncate(it.particulars || '', 24), 24)
                + Utils.padRight(Utils.truncate(it.make || '', 8), 8)
                + Utils.padRight(Utils.truncate(it.batch || '', 10), 10)
                + Utils.padRight(Utils.truncate(it.expiry || '', 7), 7)
                + Utils.padLeft(String(it.qty || 0), 4)
                + Utils.padLeft((it.amount || 0).toFixed(2), 9) + '\n';
        });
        t += dash + '\n';
        t += 'Items: ' + items.length + '  Qty: ' + qtyTotal + '  Mode: ' + (bill.paymentMode || 'Cash') + '  TOTAL: Rs.' + (bill.total || 0).toFixed(2) + '\n';
        t += '* Thank you! Sold will not be taken back. * Show to doctor *';
        return t;
    },

    // buildBillText() jaisa hi content/columns (Product, Make, Batch, Expiry, Qty, Amount
    // + store header/footer) — lekin raw ESC/P byte sequence (Uint8Array) return karta hai,
    // taaki LX-310 par direct RAW spooler print ho (graphic rasterization nahi → sharp NLQ text)
    buildBillEscP(bill) {
        const text = Utils.buildBillText(bill);
        const lines = text.split('\n');
        const bytes = [];

        // ESC @ — printer initialize (settings reset)
        bytes.push(0x1B, 0x40);
        // ESC x 1 — NLQ mode ON (9-pin dot matrix ka sharp bitmap font)
        bytes.push(0x1B, 0x78, 0x01);
        // SI — condensed pitch ON (~17cpi): paper narrow hai (approx 150mm wide),
        // isliye 80-column layout paper se bahar na jaaye
        if (CONFIG.USE_CONDENSED_PITCH) {
            bytes.push(0x0F);
        }
        // ESC 0 — line spacing 1/8 inch (8 lpi): 100mm form par ~31 lines fit hongi.
        // Default 1/6 inch par sirf ~23 lines fit hoti thi, isliye 5-6 item wale bill
        // me bhi Thank-you wali last 2 lines agle form par chali jaati thi.
        bytes.push(0x1B, 0x30);
        // ESC C n — PAGE LENGTH n lines me set karo (100mm form ≈ 31 lines @1/8").
        // Bina iske printer default 66 lines (11 inch) par FF karta hai → har bill
        // ke baad ~2 extra blank forms bahar aate hain. FF ab exactly 1 form eject karega.
        var formLines = (typeof CONFIG !== 'undefined' && CONFIG.FORM_LINES) || 31;
        if (formLines < 1 || formLines > 127) formLines = 31;
        bytes.push(0x1B, 0x43, formLines);
        // VERIFY: Epson ESC/P Reference Manual se confirm karo — agar 17cpi aur precise
        // chahiye ho to ESC P (12cpi) / ESC M (15cpi) select karna padega
        // (https://files.support.epson.com/pdf/general/escp2ref.pdf)

        lines.forEach(function (line) {
            for (let i = 0; i < line.length; i++) {
                const c = line.charCodeAt(i);
                // printer ke liye sirf ASCII/IBM-PC chars safe hain; non-ASCII → '?'
                bytes.push(c <= 255 ? c : 0x3F);
            }
            // har line ke end mein CR phir LF (ESC/P manual recommendation)
            bytes.push(0x0D, 0x0A);
            // Medicine item wali line (row number se shuru, jaise "1  Paracetamol...")
            // ke baad ESC J 18 — extra ~2.1mm micro-feed, taaki 2 medicines ke
            // beech thodi hawa aaye aur naam clear dikhe. 7 items par total
            // ~14.7mm banta hai, bill ~88mm me fit rehta hai (100mm form).
            if (/^\d/.test(line)) {
                bytes.push(0x1B, 0x4A, 18);
            }
        });

        // CR phir FF — form feed: continuous stationery ko agle form ke top par
        // align karta hai tearing ke liye
        bytes.push(0x0D, 0x0C);

        return new Uint8Array(bytes);
    },

};
