const Returns = (() => {
    const STATUS = {
        PENDING: 'Pending Return',
        PARTIAL: 'Partially Returned',
        RETURNED: 'Returned'
    };

    let _busy = false;
    let _requestId = '';
    let _returnSourceCandidates = [];
    let _sourceIndex = 0;
    let _returnContext = null;
    let _lastFilteredBatchRows = [];
    let _lastFilteredTransactions = [];
    let _expiryItems = [];
    let _selectedExpiryKeys = {};
    let _bulkContext = null;
    let _bulkBusy = false;
    let _bulkRequestId = '';
    let _bulkReturnDate = '';

    const _debouncedRefresh = Utils.debounce(function () {
        refresh();
    }, 250);

    function _norm(value) {
        return String(value == null ? '' : value).trim().toLowerCase();
    }

    function _num(value) {
        const n = parseInt(value, 10);
        return isNaN(n) ? 0 : n;
    }

    function _getAllReturns() {
        return Array.isArray(AppState.returnHistory) ? AppState.returnHistory : [];
    }

    function _sortReturns(a, b) {
        const at = parseInt(a.timestamp, 10) || 0;
        const bt = parseInt(b.timestamp, 10) || 0;
        if (at !== bt) return at - bt;
        return String(a.returnDate || '').localeCompare(String(b.returnDate || ''));
    }

    function _recordMatchesBatch(r, med, batch) {
        if (!r || !med || !batch) return false;
        if (r.stockId && med.id && r.stockId !== med.id) return false;
        if (r.batchId && batch.id && r.batchId === batch.id) return true;
        return (r.stockId === med.id || !r.stockId) &&
            String(r.batch || '') === String(batch.batch || '') &&
            String(r.expiry || '') === String(batch.expiry || '');
    }

    function _returnsForBatch(med, batch) {
        return _getAllReturns()
            .filter(function (r) { return _recordMatchesBatch(r, med, batch); })
            .sort(_sortReturns);
    }

    function getReturnedQty(med, batch) {
        return _returnsForBatch(med, batch).reduce(function (sum, r) {
            return sum + _num(r.qty);
        }, 0);
    }

    function getBatchStatusFor(med, batch) {
        const returnedQty = getReturnedQty(med, batch);
        const currentQty = Math.max(0, _num(batch && batch.qty));
        let status = null;
        if (returnedQty > 0) status = currentQty > 0 ? STATUS.PARTIAL : STATUS.RETURNED;
        else if (currentQty > 0) status = STATUS.PENDING;
        return {
            status: status,
            returnedQty: returnedQty,
            currentQty: currentQty,
            originalQty: currentQty + returnedQty,
            remainingQty: currentQty,
            returnCount: returnedQty > 0 ? _returnsForBatch(med, batch).length : 0
        };
    }

    function _buildBatchRows() {
        const rows = [];
        const matchedReturnIds = {};

        (AppState.stockData || []).forEach(function (med) {
            (med.batches || []).forEach(function (batch, batchIdx) {
                if (!Utils.isExpired(batch.expiry)) return;
                const returns = _returnsForBatch(med, batch);
                const returnedQty = returns.reduce(function (sum, r) { return sum + _num(r.qty); }, 0);
                const currentQty = Math.max(0, _num(batch.qty));
                if (returnedQty <= 0 && currentQty <= 0) return;

                returns.forEach(function (r) { if (r.id) matchedReturnIds[r.id] = true; });
                const status = returnedQty > 0
                    ? (currentQty > 0 ? STATUS.PARTIAL : STATUS.RETURNED)
                    : STATUS.PENDING;
                const lastReturn = returns.length ? returns[returns.length - 1] : null;

                rows.push({
                    key: 's:' + med.id + ':' + (batch.id || (batch.batch + '@' + batch.expiry + '@' + batchIdx)),
                    stockId: med.id,
                    batchId: batch.id || '',
                    batchIndex: batchIdx,
                    medicineName: med.name || '',
                    make: med.make || '',
                    supplier: med.wholesaler || '',
                    batch: batch.batch || '',
                    expiry: batch.expiry || '',
                    currentQty: currentQty,
                    returnedQty: returnedQty,
                    originalQty: currentQty + returnedQty,
                    remainingQty: currentQty,
                    status: status,
                    returns: returns,
                    lastReturnDate: lastReturn ? (lastReturn.returnDate || '') : '',
                    lastReturnTimestamp: lastReturn ? (parseInt(lastReturn.timestamp, 10) || 0) : 0,
                    orphan: false
                });
            });
        });

        // Inventory se delete ho chuki batches ki return history bhi dikhni
        // chahiye — audit trail kabhi gaayab nahi hota.
        const orphanGroups = {};
        _getAllReturns().forEach(function (r) {
            if (!r || (r.id && matchedReturnIds[r.id])) return;
            const key = 'o:' + _norm(r.stockId) + '|' + _norm(r.batchId) + '|' +
                _norm(r.medicineName) + '|' + _norm(r.batch) + '|' +
                _norm(r.expiry) + '|' + _norm(r.supplier);
            if (!orphanGroups[key]) {
                orphanGroups[key] = {
                    key: key,
                    stockId: r.stockId || '',
                    batchId: r.batchId || '',
                    batchIndex: -1,
                    medicineName: r.medicineName || '',
                    make: r.make || '',
                    supplier: r.supplier || '',
                    batch: r.batch || '',
                    expiry: r.expiry || '',
                    currentQty: 0,
                    returnedQty: 0,
                    originalQty: 0,
                    remainingQty: 0,
                    status: STATUS.RETURNED,
                    returns: [],
                    lastReturnDate: '',
                    lastReturnTimestamp: 0,
                    orphan: true
                };
            }
            const group = orphanGroups[key];
            group.returns.push(r);
            group.returnedQty += _num(r.qty);
            group.originalQty = group.returnedQty;
            if ((parseInt(r.timestamp, 10) || 0) >= group.lastReturnTimestamp) {
                group.lastReturnTimestamp = parseInt(r.timestamp, 10) || 0;
                group.lastReturnDate = r.returnDate || '';
            }
        });
        Object.keys(orphanGroups).forEach(function (key) {
            const group = orphanGroups[key];
            group.returns.sort(_sortReturns);
            rows.push(group);
        });

        const priority = {};
        priority[STATUS.PENDING] = 0;
        priority[STATUS.PARTIAL] = 1;
        priority[STATUS.RETURNED] = 2;
        rows.sort(function (a, b) {
            const pa = priority[a.status] == null ? 3 : priority[a.status];
            const pb = priority[b.status] == null ? 3 : priority[b.status];
            if (pa !== pb) return pa - pb;
            const nameCmp = a.medicineName.toLowerCase().localeCompare(b.medicineName.toLowerCase());
            if (nameCmp !== 0) return nameCmp;
            return String(a.expiry || '').localeCompare(String(b.expiry || ''));
        });
        return rows;
    }

    function _getSummary(rows) {
        rows = rows || _buildBatchRows();
        const meds = {};
        let pending = 0, partial = 0, returned = 0, totalQty = 0;
        rows.forEach(function (r) {
            if (_norm(r.medicineName)) meds[_norm(r.medicineName)] = true;
            if (r.status === STATUS.PENDING) pending++;
            else if (r.status === STATUS.PARTIAL) partial++;
            else if (r.status === STATUS.RETURNED) returned++;
            totalQty += _num(r.returnedQty);
        });
        return {
            expiredMedicines: Object.keys(meds).length,
            expiredBatches: rows.length,
            pending: pending,
            partial: partial,
            returned: returned,
            totalQty: totalQty
        };
    }

    function _summaryCard(label, value, sub, cls) {
        return '<div class="return-summary-card ' + cls + '">' +
            '<div class="return-summary-label">' + Utils.escapeHtml(label) + '</div>' +
            '<div class="return-summary-value">' + value + '</div>' +
            '<div class="return-summary-sub">' + Utils.escapeHtml(sub) + '</div>' +
            '</div>';
    }

    function _summaryHtml(rows) {
        const s = _getSummary(rows);
        return _summaryCard('Total Expired Medicines', s.expiredMedicines, s.expiredBatches + ' expired batch(es)', 'expired') +
            _summaryCard('Total Pending Returns', s.pending, 'batch(es) return pending', 'pending') +
            _summaryCard('Total Partially Returned', s.partial, 'batch(es) partially returned', 'partial') +
            _summaryCard('Total Returned Medicines', s.returned, 'batch(es) fully returned', 'returned') +
            _summaryCard('Total Return Quantity', s.totalQty, 'units supplier ko wapas', 'quantity');
    }

    function _renderSummaryCards() {
        const rows = _buildBatchRows();
        const html = _summaryHtml(rows);
        const el = document.getElementById('returnSummaryCards');
        if (el) el.innerHTML = html;
    }

    function _statusClass(status) {
        if (status === STATUS.PENDING) return 'pending';
        if (status === STATUS.PARTIAL) return 'partial';
        if (status === STATUS.RETURNED) return 'returned';
        return 'none';
    }

    function _statusBadge(status) {
        if (!status) return '<span class="return-status none">—</span>';
        return '<span class="return-status ' + _statusClass(status) + '">' + Utils.escapeHtml(status) + '</span>';
    }

    function _readFilters() {
        function val(id) {
            const el = document.getElementById(id);
            return el ? String(el.value || '').trim() : '';
        }
        return {
            from: val('returnFilterFrom'),
            to: val('returnFilterTo'),
            medicine: val('returnFilterMedicine'),
            supplier: val('returnFilterSupplier'),
            batch: val('returnFilterBatch'),
            status: val('returnFilterStatus')
        };
    }

    function _dateInRange(dateStr, fromDate, toDate) {
        if (!fromDate && !toDate) return true;
        const d = Utils.parseDisplayDate(dateStr);
        if (!d) return false;
        if (fromDate && d < fromDate) return false;
        if (toDate && d > toDate) return false;
        return true;
    }

    function _validateDates(filters, showMessage) {
        const fromDate = filters.from ? Utils.parseDisplayDate(filters.from) : null;
        const toDate = filters.to ? Utils.parseDisplayDate(filters.to) : null;
        if (filters.from && !fromDate) {
            if (showMessage) UI.showToast('From Date DD/MM/YYYY format mein valid nahi hai.', 'warn');
            return false;
        }
        if (filters.to && !toDate) {
            if (showMessage) UI.showToast('To Date DD/MM/YYYY format mein valid nahi hai.', 'warn');
            return false;
        }
        if (fromDate && toDate && fromDate > toDate) {
            if (showMessage) UI.showToast('From Date, To Date se badi nahi ho sakti.', 'warn');
            return false;
        }
        return true;
    }

    function _filterBatchRows(rows, filters) {
        const fromDate = filters.from ? Utils.parseDisplayDate(filters.from) : null;
        const toDate = filters.to ? Utils.parseDisplayDate(filters.to) : null;
        return rows.filter(function (row) {
            if (filters.medicine && _norm(row.medicineName).indexOf(_norm(filters.medicine)) === -1) return false;
            if (filters.supplier && _norm(row.supplier).indexOf(_norm(filters.supplier)) === -1) return false;
            if (filters.batch && _norm(row.batch).indexOf(_norm(filters.batch)) === -1) return false;
            if (filters.status && row.status !== filters.status) return false;
            if (fromDate || toDate) {
                if (!row.returns.length) return false;
                return row.returns.some(function (r) {
                    return _dateInRange(r.returnDate, fromDate, toDate);
                });
            }
            return true;
        });
    }

    function _filterTransactions(records, filters) {
        const fromDate = filters.from ? Utils.parseDisplayDate(filters.from) : null;
        const toDate = filters.to ? Utils.parseDisplayDate(filters.to) : null;
        return records.filter(function (r) {
            if (filters.medicine && _norm(r.medicineName).indexOf(_norm(filters.medicine)) === -1) return false;
            if (filters.supplier && _norm(r.supplier).indexOf(_norm(filters.supplier)) === -1) return false;
            if (filters.batch && _norm(r.batch).indexOf(_norm(filters.batch)) === -1) return false;
            if (filters.status && r.statusAfter !== filters.status) return false;
            if (fromDate || toDate) return _dateInRange(r.returnDate, fromDate, toDate);
            return true;
        });
    }

    function _bindBatchActions(tbody) {
        tbody.querySelectorAll('[data-return-action]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                const idx = parseInt(btn.getAttribute('data-idx'), 10);
                const row = _lastFilteredBatchRows[idx];
                if (!row) return;
                if (btn.getAttribute('data-return-action') === 'view') {
                    openBatchDetailsByIndex(idx);
                } else {
                    openReturnModal(row.stockId, row.batchId, row.batchIndex);
                }
            });
        });
    }

    function _renderBatchTable(filters) {
        const tbody = document.getElementById('returnBatchBody');
        if (!tbody) return;
        const rows = _filterBatchRows(_buildBatchRows(), filters);
        _lastFilteredBatchRows = rows;
        Utils.clearElement(tbody);
        if (!rows.length) {
            tbody.innerHTML = '<tr><td colspan="9" class="return-empty">Koi return batch is filter par nahi mili.</td></tr>';
            return;
        }
        rows.forEach(function (row, idx) {
            const tr = document.createElement('tr');
            const action = '<button type="button" class="return-action-btn view" data-return-action="view" data-idx="' + idx + '">🔍 History</button>' +
                (row.remainingQty > 0 && row.stockId
                    ? '<button type="button" class="return-action-btn do-return" data-return-action="return" data-idx="' + idx + '">↩ Return</button>'
                    : '');
            tr.innerHTML =
                '<td><strong>' + Utils.escapeHtml(row.medicineName || '-') + '</strong>' +
                    (row.orphan ? ' <span class="return-mini-badge">History only</span>' : '') +
                    (row.make ? '<div class="return-cell-sub">' + Utils.escapeHtml(row.make) + '</div>' : '') + '</td>' +
                '<td>' + Utils.escapeHtml(row.batch || '-') + '<div class="return-cell-sub">Exp: ' + Utils.escapeHtml(row.expiry || '-') + '</div></td>' +
                '<td>' + (row.supplier ? Utils.escapeHtml(row.supplier) : '<span class="return-cell-muted">Supplier nahi diya</span>') + '</td>' +
                '<td class="return-num">' + row.remainingQty + '</td>' +
                '<td class="return-num">' + row.returnedQty + '</td>' +
                '<td class="return-num"><strong>' + row.originalQty + '</strong></td>' +
                '<td>' + _statusBadge(row.status) + '</td>' +
                '<td>' + (row.lastReturnDate || '<span class="return-cell-muted">—</span>') + '</td>' +
                '<td class="return-actions">' + action + '</td>';
            tbody.appendChild(tr);
        });
        _bindBatchActions(tbody);
    }

    function _renderTransactionTable(filters) {
        const tbody = document.getElementById('returnTxBody');
        if (!tbody) return;
        const records = _filterTransactions(_getAllReturns().slice().sort(function (a, b) {
            return _sortReturns(b, a);
        }), filters);
        _lastFilteredTransactions = records;
        Utils.clearElement(tbody);
        if (!records.length) {
            tbody.innerHTML = '<tr><td colspan="7" class="return-empty">Koi return transaction is filter par nahi mila.</td></tr>';
            return;
        }
        records.forEach(function (r) {
            const tr = document.createElement('tr');
            tr.innerHTML =
                '<td><strong>' + Utils.escapeHtml(r.returnDate || '-') + '</strong>' +
                    '<div class="return-cell-sub">' + Utils.escapeHtml(r.createdAt || '') + '</div></td>' +
                '<td>' + Utils.escapeHtml(r.medicineName || '-') + '</td>' +
                '<td>' + Utils.escapeHtml(r.batch || '-') + '<div class="return-cell-sub">Exp: ' + Utils.escapeHtml(r.expiry || '-') + '</div></td>' +
                '<td>' + (r.supplier ? Utils.escapeHtml(r.supplier) : '<span class="return-cell-muted">Supplier nahi diya</span>') + '</td>' +
                '<td class="return-num">' + _num(r.qty) + '</td>' +
                '<td>' + _statusBadge(r.statusAfter || r.status || STATUS.RETURNED) + '</td>' +
                '<td>' + (r.remarks ? Utils.escapeHtml(r.remarks) : '<span class="return-cell-muted">—</span>') + '</td>';
            tbody.appendChild(tr);
        });
    }

    function refresh() {
        const filters = _readFilters();
        _renderSummaryCards();
        _renderBatchTable(filters);
        _renderTransactionTable(filters);
    }

    function applyFilters() {
        const filters = _readFilters();
        if (!_validateDates(filters, true)) return;
        refresh();
    }

    function resetFilters() {
        ['returnFilterFrom', 'returnFilterTo', 'returnFilterMedicine', 'returnFilterSupplier', 'returnFilterBatch'].forEach(function (id) {
            const el = document.getElementById(id);
            if (el) el.value = '';
        });
        const status = document.getElementById('returnFilterStatus');
        if (status) status.value = '';
        refresh();
    }

    function switchTab(tab) {
        const active = tab === 'transactions' ? 'transactions' : 'batch';
        const batchBtn = document.getElementById('returnTabBatch');
        const txBtn = document.getElementById('returnTabTransactions');
        const batchContent = document.getElementById('returnBatchContent');
        const txContent = document.getElementById('returnTxContent');
        if (batchBtn) batchBtn.className = active === 'batch' ? 'btn-primary' : 'btn-secondary';
        if (txBtn) txBtn.className = active === 'transactions' ? 'btn-primary' : 'btn-secondary';
        if (batchContent) batchContent.style.display = active === 'batch' ? 'block' : 'none';
        if (txContent) txContent.style.display = active === 'transactions' ? 'block' : 'none';
        applyFilters();
    }

    // ==================== EXPIRY ALERT — BULK RETURN ====================
    // Expiry screen sirf expired stock (qty > 0) dikhata hai. Har row par
    // checkbox hai; select karke ek hi confirmation modal se bulk return
    // hota hai. Single-return modal sirf Return History ke liye reserved hai.

    function _expiryKey(stockId, batchId, batchIndex) {
        return 'exp:' + String(stockId || '') + '|' +
            (batchId ? String(batchId) : 'idx:' + batchIndex);
    }

    function _buildExpiryItems() {
        const items = [];
        (AppState.stockData || []).forEach(function (med) {
            (med.batches || []).forEach(function (batch, batchIdx) {
                if (!batch || !Utils.isExpired(batch.expiry)) return;
                const qty = Math.max(0, _num(batch.qty));
                if (qty <= 0) return;
                items.push({
                    key: _expiryKey(med.id, batch.id || '', batchIdx),
                    stockId: med.id,
                    batchId: batch.id || '',
                    batchIndex: batchIdx,
                    medicineName: med.name || '',
                    make: med.make || '',
                    supplier: med.wholesaler || '',
                    batch: batch.batch || '',
                    expiry: batch.expiry || '',
                    qty: qty,
                    price: Number(batch.price) || 0
                });
            });
        });
        items.sort(function (a, b) {
            const nameCmp = a.medicineName.toLowerCase().localeCompare(b.medicineName.toLowerCase());
            if (nameCmp !== 0) return nameCmp;
            const expCmp = String(a.expiry || '').localeCompare(String(b.expiry || ''));
            if (expCmp !== 0) return expCmp;
            return String(a.batch || '').localeCompare(String(b.batch || ''));
        });
        return items;
    }

    function _selectedExpiryItems() {
        const selected = {};
        Object.keys(_selectedExpiryKeys).forEach(function (key) {
            if (_selectedExpiryKeys[key]) selected[key] = true;
        });
        return _expiryItems.filter(function (it) { return selected[it.key]; });
    }

    function _updateExpiryToolbar() {
        const countEl = document.getElementById('expirySelectedCount');
        const returnBtn = document.getElementById('expiryReturnSelectedBtn');
        const selectAll = document.getElementById('expirySelectAll');
        const selected = _selectedExpiryItems();
        let units = 0;
        selected.forEach(function (it) { units += _num(it.qty); });
        if (countEl) {
            countEl.textContent = selected.length
                ? selected.length + ' selected • ' + units + ' units'
                : '0 selected';
            countEl.classList.toggle('has-selection', selected.length > 0);
        }
        if (returnBtn) returnBtn.disabled = selected.length === 0;
        if (selectAll) {
            selectAll.disabled = _expiryItems.length === 0;
            selectAll.checked = _expiryItems.length > 0 && selected.length === _expiryItems.length;
            selectAll.indeterminate = selected.length > 0 && selected.length < _expiryItems.length;
        }
    }

    function renderExpiryList() {
        const tbody = document.getElementById('expiryTableBody');
        if (!tbody) return;
        _expiryItems = _buildExpiryItems();

        // Stock badalne par stale selection hatao.
        const valid = {};
        _expiryItems.forEach(function (it) {
            if (_selectedExpiryKeys[it.key]) valid[it.key] = true;
        });
        _selectedExpiryKeys = valid;

        Utils.clearElement(tbody);
        if (!_expiryItems.length) {
            tbody.innerHTML = '<tr><td colspan="8" class="return-empty">Koi expired stock nahi mila.</td></tr>';
            _updateExpiryToolbar();
            return;
        }

        _expiryItems.forEach(function (it) {
            const tr = document.createElement('tr');
            const checked = !!_selectedExpiryKeys[it.key];
            if (checked) tr.className = 'expiry-row-selected';
            tr.innerHTML =
                '<td class="expiry-select-cell"><input type="checkbox" data-expiry-key="' + Utils.escapeAttr(it.key) + '"' +
                    (checked ? ' checked' : '') + ' aria-label="' + Utils.escapeAttr(it.medicineName + ' batch ' + (it.batch || '-')) + '"></td>' +
                '<td><strong>' + Utils.escapeHtml(it.medicineName) + '</strong>' +
                    (it.make ? '<div class="return-cell-sub">' + Utils.escapeHtml(it.make) + '</div>' : '') + '</td>' +
                '<td>' + (it.supplier ? Utils.escapeHtml(it.supplier) : '<span class="return-cell-muted">Supplier nahi diya</span>') + '</td>' +
                '<td>' + Utils.escapeHtml(it.make || '-') + '</td>' +
                '<td>' + Utils.escapeHtml(it.batch || '-') + '</td>' +
                '<td>' + Utils.escapeHtml(it.expiry || '-') + '</td>' +
                '<td class="return-num">' + it.qty + '</td>' +
                '<td>₹' + it.price.toFixed(2) + '</td>';
            tbody.appendChild(tr);
        });

        tbody.querySelectorAll('input[data-expiry-key]').forEach(function (cb) {
            cb.addEventListener('change', function () { _onExpiryCheckboxChange(cb); });
        });
        _updateExpiryToolbar();
    }

    function _onExpiryCheckboxChange(cb) {
        const key = cb.getAttribute('data-expiry-key');
        if (!key) return;
        if (cb.checked) _selectedExpiryKeys[key] = true;
        else delete _selectedExpiryKeys[key];
        const tr = cb.closest('tr');
        if (tr) tr.classList.toggle('expiry-row-selected', cb.checked);
        _updateExpiryToolbar();
    }

    function toggleSelectAllExpiry(checked) {
        _selectedExpiryKeys = {};
        if (checked) {
            _expiryItems.forEach(function (it) { _selectedExpiryKeys[it.key] = true; });
        }
        const tbody = document.getElementById('expiryTableBody');
        if (tbody) {
            tbody.querySelectorAll('input[data-expiry-key]').forEach(function (cb) {
                cb.checked = !!checked;
                const tr = cb.closest('tr');
                if (tr) tr.classList.toggle('expiry-row-selected', !!checked);
            });
        }
        _updateExpiryToolbar();
    }

    function _showBulkError(message) {
        const el = document.getElementById('bulkReturnError');
        if (!el) {
            if (message) UI.showToast(message, 'error', 4500);
            return;
        }
        el.textContent = message || '';
        el.style.display = message ? 'block' : 'none';
    }

    function _fillBulkModal(items) {
        const countEl = document.getElementById('bulkReturnCountText');
        const unitsEl = document.getElementById('bulkReturnUnitsText');
        const dateEl = document.getElementById('bulkReturnDateText');
        let units = 0;
        items.forEach(function (it) { units += _num(it.qty); });
        if (countEl) countEl.textContent = String(items.length);
        if (unitsEl) unitsEl.textContent = String(units);
        if (dateEl) dateEl.textContent = _bulkReturnDate || '-';

        const tbody = document.getElementById('bulkReturnItemsBody');
        if (!tbody) return;
        Utils.clearElement(tbody);
        items.forEach(function (it) {
            const tr = document.createElement('tr');
            tr.innerHTML =
                '<td><strong>' + Utils.escapeHtml(it.medicineName || '-') + '</strong>' +
                    (it.make ? '<div class="return-cell-sub">' + Utils.escapeHtml(it.make) + '</div>' : '') + '</td>' +
                '<td>' + Utils.escapeHtml(it.batch || '-') +
                    '<div class="return-cell-sub">Exp: ' + Utils.escapeHtml(it.expiry || '-') + '</div></td>' +
                '<td>' + (it.supplier ? Utils.escapeHtml(it.supplier) : '<span class="return-cell-muted">Supplier nahi diya</span>') + '</td>' +
                '<td class="return-num">' + it.qty + '</td>';
            tbody.appendChild(tr);
        });
    }

    function openBulkReturnModal() {
        if (_bulkBusy) return;
        // Fresh stock se selection verify karo — stale rows kabhi return na hon.
        renderExpiryList();
        const items = _selectedExpiryItems();
        if (!items.length) {
            UI.showToast('Pehle kam se kam ek expired medicine select karein.', 'warn', 3500);
            return;
        }
        _bulkContext = items;
        _bulkRequestId = Utils.generateId('ret_bulk');
        _bulkReturnDate = Utils.getTodayStr();
        _showBulkError('');
        _fillBulkModal(items);

        const modal = document.getElementById('bulkReturnModal');
        if (modal) modal.classList.add('show');
        const submit = document.getElementById('bulkReturnSubmitBtn');
        if (submit) { submit.disabled = false; submit.textContent = '↩️ Confirm Return'; }
    }

    function closeBulkReturnModal() {
        if (_bulkBusy) return;
        const modal = document.getElementById('bulkReturnModal');
        if (modal) modal.classList.remove('show');
        _bulkContext = null;
        _bulkRequestId = '';
        _bulkReturnDate = '';
        _showBulkError('');
    }

    async function submitBulkReturn() {
        if (_bulkBusy) return;
        if (!_bulkContext || !_bulkContext.length) {
            _showBulkError('Koi medicine select nahi hai.');
            return;
        }

        const items = _bulkContext.map(function (it) {
            return {
                stockId: it.stockId,
                batchId: it.batchId,
                batchIndex: it.batchIndex,
                qty: it.qty
            };
        });
        const itemCount = items.length;
        let totalQty = 0;
        items.forEach(function (it) { totalQty += _num(it.qty); });
        const requestId = _bulkRequestId;
        const returnDate = _bulkReturnDate;

        _bulkBusy = true;
        const submitBtn = document.getElementById('bulkReturnSubmitBtn');
        if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Saving...'; }
        _showBulkError('');

        let result;
        try {
            result = await AppState.recordMedicineReturns({
                requestId: requestId,
                returnDate: returnDate,
                remarks: 'Bulk return',
                items: items
            });
        } catch (e) {
            result = { ok: false, message: e.message || 'Bulk return save fail hua.' };
        }
        _bulkBusy = false;

        if (!result || !result.ok) {
            if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = '↩️ Confirm Return'; }
            const msg = (result && result.message) || 'Bulk return save nahi ho paya.';
            _showBulkError(msg);
            UI.showToast('❌ ' + msg, 'error', 5500);
            return;
        }

        closeBulkReturnModal();
        _selectedExpiryKeys = {};
        UI.showToast('✅ ' + itemCount + ' expired medicine return ho gayi — total ' + totalQty + ' units. Return History mein save hai.', 'success', 6000);
        refresh();
        try {
            if (typeof AppModules !== 'undefined' && AppModules.refreshExpiryIfVisible) AppModules.refreshExpiryIfVisible();
            if (typeof Inventory !== 'undefined' && Inventory.renderStockTable) Inventory.renderStockTable();
            if (typeof Notifications !== 'undefined' && Notifications.renderPanel) Notifications.renderPanel();
        } catch (e) { console.error('Bulk return refresh warning:', e); }
    }

    function _findCandidates(med, batch) {
        const out = [];
        const seen = {};
        (AppState.stockData || []).forEach(function (sourceMed) {
            if (_norm(sourceMed.name) !== _norm(med.name)) return;
            (sourceMed.batches || []).forEach(function (sourceBatch, sourceIdx) {
                if (_norm(sourceBatch.batch) !== _norm(batch.batch) || _norm(sourceBatch.expiry) !== _norm(batch.expiry)) return;
                const qty = Math.max(0, _num(sourceBatch.qty));
                if (qty <= 0) return;
                const key = sourceMed.id + '|' + (sourceBatch.id || sourceIdx);
                if (seen[key]) return;
                seen[key] = true;
                out.push({
                    stockId: sourceMed.id,
                    batchId: sourceBatch.id || '',
                    batchIndex: sourceIdx,
                    supplier: sourceMed.wholesaler || '',
                    medicineName: sourceMed.name || '',
                    make: sourceMed.make || '',
                    batch: sourceBatch.batch || '',
                    expiry: sourceBatch.expiry || '',
                    qty: qty
                });
            });
        });
        out.sort(function (a, b) { return a.supplier.localeCompare(b.supplier); });
        return out;
    }

    function _showReturnError(message) {
        const el = document.getElementById('returnFormError');
        if (!el) {
            if (message) UI.showToast(message, 'error', 4500);
            return;
        }
        el.textContent = message || '';
        el.style.display = message ? 'block' : 'none';
    }

    function _fillSource(index, keepQty) {
        if (!_returnSourceCandidates.length) return;
        index = Math.max(0, Math.min(index, _returnSourceCandidates.length - 1));
        _sourceIndex = index;
        const src = _returnSourceCandidates[index];
        _returnContext = src;
        const select = document.getElementById('returnSourceSelect');
        if (select) select.value = String(index);
        const setText = function (id, value) {
            const el = document.getElementById(id);
            if (el) el.textContent = value;
        };
        setText('returnMedicineText', src.medicineName || '-');
        setText('returnBatchText', src.batch || '-');
        setText('returnExpiryText', src.expiry || '-');
        setText('returnSupplierText', src.supplier || 'Supplier nahi diya');
        setText('returnAvailableText', String(src.qty) + ' units');
        const qty = document.getElementById('returnQty');
        if (qty) {
            qty.max = String(src.qty);
            if (!keepQty) qty.value = '';
            else if (parseInt(qty.value, 10) > src.qty) qty.value = String(src.qty);
        }
        _updateReturnPreview();
    }

    function _updateReturnPreview() {
        const preview = document.getElementById('returnPreview');
        if (!preview || !_returnContext) return;
        const qtyRaw = parseInt(document.getElementById('returnQty') && document.getElementById('returnQty').value, 10);
        const available = _num(_returnContext.qty);
        if (!qtyRaw || qtyRaw <= 0 || qtyRaw > available) {
            preview.textContent = 'Available: ' + available + ' units • Return quantity daalne par remaining status dikhega.';
            preview.className = 'return-preview';
            return;
        }
        const remaining = available - qtyRaw;
        const status = remaining > 0 ? STATUS.PARTIAL : STATUS.RETURNED;
        preview.textContent = 'Return ke baad remaining: ' + remaining + ' units • New status: ' + status;
        preview.className = 'return-preview valid';
    }

    function openReturnModal(stockId, batchId, batchIndex) {
        if (_busy) return;
        const med = (AppState.stockData || []).find(function (m) { return m && m.id === stockId; });
        if (!med) { UI.showToast('Medicine stock record nahi mila.', 'error'); return; }
        let batch = null;
        if (batchId) batch = (med.batches || []).find(function (b) { return b && b.id === batchId; });
        if (!batch) {
            const bi = parseInt(batchIndex, 10);
            if (!isNaN(bi) && med.batches && med.batches[bi]) batch = med.batches[bi];
        }
        if (!batch) { UI.showToast('Batch record nahi mila.', 'error'); return; }
        if (!Utils.isExpired(batch.expiry)) {
            UI.showToast('Sirf expired batch supplier ko return ki ja sakti hai.', 'warn', 4000);
            return;
        }
        if (Math.max(0, _num(batch.qty)) <= 0) {
            UI.showToast('Is batch mein return karne ke liye stock nahi bacha.', 'warn', 4000);
            return;
        }

        _returnSourceCandidates = _findCandidates(med, batch);
        if (!_returnSourceCandidates.length) {
            UI.showToast('Return ke liye koi valid purchase/batch source nahi mila.', 'error');
            return;
        }
        // Jis batch row se modal khula hai wahi source default ho — warna
        // same medicine/batch/expiry wale do suppliers mein galat supplier
        // ka stock return hone ka risk rehta hai.
        _sourceIndex = 0;
        for (let i = 0; i < _returnSourceCandidates.length; i++) {
            const cand = _returnSourceCandidates[i];
            if (cand.stockId !== stockId) continue;
            if (batchId && cand.batchId && cand.batchId !== batchId) continue;
            _sourceIndex = i;
            break;
        }
        _requestId = Utils.generateId('ret_req');
        _busy = false;
        _showReturnError('');

        const select = document.getElementById('returnSourceSelect');
        if (select) {
            Utils.clearElement(select);
            _returnSourceCandidates.forEach(function (src, idx) {
                const option = document.createElement('option');
                option.value = String(idx);
                option.textContent = (src.supplier || 'Supplier nahi diya') +
                    ' • Available: ' + src.qty + ' • Exp: ' + src.expiry;
                select.appendChild(option);
            });
            select.value = String(_sourceIndex);
        }
        const dateEl = document.getElementById('returnDate');
        if (dateEl) {
            dateEl.value = Utils.getTodayStr();
            dateEl.max = '';
        }
        document.getElementById('returnQty').value = '';
        document.getElementById('returnRemarks').value = '';
        _fillSource(_sourceIndex, false);

        const modal = document.getElementById('returnModal');
        if (modal) modal.classList.add('show');
        const submit = document.getElementById('returnSubmitBtn');
        if (submit) { submit.disabled = false; submit.textContent = '↩ Return Confirm Karein'; }
        setTimeout(function () {
            const q = document.getElementById('returnQty');
            if (q) q.focus();
        }, 80);
    }

    function onSourceChange() {
        const select = document.getElementById('returnSourceSelect');
        if (!select) return;
        _showReturnError('');
        _fillSource(parseInt(select.value, 10) || 0, false);
    }

    function closeReturnModal() {
        if (_busy) return;
        const modal = document.getElementById('returnModal');
        if (modal) modal.classList.remove('show');
        _returnContext = null;
        _returnSourceCandidates = [];
        _requestId = '';
        _showReturnError('');
    }

    function _validateReturnForm() {
        if (!_returnContext) return 'Return source select karein.';
        const qty = parseInt(document.getElementById('returnQty').value, 10);
        const dateStr = document.getElementById('returnDate').value.trim();
        const dateObj = Utils.parseDisplayDate(dateStr);
        const available = _num(_returnContext.qty);
        if (!qty || isNaN(qty) || qty <= 0) return 'Return quantity 1 ya usse zyada honi chahiye.';
        if (qty > available) return 'Over-return nahi ho sakta. Sirf ' + available + ' units available hain.';
        if (!dateObj) return 'Return date DD/MM/YYYY format mein valid daalein.';
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (dateObj > today) return 'Return date aaj se aage ki nahi ho sakti.';
        if (!Utils.isExpired(_returnContext.expiry)) return 'Sirf expired batch return ki ja sakti hai.';
        return '';
    }

    function submitReturn(event) {
        if (event) event.preventDefault();
        if (_busy) return;
        if (!_returnContext) { _showReturnError('Return source select karein.'); return; }
        const error = _validateReturnForm();
        if (error) { _showReturnError(error); return; }
        _showReturnError('');

        const src = _returnContext;
        const qty = parseInt(document.getElementById('returnQty').value, 10);
        const returnDate = document.getElementById('returnDate').value.trim();
        const remarks = document.getElementById('returnRemarks').value.trim();
        const requestId = _requestId;
        const remaining = _num(src.qty) - qty;
        const afterStatus = remaining > 0 ? STATUS.PARTIAL : STATUS.RETURNED;

        _busy = true;
        const submitBtn = document.getElementById('returnSubmitBtn');
        if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Saving...'; }

        UI.showConfirmDialog(
            '↩ Return to Supplier Confirm',
            src.medicineName + ' • Batch ' + src.batch + ' • ' + qty + ' units ' +
                (src.supplier || '(supplier nahi diya)') + ' ko return honge. Return ke baad status: ' + afterStatus + '.',
            'Haan, Return Karo',
            'Cancel'
        ).then(async function (ok) {
            if (!ok) {
                _busy = false;
                if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = '↩ Return Confirm Karein'; }
                return;
            }
            let result;
            try {
                result = await AppState.recordMedicineReturn({
                    requestId: requestId,
                    stockId: src.stockId,
                    batchId: src.batchId,
                    batchIndex: src.batchIndex,
                    qty: qty,
                    returnDate: returnDate,
                    remarks: remarks
                });
            } catch (e) {
                result = { ok: false, message: e.message || 'Return save fail hua.' };
            }
            _busy = false;
            if (!result || !result.ok) {
                if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = '↩ Return Confirm Karein'; }
                const msg = (result && result.message) || 'Return save nahi ho paya.';
                _showReturnError(msg);
                UI.showToast('❌ ' + msg, 'error', 5000);
                return;
            }

            closeReturnModal();
            UI.showToast('✅ ' + qty + ' units return ho gaye — Batch ' + src.batch + ' ab ' + result.statusAfter + ' hai.', 'success', 5000);
            refresh();
            try {
                if (typeof AppModules !== 'undefined' && AppModules.refreshExpiryIfVisible) AppModules.refreshExpiryIfVisible();
                if (typeof Inventory !== 'undefined' && Inventory.renderStockTable) Inventory.renderStockTable();
                if (typeof Notifications !== 'undefined' && Notifications.renderPanel) Notifications.renderPanel();
            } catch (e) { console.error('Return refresh warning:', e); }
        });
    }

    function _txCard(r) {
        return '<div class="return-tx-card">' +
            '<div class="return-tx-head"><strong>' + Utils.escapeHtml(r.returnDate || '-') + '</strong>' +
                '<span class="return-tx-qty">' + _num(r.qty) + ' units</span></div>' +
            '<div class="return-tx-meta">' + Utils.escapeHtml(r.statusBefore || STATUS.PENDING) + ' → ' + Utils.escapeHtml(r.statusAfter || '') +
                ' • Remaining after: ' + _num(r.remainingAfter) + '</div>' +
            '<div class="return-tx-meta">Stock: ' + _num(r.stockBefore) + ' → ' + _num(r.stockAfter) +
                ' • Supplier: ' + Utils.escapeHtml(r.supplier || 'Nahi diya') + '</div>' +
            (r.remarks ? '<div class="return-tx-remarks">Remarks: ' + Utils.escapeHtml(r.remarks) + '</div>' : '') +
            '<div class="return-tx-audit">Saved: ' + Utils.escapeHtml(r.createdAt || '-') +
                ' • Record: ' + Utils.escapeHtml(r.id || '-') + '</div>' +
            '</div>';
    }

    function _showDetailsForRow(row) {
        if (!row) return;
        const title = document.getElementById('returnDetailsTitle');
        if (title) title.textContent = row.medicineName + ' • Batch ' + (row.batch || '-');
        const body = document.getElementById('returnDetailsBody');
        if (!body) return;
        const sorted = row.returns.slice().sort(function (a, b) { return _sortReturns(b, a); });
        const txHtml = sorted.length ? sorted.map(_txCard).join('') :
            '<div class="return-empty">Is batch ke liye abhi koi return transaction nahi hua. Status: Pending Return.</div>';
        body.innerHTML =
            '<div class="return-details-grid">' +
                '<div><span>Supplier</span><strong>' + Utils.escapeHtml(row.supplier || 'Supplier nahi diya') + '</strong></div>' +
                '<div><span>Expiry</span><strong>' + Utils.escapeHtml(row.expiry || '-') + '</strong></div>' +
                '<div><span>Original Qty</span><strong>' + row.originalQty + '</strong></div>' +
                '<div><span>Returned Qty</span><strong>' + row.returnedQty + '</strong></div>' +
                '<div><span>Remaining Returnable</span><strong>' + row.remainingQty + '</strong></div>' +
                '<div><span>Current Status</span><strong>' + _statusBadge(row.status) + '</strong></div>' +
            '</div>' +
            '<div class="return-audit-note">Audit trail: har return transaction permanently save hota hai. Returned stock sale ke liye available nahi hai.</div>' +
            '<h4 class="return-details-subtitle">Return Transactions (' + sorted.length + ')</h4>' +
            '<div class="return-tx-list">' + txHtml + '</div>';
        const modal = document.getElementById('returnDetailsModal');
        if (modal) modal.classList.add('show');
    }

    function openBatchDetailsByIndex(idx) {
        const row = _lastFilteredBatchRows[idx];
        if (row) _showDetailsForRow(row);
    }

    // Expiry table se direct batch details kholne ke liye — filter rows par
    // depend nahi karta, isliye expired stock screen se bhi kaam karta hai.
    function openBatchDetails(stockId, batchId, batchIndex) {
        const bi = parseInt(batchIndex, 10);
        const row = _buildBatchRows().find(function (r) {
            if (r.stockId !== stockId) return false;
            if (batchId && r.batchId) return r.batchId === batchId;
            return !isNaN(bi) && r.batchIndex === bi;
        });
        if (!row) {
            UI.showToast('Is batch ki return history nahi mili.', 'warn', 3500);
            return;
        }
        _showDetailsForRow(row);
    }

    function closeDetailsModal() {
        const modal = document.getElementById('returnDetailsModal');
        if (modal) modal.classList.remove('show');
    }

    function closeAllModals() {
        closeReturnModal();
        closeDetailsModal();
        closeBulkReturnModal();
    }

    function init() {
        ['returnModal', 'returnDetailsModal', 'bulkReturnModal'].forEach(function (id) {
            const modal = document.getElementById(id);
            if (!modal) return;
            modal.addEventListener('click', function (e) {
                if (e.target !== modal) return;
                if (id === 'returnModal') closeReturnModal();
                else if (id === 'bulkReturnModal') closeBulkReturnModal();
                else closeDetailsModal();
            });
        });
        _renderSummaryCards();
        const btnBatch = document.getElementById('returnTabBatch');
        const btnTx = document.getElementById('returnTabTransactions');
        if (btnBatch) btnBatch.className = 'btn-primary';
        if (btnTx) btnTx.className = 'btn-secondary';
    }

    return {
        init: init,
        refresh: refresh,
        applyFilters: applyFilters,
        resetFilters: resetFilters,
        switchTab: switchTab,
        renderExpiryList: renderExpiryList,
        toggleSelectAllExpiry: toggleSelectAllExpiry,
        openBulkReturnModal: openBulkReturnModal,
        closeBulkReturnModal: closeBulkReturnModal,
        submitBulkReturn: submitBulkReturn,
        getBatchRows: _buildBatchRows,
        getBatchStatusFor: getBatchStatusFor,
        getReturnedQty: getReturnedQty,
        statusBadge: _statusBadge,
        openReturnModal: openReturnModal,
        onSourceChange: onSourceChange,
        updateReturnPreview: _updateReturnPreview,
        submitReturn: submitReturn,
        closeReturnModal: closeReturnModal,
        closeDetailsModal: closeDetailsModal,
        closeAllModals: closeAllModals,
        openBatchDetailsByIndex: openBatchDetailsByIndex,
        openBatchDetails: openBatchDetails,
        _debouncedRefresh: _debouncedRefresh,
        STATUS: STATUS
    };
})();
