const UI = (() => {
    const TOAST_ICONS = { success: '✅', error: '❌', info: 'ℹ️', warn: '⚠️' };

    function showToast(msg, type, duration) {
        type = type || 'success';
        duration = duration || 2200;
        const container = document.getElementById('toastContainer');
        if (!container) return;
        const toast = document.createElement('div');
        toast.className = 'toast ' + type;
        const iconSpan = document.createElement('span');
        iconSpan.textContent = TOAST_ICONS[type] || '';
        const msgSpan = document.createElement('span');
        msgSpan.textContent = msg;
        toast.appendChild(iconSpan);
        toast.appendChild(msgSpan);
        container.appendChild(toast);
        requestAnimationFrame(() => {
            requestAnimationFrame(() => { toast.classList.add('show'); });
        });
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => { if (toast.parentNode) toast.remove(); }, 300);
        }, duration);
    }

    function showConfirmDialog(title, message, confirmText, cancelText) {
        return new Promise((resolve) => {
            const existing = document.getElementById('confirmDialogOverlay');
            if (existing) existing.remove();

            const overlay = document.createElement('div');
            overlay.id = 'confirmDialogOverlay';
            overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:10000;display:flex;align-items:center;justify-content:center;';

            const box = document.createElement('div');
            box.style.cssText = 'background:white;border-radius:14px;padding:24px;max-width:400px;width:90%;box-shadow:0 8px 30px rgba(0,0,0,0.2);';

            const h3 = document.createElement('h3');
            h3.textContent = title;
            h3.style.cssText = 'margin:0 0 8px 0;font-size:18px;';

            const p = document.createElement('p');
            p.textContent = message;
            p.style.cssText = 'font-size:13px;color:#6b7280;margin-bottom:18px;';

            const btnDiv = document.createElement('div');
            btnDiv.style.cssText = 'display:flex;gap:10px;justify-content:flex-end;';

            const cancelBtn = document.createElement('button');
            cancelBtn.className = 'btn-secondary';
            cancelBtn.textContent = cancelText || 'Cancel';
            cancelBtn.onclick = () => { overlay.remove(); resolve(false); };

            const confirmBtn = document.createElement('button');
            confirmBtn.className = 'btn-danger';
            confirmBtn.textContent = confirmText || 'Confirm';
            confirmBtn.onclick = () => { overlay.remove(); resolve(true); };

            btnDiv.appendChild(cancelBtn);
            btnDiv.appendChild(confirmBtn);
            box.appendChild(h3);
            box.appendChild(p);
            box.appendChild(btnDiv);
            overlay.appendChild(box);
            document.body.appendChild(overlay);
            confirmBtn.focus();
        });
    }

    function closeAllDropdowns() {
        document.querySelectorAll('.download-dd-menu').forEach(m => m.classList.remove('show'));
    }

    function setupClickOutside() {
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.download-dd')) closeAllDropdowns();
            var el;
            if (!e.target.closest('#billDoctor') && !e.target.closest('#docSuggestions')) {
                el = document.getElementById('docSuggestions');
                if (el) el.style.display = 'none';
            }
            if (!e.target.closest('#billPatient') && !e.target.closest('#patientSuggestions')) {
                el = document.getElementById('patientSuggestions');
                if (el) el.style.display = 'none';
            }
            if (!e.target.closest('#medNameInput') && !e.target.closest('#medNameSuggestions')) {
                el = document.getElementById('medNameSuggestions');
                if (el) el.style.display = 'none';
            }
            if (!e.target.closest('#stockMake') && !e.target.closest('#makeSuggestions')) {
                el = document.getElementById('makeSuggestions');
                if (el) el.style.display = 'none';
            }
            if (!e.target.closest('#stockWholesaler') && !e.target.closest('#wholesalerSuggestions')) {
                el = document.getElementById('wholesalerSuggestions');
                if (el) el.style.display = 'none';
            }
        });
    }

    function showPasswordPrompt() {
        return new Promise((resolve) => {
            const existing = document.getElementById('passwordPromptOverlay');
            if (existing) existing.remove();

            const overlay = document.createElement('div');
            overlay.id = 'passwordPromptOverlay';
            overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:10000;display:flex;align-items:center;justify-content:center;';

            const box = document.createElement('div');
            box.style.cssText = 'background:white;border-radius:14px;padding:24px;max-width:380px;width:90%;box-shadow:0 8px 30px rgba(0,0,0,0.2);';

            const h3 = document.createElement('h3');
            h3.textContent = '🔒 Password Required';
            h3.style.cssText = 'margin:0 0 6px 0;font-size:18px;';

            const p = document.createElement('p');
            p.textContent = 'All data delete karne ke liye admin password daalein.';
            p.style.cssText = 'font-size:13px;color:#6b7280;margin-bottom:14px;';

            const input = document.createElement('input');
            input.type = 'password';
            input.placeholder = 'Password daalein...';
            input.style.cssText = 'width:100%;padding:10px 12px;border:1.5px solid #d1d9e0;border-radius:8px;font-size:14px;outline:none;margin-bottom:14px;';

            const error = document.createElement('div');
            error.style.cssText = 'color:#dc2626;font-size:12px;font-weight:600;display:none;margin-bottom:10px;';
            error.textContent = 'Wrong password!';

            const btnDiv = document.createElement('div');
            btnDiv.style.cssText = 'display:flex;gap:10px;justify-content:flex-end;';

            const cancelBtn = document.createElement('button');
            cancelBtn.className = 'btn-secondary';
            cancelBtn.textContent = 'Cancel';

            const confirmBtn = document.createElement('button');
            confirmBtn.className = 'btn-danger';
            confirmBtn.textContent = 'Delete All Data';

        function _onKeydown(e) {
            if (e.key === 'Enter') confirmBtn.click();
            if (e.key === 'Escape') cancelBtn.click();
        }
        var _cleanup = function () {
            overlay.removeEventListener('click', _overlayClick);
            input.removeEventListener('keydown', _onKeydown);
            overlay.remove();
        };
        function _overlayClick(e) { if (e.target === overlay) { _cleanup(); resolve(false); } }
        cancelBtn.onclick = function () { _cleanup(); resolve(false); };
        confirmBtn.onclick = function () {
            Auth.verifyPassword(input.value).then(function (ok) {
                if (ok) { _cleanup(); resolve(true); }
                else { error.style.display = 'block'; input.value = ''; input.focus(); }
            });
        };
        input.addEventListener('keydown', _onKeydown);
        overlay.addEventListener('click', _overlayClick);

        btnDiv.appendChild(cancelBtn);
        btnDiv.appendChild(confirmBtn);
        box.appendChild(h3);
        box.appendChild(p);
        box.appendChild(input);
        box.appendChild(error);
        box.appendChild(btnDiv);
        overlay.appendChild(box);
        document.body.appendChild(overlay);
        setTimeout(function () { input.focus(); }, 50);
        });
    }

    var _progressToastId = 0;
    var _progressToastEl = null;

    function showProgressToast(msg, autoHide) {
        hideProgressToast();
        var container = document.getElementById('toastContainer');
        if (!container) return;
        var toast = document.createElement('div');
        _progressToastId = Date.now();
        toast.id = 'progressToast_' + _progressToastId;
        toast.className = 'toast info';
        toast.style.cssText = 'opacity:1;transform:translateX(0);border-left:4px solid #1a56db;';
        var spinner = document.createElement('span');
        spinner.textContent = '⏳';
        spinner.style.cssText = 'animation:spin 1s linear infinite;display:inline-block;';
        var msgSpan = document.createElement('span');
        msgSpan.textContent = msg;
        toast.appendChild(spinner);
        toast.appendChild(msgSpan);
        container.appendChild(toast);
        _progressToastEl = toast;
        if (autoHide) {
            setTimeout(function () { hideProgressToast(); }, autoHide);
        }
        return _progressToastId;
    }

    function hideProgressToast() {
        if (_progressToastEl && _progressToastEl.parentNode) {
            _progressToastEl.remove();
        }
        _progressToastEl = null;
    }

    return {
        showToast,
        showConfirmDialog,
        showPasswordPrompt,
        closeAllDropdowns,
        setupClickOutside,
        showProgressToast,
        hideProgressToast
    };
})();
