const Database = (() => {
    const API_BASE = '/api/';
    const REQUEST_TIMEOUT_MS = 20000;
    const PAGE_TIMEOUT_MS = 30000;
    let _available = null;

    // ==================== INDEXEDDB (PRIMARY STORE) ====================
    // medi_soft_db (purana DB) sirf padhne ke liye use hota hai — migration
    // aur recovery ke liye. Naya data medi_soft_v2 mein append-only records
    // ke roop mein save hota hai, taaki ek stale tab doosre tab ka naya data
    // overwrite na kar sake.
    const IDB_NAME = 'medi_soft_v2';
    const IDB_VERSION = 1;
    const LEGACY_IDB_NAME = 'medi_soft_db';
    const IDB_STORES = ['kv', 'meta', 'bills', 'stock', 'returns', 'snapshots'];
    let _dbPromise = null;
    const _locks = {};

    function _openDb() {
        if (_dbPromise) return _dbPromise;
        _dbPromise = new Promise(function (resolve, reject) {
            var settled = false;
            var timer = setTimeout(function () {
                if (settled) return;
                settled = true;
                reject(new Error('IndexedDB open timeout'));
            }, 8000);
            function done(err, db) {
                if (settled) {
                    try { if (db) db.close(); } catch (_) {}
                    return;
                }
                settled = true;
                clearTimeout(timer);
                if (err) reject(err);
                else resolve(db);
            }
            var req;
            try {
                req = indexedDB.open(IDB_NAME, IDB_VERSION);
            } catch (e) {
                done(e);
                return;
            }
            req.onupgradeneeded = function (e) {
                var db = e.target.result;
                if (!db.objectStoreNames.contains('kv')) db.createObjectStore('kv');
                if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'key' });
                if (!db.objectStoreNames.contains('bills')) db.createObjectStore('bills', { keyPath: 'id' });
                if (!db.objectStoreNames.contains('stock')) db.createObjectStore('stock', { keyPath: 'id' });
                if (!db.objectStoreNames.contains('returns')) db.createObjectStore('returns', { keyPath: 'id' });
                if (!db.objectStoreNames.contains('snapshots')) db.createObjectStore('snapshots', { keyPath: 'name' });
            };
            req.onsuccess = function (e) {
                var db = e.target.result;
                db.onversionchange = function () {
                    try { db.close(); } catch (_) {}
                    _dbPromise = null;
                };
                done(null, db);
            };
            req.onerror = function () { done(req.error || new Error('IndexedDB open failed')); };
            req.onblocked = function () { /* timeout will reject; caller falls back */ };
        });
        _dbPromise.catch(function () { _dbPromise = null; });
        return _dbPromise;
    }

    function withLock(name, fn) {
        var prev = _locks[name] || Promise.resolve();
        var next = prev.catch(function () { return null; }).then(fn);
        _locks[name] = next.catch(function () { return null; });
        return next;
    }

    async function idbGetRecord(storeName, key) {
        var db = await _openDb();
        return new Promise(function (resolve, reject) {
            var tx;
            try { tx = db.transaction(storeName, 'readonly'); } catch (e) { reject(e); return; }
            var req = tx.objectStore(storeName).get(key);
            var out;
            req.onsuccess = function () { out = req.result; };
            tx.oncomplete = function () { resolve(out); };
            tx.onerror = function () { reject(tx.error || new Error('IndexedDB read failed')); };
            tx.onabort = function () { reject(tx.error || new Error('IndexedDB read aborted')); };
        });
    }

    async function idbGetAllRecords(storeName) {
        var db = await _openDb();
        return new Promise(function (resolve, reject) {
            var tx;
            try { tx = db.transaction(storeName, 'readonly'); } catch (e) { reject(e); return; }
            var req = tx.objectStore(storeName).getAll();
            var out = [];
            req.onsuccess = function () { out = req.result || []; };
            tx.oncomplete = function () { resolve(out); };
            tx.onerror = function () { reject(tx.error || new Error('IndexedDB read failed')); };
            tx.onabort = function () { reject(tx.error || new Error('IndexedDB read aborted')); };
        });
    }

    async function idbCount(storeName) {
        var db = await _openDb();
        return new Promise(function (resolve, reject) {
            var tx;
            try { tx = db.transaction(storeName, 'readonly'); } catch (e) { reject(e); return; }
            var req = tx.objectStore(storeName).count();
            var out = 0;
            req.onsuccess = function () { out = req.result || 0; };
            tx.oncomplete = function () { resolve(out); };
            tx.onerror = function () { reject(tx.error || new Error('IndexedDB count failed')); };
        });
    }

    async function idbPutBatch(storeName, records) {
        if (!records || !records.length) return true;
        var db = await _openDb();
        return new Promise(function (resolve, reject) {
            var tx;
            try { tx = db.transaction(storeName, 'readwrite'); } catch (e) { reject(e); return; }
            var store = tx.objectStore(storeName);
            try {
                for (var i = 0; i < records.length; i++) store.put(records[i]);
            } catch (e) {
                try { tx.abort(); } catch (_) {}
                reject(e);
                return;
            }
            tx.oncomplete = function () { resolve(true); };
            tx.onerror = function () { reject(tx.error || new Error('IndexedDB write failed')); };
            tx.onabort = function () { reject(tx.error || new Error('IndexedDB write aborted')); };
        });
    }

    async function idbDeleteRecords(storeName, keys) {
        if (!keys || !keys.length) return true;
        var db = await _openDb();
        return new Promise(function (resolve, reject) {
            var tx;
            try { tx = db.transaction(storeName, 'readwrite'); } catch (e) { reject(e); return; }
            var store = tx.objectStore(storeName);
            try {
                for (var i = 0; i < keys.length; i++) store.delete(keys[i]);
            } catch (e) {
                try { tx.abort(); } catch (_) {}
                reject(e);
                return;
            }
            tx.oncomplete = function () { resolve(true); };
            tx.onerror = function () { reject(tx.error || new Error('IndexedDB delete failed')); };
            tx.onabort = function () { reject(tx.error || new Error('IndexedDB delete aborted')); };
        });
    }

    async function idbClearStore(storeName) {
        var db = await _openDb();
        return new Promise(function (resolve, reject) {
            var tx;
            try { tx = db.transaction(storeName, 'readwrite'); } catch (e) { reject(e); return; }
            tx.objectStore(storeName).clear();
            tx.oncomplete = function () { resolve(true); };
            tx.onerror = function () { reject(tx.error || new Error('IndexedDB clear failed')); };
            tx.onabort = function () { reject(tx.error || new Error('IndexedDB clear aborted')); };
        });
    }

    // Ek hi transaction mein multiple stores — return/stock jaise atomic
    // operations ke liye. ops = { stock: {put:[], delete:[]}, returns: {...} }
    async function idbWriteBatch(ops) {
        var names = Object.keys(ops || {}).filter(function (n) { return IDB_STORES.indexOf(n) !== -1; });
        if (!names.length) return true;
        var db = await _openDb();
        return new Promise(function (resolve, reject) {
            var tx;
            try { tx = db.transaction(names, 'readwrite'); } catch (e) { reject(e); return; }
            try {
                names.forEach(function (name) {
                    var op = ops[name] || {};
                    var store = tx.objectStore(name);
                    (op.put || []).forEach(function (rec) { store.put(rec); });
                    (op.delete || []).forEach(function (key) { store.delete(key); });
                });
            } catch (e) {
                try { tx.abort(); } catch (_) {}
                reject(e);
                return;
            }
            tx.oncomplete = function () { resolve(true); };
            tx.onerror = function () { reject(tx.error || new Error('IndexedDB batch failed')); };
            tx.onabort = function () { reject(tx.error || new Error('IndexedDB batch aborted')); };
        });
    }

    async function idbGetKv(key, defaultValue) {
        var rec = await idbGetRecord('kv', key);
        return rec !== undefined ? rec : defaultValue;
    }

    async function idbSetKv(key, value) {
        var db = await _openDb();
        return new Promise(function (resolve, reject) {
            var tx;
            try { tx = db.transaction('kv', 'readwrite'); } catch (e) { reject(e); return; }
            tx.objectStore('kv').put(value, key);
            tx.oncomplete = function () { resolve(true); };
            tx.onerror = function () { reject(tx.error || new Error('IndexedDB kv write failed')); };
            tx.onabort = function () { reject(tx.error || new Error('IndexedDB kv write aborted')); };
        });
    }

    async function idbRemoveKv(key) {
        var db = await _openDb();
        return new Promise(function (resolve, reject) {
            var tx;
            try { tx = db.transaction('kv', 'readwrite'); } catch (e) { reject(e); return; }
            tx.objectStore('kv').delete(key);
            tx.oncomplete = function () { resolve(true); };
            tx.onerror = function () { reject(tx.error || new Error('IndexedDB kv delete failed')); };
        });
    }

    async function idbGetAllKvKeys() {
        var db = await _openDb();
        return new Promise(function (resolve, reject) {
            var tx;
            try { tx = db.transaction('kv', 'readonly'); } catch (e) { reject(e); return; }
            var req = tx.objectStore('kv').getAllKeys();
            var out = [];
            req.onsuccess = function () { out = req.result || []; };
            tx.oncomplete = function () { resolve(out); };
            tx.onerror = function () { reject(tx.error || new Error('IndexedDB keys failed')); };
        });
    }

    async function idbSetMeta(key, value) {
        return idbPutBatch('meta', [{ key: key, value: value, updatedAt: Date.now() }]);
    }

    async function idbGetMeta(key, defaultValue) {
        var rec = await idbGetRecord('meta', key);
        return rec && rec.value !== undefined ? rec.value : defaultValue;
    }

    async function idbGetAllMeta() {
        return idbGetAllRecords('meta');
    }

    async function idbClearAll() {
        var db = await _openDb();
        return new Promise(function (resolve, reject) {
            var tx;
            try { tx = db.transaction(IDB_STORES, 'readwrite'); } catch (e) { reject(e); return; }
            IDB_STORES.forEach(function (name) { tx.objectStore(name).clear(); });
            tx.oncomplete = function () { resolve(true); };
            tx.onerror = function () { reject(tx.error || new Error('IndexedDB clear failed')); };
            tx.onabort = function () { reject(tx.error || new Error('IndexedDB clear aborted')); };
        });
    }

    // ==================== LEGACY DB (READ / RECOVERY ONLY) ====================
    function _openLegacyDb() {
        return new Promise(function (resolve) {
            var settled = false;
            var timer = setTimeout(function () {
                if (settled) return;
                settled = true;
                resolve(null);
            }, 5000);
            function finish(db) {
                if (settled) {
                    try { if (db) db.close(); } catch (_) {}
                    return;
                }
                settled = true;
                clearTimeout(timer);
                resolve(db);
            }
            var req;
            try {
                req = indexedDB.open(LEGACY_IDB_NAME, 1);
            } catch (e) { finish(null); return; }
            req.onupgradeneeded = function (e) {
                var db = e.target.result;
                if (!db.objectStoreNames.contains('store')) db.createObjectStore('store');
            };
            req.onsuccess = function (e) { finish(e.target.result); };
            req.onerror = function () { finish(null); };
            req.onblocked = function () { finish(null); };
        });
    }

    async function idbLegacyGetMany(keys) {
        var out = {};
        var db = await _openLegacyDb();
        if (!db) return out;
        try {
            if (!db.objectStoreNames.contains('store')) return out;
            await new Promise(function (resolve) {
                var tx;
                try { tx = db.transaction('store', 'readonly'); } catch (e) { resolve(); return; }
                var store = tx.objectStore('store');
                keys.forEach(function (key) {
                    try {
                        var req = store.get(key);
                        req.onsuccess = function () { out[key] = req.result; };
                    } catch (_) {}
                });
                tx.oncomplete = function () { resolve(); };
                tx.onerror = function () { resolve(); };
                tx.onabort = function () { resolve(); };
            });
        } finally {
            try { db.close(); } catch (_) {}
        }
        return out;
    }

    async function idbLegacyGet(key, defaultValue) {
        var all = await idbLegacyGetMany([key]);
        return all[key] !== undefined ? all[key] : defaultValue;
    }

    async function idbClearLegacy() {
        var db = await _openLegacyDb();
        if (!db) return false;
        try {
            if (!db.objectStoreNames.contains('store')) return true;
            return await new Promise(function (resolve) {
                var tx;
                try { tx = db.transaction('store', 'readwrite'); } catch (e) { resolve(false); return; }
                tx.objectStore('store').clear();
                tx.oncomplete = function () { resolve(true); };
                tx.onerror = function () { resolve(false); };
                tx.onabort = function () { resolve(false); };
            });
        } finally {
            try { db.close(); } catch (_) {}
        }
    }

    // ==================== ONLINE BACKUP (NEON) PROXY HELPERS ====================
    // Local server ko requests sirf isi header ke saath bheji jaati hain.
    // Cross-origin page ye header bina CORS preflight ke nahi bhej sakta, aur
    // server preflight allow nahi karta — isliye CSRF protection milti hai.
    // Neon connection string sirf server-side (assets/neon-config.json) hai;
    // browser mein koi secret nahi rakha jaata.
    function _apiHeaders() {
        return {
            'Content-Type': 'application/json',
            'X-Requested-With': 'MediSoft'
        };
    }

    function _abortTimeout(ms) {
        try {
            return AbortSignal.timeout(ms);
        } catch (e) {
            var ctrl = new AbortController();
            setTimeout(function () { ctrl.abort(); }, ms);
            return ctrl.signal;
        }
    }

    function isAvailable() {
        if (_available !== null) return _available;
        if (window.location.protocol !== 'http:' && window.location.protocol !== 'https:') {
            _available = false;
            return false;
        }
        _available = true;
        setTimeout(function () {
            fetch('/?' + Date.now(), { method: 'HEAD', signal: _abortTimeout(3000) })
                .then(function (r) { _available = r.status >= 200 && r.status < 400; })
                .catch(function () { _available = false; });
        }, 0);
        return true;
    }

    async function _readError(res) {
        try {
            var data = await res.json();
            if (data && data.error) return data.error;
        } catch (e) {}
        return 'HTTP ' + res.status;
    }

    async function _proxyFetch(table) {
        var allData = [];
        var pageSize = CONFIG.CLOUD_PAGE_SIZE || 1000;
        var offset = 0;
        var maxPages = 100;
        try {
            while (maxPages-- > 0) {
                var res = await fetch(API_BASE + table + '?select=*&limit=' + pageSize + '&offset=' + offset, {
                    headers: _apiHeaders(),
                    signal: _abortTimeout(PAGE_TIMEOUT_MS)
                });
                if (!res.ok) return { error: await _readError(res) };
                var data = await res.json();
                if (!data || !data.length) break;
                allData = allData.concat(data);
                if (data.length < pageSize) break;
                offset += pageSize;
            }
            return allData;
        } catch (e) {
            return { error: e.message || 'Fetch failed' };
        }
    }

    async function _proxyUpsert(table, rows, conflictCol) {
        if (!rows || (Array.isArray(rows) && !rows.length)) return { error: 'No rows to upsert' };
        conflictCol = conflictCol || 'id';
        try {
            var arr = Array.isArray(rows) ? rows : [rows];
            var qs = '?select=*&on_conflict=' + encodeURIComponent(conflictCol);
            var res = await fetch(API_BASE + table + qs, {
                method: 'POST',
                headers: _apiHeaders(),
                body: JSON.stringify(arr),
                signal: _abortTimeout(REQUEST_TIMEOUT_MS)
            });
            if (!res.ok) return { error: await _readError(res) };
            return true;
        } catch (e) {
            return { error: e.message || 'Upsert failed' };
        }
    }

    async function _proxyDelete(table, col, val) {
        try {
            var qs = '?' + encodeURIComponent(col) + '=eq.' + encodeURIComponent(String(val));
            var res = await fetch(API_BASE + table + qs, {
                method: 'DELETE',
                headers: _apiHeaders(),
                signal: _abortTimeout(REQUEST_TIMEOUT_MS)
            });
            if (!res.ok) return { error: await _readError(res) };
            return true;
        } catch (e) {
            return { error: e.message || 'Delete failed' };
        }
    }

    async function _proxyDeleteMany(table, col, vals) {
        if (!vals || !vals.length) return { error: 'No values to delete' };
        var allOk = true, CHUNK = 50;
        for (var i = 0; i < vals.length; i += CHUNK) {
            var chunk = vals.slice(i, i + CHUNK);
            try {
                var qs = '?' + encodeURIComponent(col) + '=in.(' + chunk.map(function (v) { return encodeURIComponent(String(v)); }).join(',') + ')';
                var res = await fetch(API_BASE + table + qs, {
                    method: 'DELETE',
                    headers: _apiHeaders(),
                    signal: _abortTimeout(REQUEST_TIMEOUT_MS)
                });
                if (!res.ok) { console.error('PROXY DELETE ' + table + ' chunk ' + (i / CHUNK) + ' failed:', await _readError(res)); allOk = false; }
            } catch (e) {
                console.error('PROXY DELETE ' + table + ' chunk ' + (i / CHUNK) + ' error:', e.message); allOk = false;
            }
        }
        return allOk ? true : { error: 'Some deletes failed (see console)' };
    }

    // Saare cloud operations sirf local server ke through jaate hain.
    // Browser kabhi Neon DB ko direct contact nahi karta.
    async function cloudFetch(table) {
        if (!isAvailable()) return { error: 'Local server unavailable' };
        return await _proxyFetch(table);
    }

    async function cloudUpsert(table, rows, conflictCol) {
        if (!isAvailable()) return { error: 'Local server unavailable' };
        return await _proxyUpsert(table, rows, conflictCol);
    }

    async function cloudDelete(table, col, val) {
        if (!isAvailable()) return { error: 'Local server unavailable' };
        return await _proxyDelete(table, col, val);
    }

    async function cloudDeleteMany(table, col, vals) {
        if (!isAvailable()) return { error: 'Local server unavailable' };
        return await _proxyDeleteMany(table, col, vals);
    }

    // ==================== LOCALSTORAGE WRAPPER ====================
    const Storage = {
        get(key, defaultValue) {
            try {
                const val = localStorage.getItem(key);
                return val ? JSON.parse(val) : defaultValue;
            } catch (e) {
                console.error('Storage.get error:', key, e);
                return defaultValue;
            }
        },

        set(key, value) {
            try {
                localStorage.setItem(key, JSON.stringify(value));
                return true;
            } catch (e) {
                console.error('Storage.set error:', key, e);
                return false;
            }
        },

        getString(key, defaultValue) {
            try {
                const val = localStorage.getItem(key);
                return val !== null ? val : defaultValue;
            } catch (e) {
                return defaultValue;
            }
        },

        setString(key, value) {
            try {
                localStorage.setItem(key, String(value));
                return true;
            } catch (e) {
                return false;
            }
        },

        remove(key) {
            try {
                localStorage.removeItem(key);
                return true;
            } catch (e) {
                return false;
            }
        },

        // Purane API naam — naye v2 kv store par map kiye gaye hain.
        idbGet(key, defaultValue) {
            return idbGetKv(key, defaultValue);
        },

        idbSet(key, value) {
            return idbSetKv(key, value).then(function () { return true; }).catch(function () { return false; });
        },

        idbRemove(key) {
            return idbRemoveKv(key).then(function () { return true; }).catch(function () { return false; });
        },

        idbClear() {
            return idbClearAll().then(function () { return true; }).catch(function () { return false; });
        },

        idbLegacyGet,
        idbLegacyGetMany,
        idbClearLegacy
    };

    async function printTextToNotepad(text) {
        if (isAvailable()) {
            try {
                var res = await fetch(API_BASE + 'print-text', {
                    method: 'POST',
                    headers: _apiHeaders(),
                    body: JSON.stringify({ text: String(text || '') }),
                    signal: _abortTimeout(REQUEST_TIMEOUT_MS)
                });
                if (res.ok) return true;
            } catch (e) {}
        }
        try {
            var blob = new Blob([String(text || '')], { type: 'text/plain;charset=utf-8' });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'medisoft_bill_' + Date.now() + '.txt';
            a.click();
            setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
            return false;
        } catch (e) {
            return false;
        }
    }

    async function printRawEscP(bytes) {
        let b64 = '';
        try {
            if (typeof bytes === 'string') {
                b64 = bytes;
            } else {
                const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
                let bin = '';
                for (let i = 0; i < arr.length; i++) bin += String.fromCharCode(arr[i]);
                b64 = btoa(bin);
            }
        } catch (e) {
            console.error('printRawEscP base64 error:', e);
            return false;
        }
        if (!isAvailable()) return false;
        try {
            const body = { dataBase64: b64 };
            if (CONFIG.PRINTER_NAME) body.printerName = CONFIG.PRINTER_NAME;
            const res = await fetch(API_BASE + 'print-raw', {
                method: 'POST',
                headers: _apiHeaders(),
                body: JSON.stringify(body),
                signal: _abortTimeout(REQUEST_TIMEOUT_MS)
            });
            return res.ok;
        } catch (e) {
            console.error('printRawEscP error:', e);
            return false;
        }
    }

    return {
        isAvailable,
        cloudFetch,
        cloudUpsert,
        cloudDelete,
        cloudDeleteMany,
        Storage,
        printTextToNotepad,
        printRawEscP,

        // IndexedDB v2 API
        idbGetRecord,
        idbGetAllRecords,
        idbCount,
        idbPutBatch,
        idbDeleteRecords,
        idbClearStore,
        idbWriteBatch,
        idbGetKv,
        idbSetKv,
        idbRemoveKv,
        idbGetAllKvKeys,
        idbSetMeta,
        idbGetMeta,
        idbGetAllMeta,
        idbClearAll,
        idbClearLegacy,
        withLock
    };
})();
