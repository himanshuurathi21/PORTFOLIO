# RATHI's MEDISOFT — Raw ESC/P Print (Dot Matrix / EPSON LX-310)

> Printing documentation temporarily removed. Printer settings, print-size ratio
> and raw ESC/P options will be re-added here.
