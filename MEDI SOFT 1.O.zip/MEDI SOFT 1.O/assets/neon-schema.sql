-- ============================================================
-- Shri Ramdevbaba Medical & General Store — Neon Postgres Schema
-- Neon Console -> SQL Editor mein run karein (optional).
-- App pehli online backup/restore par ye tables khud bhi bana leta hai
-- (CREATE TABLE IF NOT EXISTS), isliye manual run zaroori nahi hai.
-- ============================================================

-- 1. STOCK (Medicines Inventory)
CREATE TABLE IF NOT EXISTS public.stock (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    wholesaler TEXT DEFAULT '',
    make TEXT DEFAULT '',
    h BOOLEAN DEFAULT false,
    h1 BOOLEAN DEFAULT false,
    h2 BOOLEAN DEFAULT false,
    narcotic BOOLEAN DEFAULT false
);

-- 2. BATCHES (per-medicine batch entries)
CREATE TABLE IF NOT EXISTS public.batches (
    id TEXT PRIMARY KEY,
    stock_id TEXT NOT NULL REFERENCES public.stock(id) ON DELETE CASCADE,
    batch TEXT DEFAULT '',
    expiry TEXT DEFAULT '',
    qty INTEGER DEFAULT 0,
    strip_size INTEGER DEFAULT 0,
    price REAL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_batches_stock_id ON public.batches(stock_id);

-- 3. BILLS
CREATE TABLE IF NOT EXISTS public.bills (
    id TEXT PRIMARY KEY,
    bill_no INTEGER DEFAULT 0,
    date TEXT DEFAULT '',
    time TEXT DEFAULT '',
    patient TEXT DEFAULT '',
    doctor TEXT DEFAULT '',
    payment_mode TEXT DEFAULT 'Cash',
    total REAL DEFAULT 0,
    cancelled BOOLEAN DEFAULT false,
    cancel_reason TEXT DEFAULT '',
    cancelled_at TEXT DEFAULT ''
);

-- 4. BILL ITEMS
CREATE TABLE IF NOT EXISTS public.bill_items (
    id TEXT PRIMARY KEY,
    bill_id TEXT NOT NULL REFERENCES public.bills(id) ON DELETE CASCADE,
    stock_id TEXT DEFAULT '',
    particulars TEXT DEFAULT '',
    make TEXT DEFAULT '',
    h BOOLEAN DEFAULT false,
    h1 BOOLEAN DEFAULT false,
    h2 BOOLEAN DEFAULT false,
    narcotic BOOLEAN DEFAULT false,
    batch TEXT DEFAULT '',
    expiry TEXT DEFAULT '',
    qty INTEGER DEFAULT 0,
    amount REAL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_bill_items_bill_id ON public.bill_items(bill_id);

-- 5. DOCTORS LIST
CREATE TABLE IF NOT EXISTS public.doctors (
    name TEXT PRIMARY KEY
);

-- 6. MAKE (BRAND/COMPANY) LIST
CREATE TABLE IF NOT EXISTS public.make_list (
    name TEXT PRIMARY KEY
);

-- 7. WHOLESALER LIST
CREATE TABLE IF NOT EXISTS public.wholesaler_list (
    name TEXT PRIMARY KEY
);

-- 8. PATIENT WORD SUGGESTIONS
CREATE TABLE IF NOT EXISTS public.patient_words (
    word TEXT PRIMARY KEY
);

-- 9. BILL COUNTER
CREATE TABLE IF NOT EXISTS public.bill_counter (
    id INTEGER PRIMARY KEY DEFAULT 1,
    counter INTEGER DEFAULT 0
);

-- 10. PURCHASE BILLS
CREATE TABLE IF NOT EXISTS public.purchase_bills (
    id TEXT PRIMARY KEY,
    pharma_name TEXT DEFAULT '',
    file_name TEXT DEFAULT '',
    file_type TEXT DEFAULT '',
    file_data TEXT DEFAULT '',
    date TEXT DEFAULT '',
    added_at BIGINT DEFAULT 0
);

-- 11. MEDICINE RETURNS (optional audit trail)
-- Agar yeh table nahi bhi ho, to baaki cloud backup normal kaam karta hai.
CREATE TABLE IF NOT EXISTS public.medicine_returns (
    id TEXT PRIMARY KEY,
    request_id TEXT DEFAULT '',
    stock_id TEXT DEFAULT '',
    batch_id TEXT DEFAULT '',
    medicine_name TEXT DEFAULT '',
    make TEXT DEFAULT '',
    supplier TEXT DEFAULT '',
    batch TEXT DEFAULT '',
    expiry TEXT DEFAULT '',
    qty INTEGER DEFAULT 0,
    return_date TEXT DEFAULT '',
    remarks TEXT DEFAULT '',
    status_before TEXT DEFAULT '',
    status_after TEXT DEFAULT '',
    remaining_after INTEGER DEFAULT 0,
    stock_before INTEGER DEFAULT 0,
    stock_after INTEGER DEFAULT 0,
    returned_before INTEGER DEFAULT 0,
    source_type TEXT DEFAULT 'inventory',
    created_at TEXT DEFAULT '',
    timestamp BIGINT DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_medicine_returns_stock_id ON public.medicine_returns(stock_id);
CREATE INDEX IF NOT EXISTS idx_medicine_returns_medicine ON public.medicine_returns(medicine_name);

-- ============================================================
-- SECURITY NOTE
-- ============================================================
-- Neon connection string sirf assets/neon-config.json (server-side) mein hai.
-- Browser kabhi DB ko direct contact nahi karta — sab kuch local server ke
-- /api/* proxy se hota hai. neon-config.json static server se serve nahi hoti.
-- ============================================================
