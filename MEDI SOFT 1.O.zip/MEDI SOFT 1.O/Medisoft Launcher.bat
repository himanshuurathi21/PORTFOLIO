@echo off
title Medisoft Launcher
wscript.exe "%~dp0Medisoft Launcher.vbs"
exit
