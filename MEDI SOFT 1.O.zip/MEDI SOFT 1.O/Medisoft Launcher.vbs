' Medisoft Launcher - server ko background mein start karta hai aur web app kholta hai
' (koi window nahi dikhti - fully hidden)

Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

base = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = base & "\assets"

' ===== SETUP MODE: desktop shortcut banao =====
' (kisi bhi computer par — shortcut isi folder ki location point karta hai)
If WScript.Arguments.Count > 0 Then
    If LCase(WScript.Arguments(0)) = "/setup" Then
        lnk = sh.SpecialFolders("Desktop") & "\Medisoft Medical Store.lnk"
        Set sc = sh.CreateShortcut(lnk)
        sc.TargetPath = sh.ExpandEnvironmentStrings("%WINDIR%\System32\wscript.exe")
        sc.Arguments = """" & WScript.ScriptFullName & """"
        sc.WorkingDirectory = base
        sc.Description = "Medisoft - background server + web app"
        sc.Save
        MsgBox "Desktop shortcut ban gaya: Medisoft Medical Store", 64, "Medisoft Setup"
        WScript.Quit
    End If
End If

' ===== NODE KO DHUNDHO (PATH + common install locations) =====
nodeCmd = "node"
found = False
On Error Resume Next
Set chk = sh.Exec(nodeCmd & " --version")
If Err.Number = 0 Then
    Do While chk.Status = 0
        WScript.Sleep 100
    Loop
    If chk.ExitCode = 0 Then found = True
End If
Err.Clear
If Not found Then
    candidates = Array( _
        sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\nodejs\node.exe", _
        sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\nodejs\node.exe", _
        sh.ExpandEnvironmentStrings("%LocalAppData%") & "\Programs\nodejs\node.exe")
    For Each cand In candidates
        If fso.FileExists(cand) Then
            Set chk = sh.Exec("""" & cand & """ --version")
            Do While chk.Status = 0
                WScript.Sleep 100
            Loop
            If chk.ExitCode = 0 Then
                nodeCmd = """" & cand & """"
                found = True
                Exit For
            End If
        End If
    Next
End If
On Error GoTo 0
If Not found Then
    MsgBox "Node.js installed nahi hai!" & vbCrLf & "Install karne ke liye https://nodejs.org khulta hai." & vbCrLf & vbCrLf & "Install ke baad COMPUTER RESTART karna zaroori hai.", 48, "Medisoft"
    sh.Run "https://nodejs.org", 1, False
    WScript.Quit
End If

' ===== SERVER PEHLE SE CHAL RAHA HAI? =====
' Use PowerShell for reliable port check
Set exec = sh.Exec("powershell -NoProfile -Command ""$l = Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue; if ($l) { exit 0 } else { exit 1 }""")
Do While exec.Status = 0
    WScript.Sleep 100
Loop

If exec.ExitCode = 0 Then
    ' Port 8080 pe server chal raha hai — browser kholo
    sh.Run "http://127.0.0.1:8080", 1, False
Else
    ' Server start karo (hidden) - server khud browser khol deta hai
    sh.Run nodeCmd & " server.js", 0, False
End If
