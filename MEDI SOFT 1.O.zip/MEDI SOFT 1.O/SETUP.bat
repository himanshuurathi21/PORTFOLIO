@echo off
title Medisoft Setup
echo ============================================
echo  RATHI MEDISOFT - Desktop Shortcut Setup
echo ============================================
echo.
echo Desktop shortcut ban raha hai...
wscript.exe "%~dp0Medisoft Launcher.vbs" /setup

echo.
echo Setup complete!
echo Ab Desktop par "Medisoft Medical Store" icon double-click karo.
echo.
pause
